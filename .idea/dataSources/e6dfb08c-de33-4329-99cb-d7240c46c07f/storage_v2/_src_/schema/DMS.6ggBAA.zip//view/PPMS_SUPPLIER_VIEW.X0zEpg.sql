create view PPMS_SUPPLIER_VIEW as
  SELECT (CASE WHEN SYSTEM_TYPE = '0' THEN '1' ELSE '2' END) SUPPLIER_TYPE,
          SUPPLIER_SERIAL_NO,
          SUPPLIER,
          ENT_ADDR,
          PHONE,
          CONTACTOR,
          ACCOUNT_NO,
          BANK,
          TAX_NO,
          ENT_NAME_ALIAS,
          POSTAL_CODE,
          MOBILE_NUM,
          E_MAIL_ADDR,
          IS_STOP,
          INPUT_CODE,
          CREATE_DATE,
          NOTE,
          SUPPLIER_PERMIT_NO,
          SUPPLIER_PERMIT_INVALIDATE,
          SUPPLIER_FAX_NO,
          SUPPLIER_HEAD
     FROM GOODS_SUPPLIER_CATALOG
   UNION
   SELECT '0' SUPPLIER_TYPE,
          SUPPLIER_SERIAL_NO,
          SUPPLIER,
          ENT_ADDR,
          PHONE,
          CONTACTOR,
          ACCOUNT_NO,
          BANK,
          TAX_NO,
          ENT_NAME_ALIAS,
          POSTAL_CODE,
          MOBILE_NUM,
          E_MAIL_ADDR,
          IS_STOP,
          INPUT_CODE,
          CREATE_DATE,
          NOTE,
          '' SUPPLIER_PERMIT_NO,
          NULL SUPPLIER_PERMIT_INVALIDATE,
          '' SUPPLIER_FAX_NO,
          '' SUPPLIER_HEAD
     FROM PHAM_SUPPLIER_CATALOG


/

