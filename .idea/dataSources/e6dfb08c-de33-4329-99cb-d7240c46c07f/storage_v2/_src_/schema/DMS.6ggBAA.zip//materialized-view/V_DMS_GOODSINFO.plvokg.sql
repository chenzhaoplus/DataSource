create materialized view V_DMS_GOODSINFO
refresh force on demand
  as
    select * from dms.V_DMS_GOODSINFO_link

/

