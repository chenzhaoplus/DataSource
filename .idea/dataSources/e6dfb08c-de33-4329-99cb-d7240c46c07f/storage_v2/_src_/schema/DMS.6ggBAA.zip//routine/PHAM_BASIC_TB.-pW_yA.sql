create procedure pham_basic_tb
as
pham_name varchar2(500);
begin
  -------插入新增的药品信息
insert into dms.pham_basic_info 
select 
PHAM_STD_CODE||'-'||(row_number() over(partition by PHAM_STD_CODE order by PHAM_STD_CODE)) AS pham_std_code,
pham_code, pham_cate_code, pham_name, pham_general_name, pham_e_name, pham_spec, svr_scope_type_id,
pham_des, svr_mode_type_code, pham_unit, dose_unit, dose_per_unit, package_unit, package_factor, retail_price, trade_price, purchase_price, pharmacy_factory, 
qualification_code, org_id_belong, show_in_order_flag, create_time, emp_id_create, edit_time, emp_id_edit, bidding_flag, temporary_flag, org_id_hosp,
stop_flag_plan, stop_flag_pur, delete_flag, high_risk_level, manage_level, free_charge_flag, bill_model_code, purchase_type, note, pham_similar, basic_pham, 
gb_serial_no, subj_code ,null,null,'1'from thdba.ypjbxx_zx;
commit;

-------插入扩展表
insert into dms.pham_attribute_info
  select a.pham_std_code as pham_std_code,
         null            as origin_form,
         b.jgfl          as price_property, --
         b.dmfl          as toxicology_property, --
         c.item_value    as pham_form,
         null            as material_property, --
         null            as precript_code,
         null            as pharm_code,
         null            as use_guide,
         null            as effect,
         null            as kick_back,
         null            as att_note,
         null            as component,
         null            as tabu,
         null            as suit,
         null            as recip,
         null            as direction,
         null            as e_data,
         null            as general_cate_name,
         null            as physics_trait,
         null            as storage_trait,
         null            as def_usage_code,
         null            as def_freq_code,
         a.dose_per_unit as def_per_dose,
         null            as def_per_quan,
         a.dose_unit     as dosage_units,
         null            as def_course,
         null            as def_course_unit,
         null            as ch_def_usage_code,
         null            as oi_dosage_units,
         null            as pham_oi_sign
  
    from dms.pham_basic_info a
    left join ypjbxx_kz@oldhis b
      on a.pham_e_name = b.drug_code
     and a.pham_spec = b.drug_spec
    left join (select *
                 from bds.bds_code_table_item f
                where f.id in (select max(id)
                                 from bds.bds_code_table_item e
                                where e.t_id = '19'
                                group by e.item_name)
                  and f.t_id = '19') c
      on b.drug_form = c.item_name
   where a.pham_std_code not in
         (select t.pham_std_code from dms.pham_attribute_info t);    
commit;

---插入启停标志
insert into dms.pham_cust_def_busi
select pham_std_code,'StopFlagPlan','计划停标识',1,null,'H0002' from dms.pham_basic_info where pham_std_code not in(
select b.pham_std_code from dms.pham_cust_def_busi b where  b.cont_type_id='StopFlagPlan');
insert into dms.pham_cust_def_busi
select pham_std_code,'StopFlagPur','采购停标识',1,null,'H0002' from dms.pham_basic_info where pham_std_code not in(
select b.pham_std_code from dms.pham_cust_def_busi b where b.cont_type_id='StopFlagPur');

commit;
-------插入别名表
insert into dms.pham_alia_dict
select a.pham_std_code,dms.f_sequence_gen('PHAM_ALIA_DICT',1),a.pham_name,func_getpy(a.pham_name,3),'0' from dms.pham_basic_info a where a.pham_std_code not in (
select b.pham_code from dms.pham_alia_dict b
);
commit;

-----插入多园区价格表
insert into dms.pham_basic_price_detail
select 
dms.f_sequence_gen('PHAM_BASIC_PRICE_DETAIL',1),
'1',
a.pham_std_code,
a.retail_price,
a.trade_price,
a.purchase_price
 from dms.pham_basic_info a where a.pham_std_code not in (
select b.pham_std_code from dms.pham_basic_price_detail b --where b.price_level_code='1'
)
;
commit;
end;




/

