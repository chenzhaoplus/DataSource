create trigger TR_NDGZ_DMS_PHAM_DOCU_HEAD
  before insert
  on PHAM_DOCU_HEAD
  for each row
  begin
    if :new.pham_io_sort in( '2003','1013') then
        raise_application_error(-20001,'年底2016年12月20号 23:59:59秒进行关账,为期20天，禁止所有和经费卡相关的业务!');
    end if;
end;







/

