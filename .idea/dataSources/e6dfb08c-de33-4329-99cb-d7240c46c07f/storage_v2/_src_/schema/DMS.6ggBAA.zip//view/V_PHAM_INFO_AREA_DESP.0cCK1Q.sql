create view V_PHAM_INFO_AREA_DESP as
  SELECT A.PHAM_STD_CODE,
       A.PHAM_CATE_CODE,
       (SELECT ITEM_NAME
          FROM BDS_CODE_TABLE_ITEM
         WHERE T_ID =
               (SELECT ID FROM BDS_CODE_TABLE WHERE STANDARD_CODE = 'TJ0023')
           AND ITEM_VALUE = A.PHAM_CATE_CODE) AS PHAM_CATE_NAME,
       A.PHAM_CODE,
       A.PHAM_NAME,
       (SELECT MAX(INPUT_CODE)
          FROM PHAM_ALIA_DICT
         WHERE PHAM_CODE = A.PHAM_STD_CODE
           AND STD_INDICATOR = 0) AS INPUT_CODE,
       A.PHAM_GENERAL_NAME,
       A.PHAM_E_NAME,
       A.PHAM_SPEC,
       A.PHAM_UNIT,
       (SELECT ITEM_NAME
          FROM BDS_CODE_TABLE_ITEM
         WHERE T_ID =
               (SELECT ID FROM BDS_CODE_TABLE WHERE STANDARD_CODE = 'TJ0024')
           AND ITEM_VALUE = A.PHAM_UNIT) AS PHAM_UNIT_DESP,
       A.DOSE_UNIT,
       (SELECT ITEM_NAME
          FROM BDS_CODE_TABLE_ITEM
         WHERE T_ID =
               (SELECT ID FROM BDS_CODE_TABLE WHERE STANDARD_CODE = 'TJ0022')
           AND ITEM_VALUE = A.DOSE_UNIT) AS DOSE_UNIT_DESP,
       A.DOSE_PER_UNIT,
       A.PACKAGE_UNIT,
       (SELECT ITEM_NAME
          FROM BDS_CODE_TABLE_ITEM
         WHERE T_ID =
               (SELECT ID FROM BDS_CODE_TABLE WHERE STANDARD_CODE = 'TJ0024')
           AND ITEM_VALUE = A.PACKAGE_UNIT) AS PACKAGE_UNIT_DESP,
      A.PACKAGE_FACTOR,
      pd.RETAIL_PRICE,
      pd.TRADE_PRICE,
      pd.PURCHASE_PRICE,
       TO_CHAR(ROUND(pd.RETAIL_PRICE / A.PACKAGE_FACTOR, 4), 'FM999999.0000') AS PHAM_PRICE,
       A.PHARMACY_FACTORY,
       A.MANAGE_LEVEL,
       B.PRICE_PROPERTY,
       (SELECT ITEM_NAME
          FROM BDS_CODE_TABLE_ITEM
         WHERE T_ID =
               (SELECT ID FROM BDS_CODE_TABLE WHERE STANDARD_CODE = 'TJ0020')
           AND ITEM_VALUE = B.PRICE_PROPERTY) AS PRICE_PROPERTY_DESP,
       B.TOXICOLOGY_PROPERTY,
       (SELECT ITEM_NAME
          FROM BDS_CODE_TABLE_ITEM
         WHERE T_ID =
               (SELECT ID FROM BDS_CODE_TABLE WHERE STANDARD_CODE = 'TJ0017')
           AND ITEM_VALUE = B.TOXICOLOGY_PROPERTY) AS TOXICOLOGY_PROPERTY_DESP,
       B.PHAM_FORM,
       (SELECT ITEM_NAME
          FROM BDS_CODE_TABLE_ITEM
         WHERE T_ID =
               (SELECT ID FROM BDS_CODE_TABLE WHERE STANDARD_CODE = 'TJ0019')
           AND ITEM_VALUE = B.PHAM_FORM) AS PHAM_FORM_DESP,
       B.DEF_USAGE_CODE,
       B.DEF_FREQ_CODE,
       B.DEF_PER_DOSE,
       B.DEF_PER_QUAN,
       (SELECT CONT_VALUE
          FROM PHAM_CUST_DEF_BUSI
         WHERE PHAM_STD_CODE = A.PHAM_STD_CODE AND CONT_TYPE_ID = '8'and area_code = ai.area_code) --口服要标示
           IS_ORAL,
         (SELECT CONT_VALUE
           FROM PHAM_CUST_DEF_BUSI
          WHERE PHAM_STD_CODE = A.PHAM_STD_CODE AND CONT_TYPE_ID = '31'and area_code = ai.area_code) --静配标示
           PIVAS_FLAG,
         (SELECT CONT_VALUE
          FROM PHAM_CUST_DEF_BUSI
         WHERE PHAM_STD_CODE = A.PHAM_STD_CODE AND CONT_TYPE_ID = '3'and area_code = ai.area_code) --皮试药标示
           SKIN_TEST,
         (SELECT CONT_VALUE
           FROM PHAM_CUST_DEF_BUSI
          WHERE PHAM_STD_CODE = A.PHAM_STD_CODE AND CONT_TYPE_ID = '32'and area_code = ai.area_code) --抗肿瘤药标示
           ANTI_Tumour,
         (SELECT CONT_VALUE
          FROM PHAM_CUST_DEF_BUSI
         WHERE PHAM_STD_CODE = A.PHAM_STD_CODE AND CONT_TYPE_ID = 'TJ0055'and area_code = ai.area_code)  --抗菌药物等级
           ANTI_LEVEL,
       ai.area_code,
       A.HIGH_RISK_LEVEL,
       sfpa.cont_value   STOP_FLAG,
       A.PHAM_SIMILAR
  FROM PHAM_BASIC_INFO A
  left join PHAM_ATTRIBUTE_INFO B
  on A.PHAM_STD_CODE = B.PHAM_STD_CODE
  left join  dms.pham_basic_price_detail pd
    on pd.pham_std_code = A.pham_std_code
    left join dms.pham_area_price_rel ai
    on ai.price_level_code = pd.price_level_code
  left join  dms.pham_cust_def_busi sfpa
    on sfpa.pham_std_code = A.pham_std_code
     and sfpa.cont_type_id = 'StopFlagPlan'
     and sfpa.area_code = ai.area_code


/

