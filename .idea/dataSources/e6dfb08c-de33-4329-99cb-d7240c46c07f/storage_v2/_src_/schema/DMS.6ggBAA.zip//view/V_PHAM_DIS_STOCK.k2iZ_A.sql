create view V_PHAM_DIS_STOCK as
  SELECT ppts.pham_std_code,
          ppts.pham_unit,
          ppts.package_factor,
          ppts.org_id,
          ppts.low_limit,
          ppts.unit_name,
          ppts.factor,
          pst.quantity,
          pst.unit,
          --???????
          FLOOR (
               (pst.quantity - ppts.factor * ppts.low_limit)
             / ppts.package_factor)
             AS dis_package_amount,
          --???????
          ppts.pham_unit AS dis_package_unit
     FROM (                                          --???????????????????????
           SELECT pi.pham_std_code,
                  pi.pham_unit,
                  pi.package_factor,
                  ppt.org_id,
                  ppt.low_limit,
                  ppt.unit_name,
                  ppt.factor
             FROM (SELECT pbi.pham_std_code,
                          pbi.pham_unit,
                          1 AS package_factor
                     FROM pham_basic_info pbi
                   UNION
                   SELECT pbi.pham_std_code,
                          pbi.package_unit,
                          pbi.package_factor
                     FROM pham_basic_info pbi
                   UNION
                   SELECT ppu.pham_std_code, ppu.unit_name, ppu.factor
                     FROM pham_pack_unit ppu
                    WHERE ppu.unit_type_code = 10) pi,
                  pham_property_table ppt
            WHERE pi.pham_std_code(+) = ppt.pham_std_code) ppts,
          pham_stock_table pst
    WHERE     ppts.pham_std_code = pst.pham_std_code
          AND pst.dept_code = ppts.org_id


/

