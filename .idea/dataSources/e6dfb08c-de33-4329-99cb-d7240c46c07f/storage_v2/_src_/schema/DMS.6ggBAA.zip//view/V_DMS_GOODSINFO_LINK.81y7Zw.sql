create view V_DMS_GOODSINFO_LINK as
  SELECT '0' AS GOODS_TYPE,
       PBI.PHAM_STD_CODE AS GOODS_CODE,
       PBI.PHAM_CODE AS GOODS_CODE_PRE,

  (SELECT ITEM_NAME
   FROM BDS.BDS_CODE_TABLE_ITEM
   WHERE T_ID IN
       (SELECT ID
        FROM BDS.BDS_CODE_TABLE
        WHERE STANDARD_CODE = 'TJ0023')
     AND ITEM_VALUE = PBI.PHAM_CATE_CODE) AS GOODS_CLASS_NAME,
       PBI.PHAM_CATE_CODE AS GOODS_CLASS,
       NULL GOODS_CATE_CODE,
            PBI.PHAM_NAME AS GOODS_NAME,
            PBI.PHAM_GENERAL_NAME AS GOODS_GENERAL_NAME,
            PBI.PHAM_E_NAME AS GOODS_E_NAME,
            PBI.PHAM_SPEC AS GOODS_SPEC,
            PBI.SVR_SCOPE_TYPE_ID AS SVR_SCOPE_TYPE_ID,
            PBI.SVR_MODE_TYPE_CODE AS SVR_MODE_TYPE_CODE,
            PBI.PHAM_UNIT AS GOODS_UNIT,
            PBI.DOSE_UNIT AS DOSE_UNIT,
            PBI.DOSE_PER_UNIT AS DOSE_PER_UNIT,
            PBI.PACKAGE_UNIT AS PACKAGE_UNIT,
            PBI.PACKAGE_FACTOR AS PACKAGE_SPEC,
            pd.RETAIL_PRICE AS RETAIL_PRICE,
            pd.TRADE_PRICE AS TRADE_PRICE,
            pd.PURCHASE_PRICE AS PURCHASE_PRICE,
            PBI.PHARMACY_FACTORY AS GOODS_FACTORY,
            PBI.QUALIFICATION_CODE AS QUALIFICATION_CODE,
            PBI.ORG_ID_BELONG || NULL AS ORG_ID_BELONG,
                                 PBI.SHOW_IN_ORDER_FLAG AS SHOW_IN_ORDER_FLAG,
                                 PBI.CREATE_TIME AS ENTER_DATE,
                                 PBI.EMP_ID_CREATE AS EMP_ID_CREATE,
                                 PBI.EDIT_TIME AS EDIT_TIME,
                                 PBI.EMP_ID_EDIT AS EMP_ID_EDIT,
                                 PBI.BIDDING_FLAG AS BIDDING_FLAG,
                                 PBI.TEMPORARY_FLAG AS TEMPORARY_FLAG,
                                 PBI.ORG_ID_HOSP AS ORG_ID_HOSP,
                                 sfpa.cont_value AS STOP_FLAG,
                                 sfpu.cont_value AS STOP_FLAG_PUR,
                                 PBI.DELETE_FLAG AS DELETE_FLAG,
                                 PBI.HIGH_RISK_LEVEL AS HIGH_RISK_LEVEL,
                                 PBI.MANAGE_LEVEL AS MANAGY_LEVEL,
                                 PBI.FREE_CHARGE_FLAG AS FREE_CHARGE_FLAG,
                                 PBI.BILL_MODEL_CODE AS BILL_MODEL_CODE,
                                 PBI.PURCHASE_TYPE AS PURCHASE_TYPE,
                                 PBI.NOTE AS NOTE,
                                 NULL GOODS_MODELS,
                                      NULL GOODS_UNIT_PURCHASE_PRICE,
                                           NULL GOODS_UNIT_RETAIL_PRICE,
                                                NULL PRO_AREA,
                                                     NULL BRAND_NAME,
                                                          NULL CLINIC_USE_FLAG,
                                                               NULL APPLY_FLAG,
                                                                    NULL TRACK_LEVEL_CODE,
                                                                         NULL GOODS_GB_CODE,
                                                                              NULL GOODS_ACCOUNTING_CLASS,
                                                                                   NULL GOODS_CALCULATION_CLASS,
                                                                                        NULL MAIN_OR_SUB,
                                                                                             NULL AS GOODS_BAR_CODE,
                                                                                             ai.area_code as area_code
FROM PHAM_BASIC_INFO PBI
left join dms.pham_basic_price_detail pd on pd.pham_std_code = PBI.pham_std_code
left join dms.pham_area_price_rel ai on ai.price_level_code = pd.price_level_code
left join dms.pham_cust_def_busi sfpa on sfpa.pham_std_code = PBI.pham_std_code
and sfpa.cont_type_id = 'StopFlagPlan'
left join dms.pham_cust_def_busi sfpu on sfpu.pham_std_code = PBI.pham_std_code
and sfpu.cont_type_id = 'StopFlagPur'
UNION
SELECT (CASE
            WHEN GBI.SYSTEM_TYPE = '0' THEN '1'
            ELSE '2'
        END) GOODS_TYPE,
       GBI.GOODS_CODE,
       GBI.GOODS_CODE_PRE,

  (SELECT CATE_NAME
   FROM GOODS_INSIDE_CODE_DICT
   WHERE CATE_CODE = GBI.GOODS_CLASS) AS GOODS_CLASS_NAME,
       GBI.GOODS_CLASS,
       GBI.GOODS_CATE_CODE,
       GBI.GOODS_NAME,
       GBI.GOODS_GENERAL_NAME,
       GBI.GOODS_E_NAME,
       GBI.GOODS_SPEC,
       NULL SVR_SCOPE_TYPE_ID,
            NULL SVR_MODE_TYPE_CODE,
                 NULL GOODS_UNIT,
                      NULL DOSE_UNIT,
                           NULL DOSE_PER_UNIT,
                                GBI.PACKAGE_UNIT,
                                GBI.PACKAGE_SPEC,
                                gp.RETAIL_PRICE,
                                gp.TRADE_PRICE,
                                gp.PURCHASE_PRICE,
                                GBI.GOODS_FACTORY,
                                NULL QUALIFICATION_CODE,
                                     GBI.ORG_ID_BELONG,
                                     NULL SHOW_IN_ORDER_FLAG,
                                          GBI.ENTER_DATE,
                                          GBI.EMP_ID_CREATE,
                                          GBI.EDIT_TIME,
                                          GBI.EMP_ID_EDIT,
                                          NULL BIDDING_FLAG,
                                               NULL TEMPORARY_FLAG,
                                                    GBI.ORG_ID_HOSP,
                                                    gp.STOP_FLAG,
                                                    gp.STOP_FLAG_PUR,
                                                    GBI.DELETE_FLAG,
                                                    NULL HIGH_RISK_LEVEL,
                                                         GBI.MANAGY_LEVEL,
                                                         GBI.FREE_CHARGE_FLAG,
                                                         NULL BILL_MODEL_CODE,
                                                              GBI.PURCHASE_TYPE,
                                                              GBI.NOTE,
                                                              GBI.GOODS_MODELS,
                                                              gp.GOODS_UNIT_PURCHASE_PRICE,
                                                              gp.GOODS_UNIT_RETAIL_PRICE,
                                                              GBI.PRO_AREA,
                                                              GBI.BRAND_NAME,
                                                              GBI.CLINIC_USE_FLAG,
                                                              GBI.APPLY_FLAG,
                                                              GBI.TRACK_LEVEL_CODE,
                                                              GBI.GOODS_GB_CODE,
                                                              GBI.GOODS_ACCOUNTING_CLASS,
                                                              GBI.GOODS_CALCULATION_CLASS,
                                                              GBI.MAIN_OR_SUB,

  (SELECT GEI.GOODS_BAR_CODE
   FROM GOODS_EXTENDS_INFO GEI
   WHERE GEI.GOODS_CODE = GBI.GOODS_CODE) AS GOODS_BAR_CODE,
                                                              ai.AREA_CODE
FROM GOODS_BASIC_INFO GBI
LEFT JOIN dms.goods_basic_price_detail gp on gp.goods_code = gbi.goods_code
left join dms.goods_area_price_rel ai on ai.price_level_code = gp.price_level_code


/

