create FUNCTION F_BUSINESSNO_GEN(i_busi_serial_name IN VARCHAR2,
                                            i_opuser           IN VARCHAR2,
                                            i_num              IN number,
                                            i_forcefix IN number)
  RETURN VARCHAR2 IS

  V_COUNT            NUMBER(2);
  V_TAB_CONFIG       BUSINESS_SERIAL_CONFIG%ROWTYPE;
  V_TAB_BUSINESS_NUM BUSINESS_SERIAL_NUM%ROWTYPE;
  V_FIXSQL  VARCHAR2(2000);
  V_FIX_NUM VARCHAR2(20);
  V_OUT_TIME_SEC NUMBER(8):=60; --锁超时时间 单位秒，默认60秒
  V_LOCK_FLAG  NUMBER(8);
  V_CYCLE VARCHAR2(20);
  V_ERR  VARCHAR2(2000);
  V_RETURN_SEQ NUMBER(20);
  V_LOOP_LEFT NUMBER(20);
  V_LOOP_MAX NUMBER(20);
  PRAGMA AUTONOMOUS_TRANSACTION;
BEGIN


  V_RETURN_SEQ := NULL;
  -- WHERE  A.OP_USER = DECODE(i_opuser,NULL,A.OP_USER,i_opuser)
-- 上面的写法可以简单描述逻辑，但是为了防止出现索引使用异常还是不建议这样使用
  IF i_opuser IS NULL THEN
    SELECT COUNT(1)
      INTO V_COUNT
      FROM BUSINESS_SERIAL_NUM A
     WHERE A.BUSI_SERIAL_NAME = i_busi_serial_name;
  ELSE
    SELECT COUNT(1)
      INTO V_COUNT
      FROM BUSINESS_SERIAL_NUM A
     WHERE A.BUSI_SERIAL_NAME = i_busi_serial_name
       AND A.OP_USER = i_opuser;
  END IF;

-- 若存在记录
  IF V_COUNT > 0  THEN
    IF i_opuser IS NULL  THEN
      SELECT *
        INTO V_TAB_BUSINESS_NUM
        FROM BUSINESS_SERIAL_NUM A
       WHERE A.BUSI_SERIAL_NAME = i_busi_serial_name
       FOR UPDATE;
    ELSE
      SELECT *
        INTO V_TAB_BUSINESS_NUM
        FROM BUSINESS_SERIAL_NUM A
       WHERE A.BUSI_SERIAL_NAME = i_busi_serial_name
         AND A.OP_USER = i_opuser
          FOR UPDATE;
    END IF;
  END IF;



     begin

       SELECT *
         INTO V_TAB_CONFIG
         FROM BUSINESS_SERIAL_CONFIG
        WHERE BUSINESS_SERIAL_CONFIG.BUSI_SERIAL_NAME = i_busi_serial_name;

     EXCEPTION
       WHEN NO_DATA_FOUND THEN
          ROLLBACK;
          RETURN '{"err_flag":"1","err_code":"'||sqlcode||'","err_msg":"在配置表BUSINESS_SERIAL_CONFIG中未找到BUSINESSNAME为 '||i_busi_serial_name||' 的配置信息"}';
     end;
    --周期性的属性判断
      if V_TAB_CONFIG.CYCLE IS NULL OR V_TAB_CONFIG.CYCLE = '0' then
         NULL;
      ELSIF V_TAB_CONFIG.CYCLE = 'H' THEN
      SELECT 'H:'||TO_CHAR(sysdate,'hh24') into V_CYCLE from dual;
      ELSIF V_TAB_CONFIG.CYCLE = 'D' THEN
      SELECT 'D:'||TO_CHAR(sysdate,'DD') into V_CYCLE from dual;
       ELSIF V_TAB_CONFIG.CYCLE = 'M' THEN
      SELECT 'M:'||TO_CHAR(sysdate,'MM') into V_CYCLE from dual;
      ELSIF V_TAB_CONFIG.CYCLE = 'Y' THEN
      SELECT 'Y:'||TO_CHAR(sysdate,'YYYY') into V_CYCLE from dual;
      ELSIF V_TAB_CONFIG.CYCLE = 'R' THEN
      SELECT TO_CHAR(V_TAB_CONFIG.CYCLE_MID_MAX) into V_CYCLE from dual;
      ELSE
        NULL;
      end if;

  --超时时间 默认60秒
  V_OUT_TIME_SEC := nvl(V_TAB_CONFIG.Time_Out_Limit,60);

  IF V_TAB_CONFIG.CYCLE = 'R' AND NVL(V_TAB_CONFIG.MID_SEQ_MIN,0) > NVL(V_TAB_CONFIG.CYCLE_MID_MAX,0) THEN
         RAISE_APPLICATION_ERROR(-20004,
                                i_busi_serial_name ||
                                ' 当为周期获取序列时，序列最小值不能大于周期最大限值');

    END IF;

  IF V_COUNT = 0 THEN
    BEGIN


      IF V_TAB_CONFIG.IS_OP_USER = 1 AND i_opuser IS NULL THEN
        RAISE_APPLICATION_ERROR(-20001,
                                i_busi_serial_name ||
                                ' 配置描述序列号必须管理用户，但是在传入参数中并未指定用户');
      END IF;

      V_FIXSQL := V_TAB_CONFIG.FIX_SQL;

      --初始化一条数据
      INSERT into BUSINESS_SERIAL_NUM
        (busi_serial_name,
         mid_seq,
         pre_1,
         pre_2,
         pre_3,
         pre_4,
         pre_5,
         mid_1,
         mid_2,
         mid_3,
         suf_1,
         suf_2,
         suf_3,
         suf_4,
         suf_5,
         mid_seq_len,
         mid_seq_comp_char,
         mid_seq_comp_mode,
         continunity,
         op_user,CYCLE,sn)
      VALUES
        (i_busi_serial_name,
         DECODE(V_TAB_CONFIG.MID_SEQ_MIN, NULL, 1, V_TAB_CONFIG.MID_SEQ_MIN),
         V_TAB_CONFIG.PRE_1,
         V_TAB_CONFIG.PRE_2,
         V_TAB_CONFIG.PRE_3,
         V_TAB_CONFIG.PRE_4,
         V_TAB_CONFIG.PRE_5,
         V_TAB_CONFIG.MID_1,
         V_TAB_CONFIG.MID_2,
         V_TAB_CONFIG.MID_3,
         V_TAB_CONFIG.SUF_1,
         V_TAB_CONFIG.SUF_2,
         V_TAB_CONFIG.SUF_3,
         V_TAB_CONFIG.SUF_4,
         V_TAB_CONFIG.SUF_5,
         V_TAB_CONFIG.MID_SEQ_LEN,
         V_TAB_CONFIG.MID_SEQ_COMP_CHAR,
         V_TAB_CONFIG.MID_SEQ_COMP_MODE,
         V_TAB_CONFIG.CONTINUNITY,
         DECODE(V_TAB_CONFIG.IS_OP_USER, 1, i_opuser, null),V_CYCLE,
         (select decode(max(sn)+1,null,1,max(sn)+1) from BUSINESS_SERIAL_NUM)
         );

    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        RAISE_APPLICATION_ERROR(-20002,
                                '业务序列 ' || i_busi_serial_name ||
                                ' 未配置规范，请在BUSINESS_SERIAL_CONFIG表配置');

        --TOO MANY
    END;
  END IF;


  --准备工作已经就绪，锁定表记录
  IF V_COUNT = 0  THEN
    IF i_opuser IS NULL  THEN
      SELECT *
        INTO V_TAB_BUSINESS_NUM
        FROM BUSINESS_SERIAL_NUM A
       WHERE A.BUSI_SERIAL_NAME = i_busi_serial_name
       FOR UPDATE;
    ELSE
      SELECT *
        INTO V_TAB_BUSINESS_NUM
        FROM BUSINESS_SERIAL_NUM A
       WHERE A.BUSI_SERIAL_NAME = i_busi_serial_name
         AND A.OP_USER = i_opuser
          FOR UPDATE;
    END IF;
  END IF;



  IF V_TAB_CONFIG.CONTINUNITY = 1 THEN

     --先检查锁是否存在
     IF V_TAB_BUSINESS_NUM.LOCK_FLAG = 1 THEN

        --锁存在不一定合理，若业务系统奔溃导致“偿还”步骤并未进行，那么需要进行锁过时判断
        IF V_TAB_BUSINESS_NUM.LOCK_TIME IS NOT NULL AND V_TAB_BUSINESS_NUM.LOCK_TIME < ( sysdate-V_OUT_TIME_SEC/24/60/60) THEN

          --锁已经超时
          --不抛出错误 直接接下来的操作
          NULL;
          ELSE
             RAISE_APPLICATION_ERROR(-20003,
                                '业务序列 ' || i_busi_serial_name ||
                                ' 当前数据正在被锁定使用，请稍后尝试');
          END IF;



       END IF;
     --连续序列的处理比较特别，由于业务序列获取可能存在一次获取多个，但是实际业务可能并未使用完，比如业务系统自己出现异常
     --也不排除开发中并未按照操作规范，获取了并未完全使用的情况，那么在业务系统在获取使用后还需要进行“偿还”模式
     --但是这个“获取”和“偿还”在业务代码里是在业务的前后处理，但是由于使用了自治事物在一个函数完毕必然要COMMIT或者ROLLBACK
     --导致获取序列后与“偿还”步骤失去整体性，所以系统添加LOCK_FLAG状态来弥补这个不完整性
      IF i_opuser IS NULL THEN
         UPDATE BUSINESS_SERIAL_NUM A SET A.LOCK_FLAG = 1,A.LOCK_TIME = SYSDATE WHERE  A.BUSI_SERIAL_NAME = i_busi_serial_name ;
        ELSE
         UPDATE BUSINESS_SERIAL_NUM A SET A.LOCK_FLAG = 1,A.LOCK_TIME = SYSDATE WHERE  A.BUSI_SERIAL_NAME = i_busi_serial_name AND A.OP_USER = i_opuser;
          END IF;

   --注意这里的提交会告诉释放现在的锁，但是已经修改了锁标记，所以其他线程或者进程还是不能正确获得序列，需要等待持有锁的人进行完偿还操作
      COMMIT;
      END IF;

  --若需要强制修复则进行尝试修正

  IF i_forcefix = 1 THEN
     IF V_FIXSQL IS NULL THEN
        SELECT BUSINESS_SERIAL_CONFIG.Fix_Sql INTO V_FIXSQL FROM BUSINESS_SERIAL_CONFIG WHERE BUSINESS_SERIAL_CONFIG.BUSI_SERIAL_NAME=i_busi_serial_name;
       END IF;

       IF V_TAB_CONFIG.FIX_SQL IS  NULL THEN
          --在进行强制修复的时候，必须制定标准数据来源SQL
            RAISE_APPLICATION_ERROR(-20101,
                                '业务序列 ' || i_busi_serial_name ||
                                ' 在进行强制修复的时候，必须指定标准数据来源SQL');
        END IF;

        --动态执行修复SQL，注意这个SQL要能查询出来的是数值数据，不然会抛出错误
        execute immediate V_FIXSQL into V_FIX_NUM;

        BEGIN
          IF V_TAB_BUSINESS_NUM.MID_SEQ <>  TO_NUMBER(V_FIX_NUM)+1  THEN
              --注意这里需要按用户修改 若需要的话
                IF i_opuser IS NULL THEN
                    UPDATE BUSINESS_SERIAL_NUM A
                    SET A.MID_SEQ = TO_NUMBER(V_FIX_NUM)+1
                   WHERE A.BUSI_SERIAL_NAME = i_busi_serial_name;
                ELSE
                  UPDATE BUSINESS_SERIAL_NUM A
                    SET A.MID_SEQ = TO_NUMBER(V_FIX_NUM)+1
                   WHERE A.BUSI_SERIAL_NAME = i_busi_serial_name
                   AND A.OP_USER = i_opuser;

                END IF;
            END IF;

          EXCEPTION WHEN OTHERS THEN
            RAISE_APPLICATION_ERROR(-20102,
                                '业务序列 ' || i_busi_serial_name ||
                                ' 在进行强制修复的时候，准数据来源SQL查询出来的数据必须为数值数据');
          END;

    END IF;
   -- select sysdate-3/24/60 from dual
   if  V_TAB_CONFIG.CYCLE IN ('H','D','M','Y') then
       if V_TAB_BUSINESS_NUM.CYCLE IS NOT NULL AND V_TAB_BUSINESS_NUM.CYCLE <> V_CYCLE  then
     --重置序列号
         --由于此模式下返回会重新计数 所以MID_SEQ 需要为I_NUM+1而不是1，因为1本次会返回，下次使用的数值应该为2
          IF i_opuser IS NULL THEN
               UPDATE BUSINESS_SERIAL_NUM A SET A.CYCLE_BAK=A.CYCLE,A.MID_SEQ_BAK=A.MID_SEQ, A.MID_SEQ =  (NVL(V_TAB_CONFIG.MID_SEQ_MIN,1)+NVL(I_NUM,1)),A.CYCLE=V_CYCLE,A.UPDATE_TIME=SYSDATE WHERE A.BUSI_SERIAL_NAME = i_busi_serial_name;
          ELSE
               UPDATE BUSINESS_SERIAL_NUM A SET A.CYCLE_BAK=A.CYCLE,A.MID_SEQ_BAK=A.MID_SEQ, A.MID_SEQ =  (NVL(V_TAB_CONFIG.MID_SEQ_MIN,1)+NVL(I_NUM,1)),A.CYCLE=V_CYCLE,A.UPDATE_TIME=SYSDATE WHERE A.BUSI_SERIAL_NAME = i_busi_serial_name AND A.OP_USER = i_opuser;
          END IF;
          V_RETURN_SEQ := NVL(V_TAB_CONFIG.MID_SEQ_MIN,1);
       ELSE
            IF i_opuser IS NULL THEN
           UPDATE BUSINESS_SERIAL_NUM A SET A.MID_SEQ =  A.MID_SEQ+NVL(I_NUM,1),A.UPDATE_TIME=SYSDATE WHERE A.BUSI_SERIAL_NAME = i_busi_serial_name;
            ELSE
                 UPDATE BUSINESS_SERIAL_NUM A SET A.MID_SEQ =  A.MID_SEQ+NVL(I_NUM,1),A.UPDATE_TIME=SYSDATE WHERE A.BUSI_SERIAL_NAME = i_busi_serial_name AND A.OP_USER = i_opuser;
            END IF;
       end if;


   end if;

    if V_TAB_CONFIG.CYCLE = 'R' THEN
         --若当前获取请求超过最大值
          V_LOOP_LEFT := V_TAB_BUSINESS_NUM.MID_SEQ+I_NUM;

          V_LOOP_LEFT:=mod(V_LOOP_LEFT,TO_NUMBER(V_CYCLE));
          if V_LOOP_LEFT = 0 then
             V_LOOP_LEFT := TO_NUMBER(V_CYCLE);
          end if;
          IF V_LOOP_LEFT > 0 THEN
             IF i_opuser IS NULL THEN
               UPDATE BUSINESS_SERIAL_NUM A SET A.CYCLE_BAK=A.CYCLE,A.MID_SEQ_BAK=A.MID_SEQ, A.MID_SEQ = V_LOOP_LEFT,A.CYCLE=V_CYCLE,A.UPDATE_TIME=SYSDATE WHERE A.BUSI_SERIAL_NAME = i_busi_serial_name;
             ELSE
               UPDATE BUSINESS_SERIAL_NUM A SET A.CYCLE_BAK=A.CYCLE,A.MID_SEQ_BAK=A.MID_SEQ, A.MID_SEQ =  V_LOOP_LEFT,A.CYCLE=V_CYCLE,A.UPDATE_TIME=SYSDATE WHERE A.BUSI_SERIAL_NAME = i_busi_serial_name AND A.OP_USER = i_opuser;
              END IF;
            END IF;
         END IF;




    IF V_TAB_CONFIG.CYCLE IS NULL OR V_TAB_CONFIG.CYCLE NOT IN ('H','D','M','Y','R')  THEN
      IF i_opuser IS NULL THEN
           UPDATE BUSINESS_SERIAL_NUM A SET A.MID_SEQ =  A.MID_SEQ+NVL(I_NUM,1),A.UPDATE_TIME=SYSDATE WHERE A.BUSI_SERIAL_NAME = i_busi_serial_name;
      ELSE
           UPDATE BUSINESS_SERIAL_NUM A SET A.MID_SEQ =  A.MID_SEQ+NVL(I_NUM,1),A.UPDATE_TIME=SYSDATE WHERE A.BUSI_SERIAL_NAME = i_busi_serial_name AND A.OP_USER = i_opuser;
      END IF;
    END IF;

      IF V_RETURN_SEQ IS NULL THEN
       V_RETURN_SEQ := V_TAB_BUSINESS_NUM.MID_SEQ;
      END IF;

  --告知java端当前处理可能存在循环的最大数值，若为-1那么不存在循环
    V_LOOP_MAX:= -1;
    IF V_LOOP_LEFT is not null THEN
      V_LOOP_MAX:=NVL(V_TAB_CONFIG.CYCLE_MID_MAX,-1);
      END IF;

    COMMIT;

    RETURN '{"err_flag":"0","sn":"'||V_TAB_BUSINESS_NUM.Sn||'"
    ,"busi_serial_name":"'||i_busi_serial_name||'"
    ,"op_user":"'||V_TAB_BUSINESS_NUM.OP_USER||'"
    ,"pre_1":"'||V_TAB_BUSINESS_NUM.PRE_1||'"
    ,"pre_2":"'||V_TAB_BUSINESS_NUM.PRE_2||'"
    ,"pre_3":"'||V_TAB_BUSINESS_NUM.PRE_3||'"
    ,"pre_4":"'||V_TAB_BUSINESS_NUM.PRE_4||'"
    ,"pre_5":"'||V_TAB_BUSINESS_NUM.PRE_5||'"
    ,"mid_1":"'||V_TAB_BUSINESS_NUM.Mid_1||'"
    ,"mid_2":"'||V_TAB_BUSINESS_NUM.Mid_2||'"
    ,"mid_3":"'||V_TAB_BUSINESS_NUM.Mid_3||'"
    ,"suf_1":"'||V_TAB_BUSINESS_NUM.Suf_1||'"
    ,"suf_2":"'||V_TAB_BUSINESS_NUM.Suf_2||'"
    ,"suf_3":"'||V_TAB_BUSINESS_NUM.Suf_3||'"
    ,"suf_4":"'||V_TAB_BUSINESS_NUM.Suf_4||'"
    ,"suf_5":"'||V_TAB_BUSINESS_NUM.Suf_5||'"
    ,"continunity":"'||V_TAB_CONFIG.Continunity||'"
    ,"mid_seq":"'||V_RETURN_SEQ||'"
    ,"mid_seq_len":"'||V_TAB_BUSINESS_NUM.Mid_Seq_Len||'"
    ,"mid_seq_comp_char":"'||V_TAB_BUSINESS_NUM.Mid_Seq_Comp_Char||'"
    ,"mid_seq_comp_mode":"'||V_TAB_BUSINESS_NUM.Mid_Seq_Comp_Mode||'"
    ,"numcount":"'||I_NUM||'"
    ,"loopmax":"'||V_LOOP_MAX||'"
    ,"midseqmin":"'||NVL(V_TAB_CONFIG.MID_SEQ_MIN,1)||'"

    }';

EXCEPTION
 WHEN OTHERS THEN
   ROllBACK;

   --出现错误后需要回滚锁定状态,当然要除了没有锁所抛出的异常
   --20100 之后出现的错误都是已经持有锁后锁出现的错误
   IF sqlcode < -20100 THEN
       IF i_opuser IS NULL THEN
         UPDATE BUSINESS_SERIAL_NUM A SET A.LOCK_FLAG = 0,A.LOCK_TIME = NULL WHERE  A.BUSI_SERIAL_NAME = i_busi_serial_name ;
        ELSE
         UPDATE BUSINESS_SERIAL_NUM A SET A.LOCK_FLAG = 0,A.LOCK_TIME = NULL WHERE  A.BUSI_SERIAL_NAME = i_busi_serial_name AND A.OP_USER = i_opuser;
          END IF;
      COMMIT;
     END IF;


    DBMS_OUTPUT.put_line('获取业务数据错误 '||sqlerrm);

    RETURN '{"err_flag":"1","err_code":"'||sqlcode||'","err_msg":"'||replace (sqlerrm,'"','''')||'"}';

END F_BUSINESSNO_GEN;



/

