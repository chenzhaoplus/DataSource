create FUNCTION F_PHAM_INVENTORY_MODIFY(V_DEPT_CODE VARCHAR2,
                                                         STARTNUM    NUMBER,
                                                         ENDNUM      NUMBER)
  RETURN VARCHAR2 IS
  PRAGMA AUTONOMOUS_TRANSACTION;

  v_tempDept number(10); --校验药房编码是否存在的临时变量
  v_tempStart number(10);--检验开始结存是否存在的临时变量
  v_tempEnd number(10);  --检验结束结存是否存在的临时变量

  --结构体，用于存储上一条出入库子表流水
  S_PHAM_STD_CODE    DMS.PHAM_BASIC_INFO.PHAM_STD_CODE%TYPE; --药品编码
  S_PHAM_NAME        DMS.PHAM_BASIC_INFO.PHAM_NAME%TYPE; --药品名称
  S_INOUT_SUB_NUMBER DMS.PHAM_DOCU_DETAIL.INOUT_SUB_NUMBER%TYPE; --出入库子表ID
  S_SQUANTITY        DMS.PHAM_STOCK_SNAPSHOT_DETAIL.SQUANTITY%TYPE; --上期结存
  S_INVENTORY        DMS.PHAM_DOCU_DETAIL.INVENTORY%TYPE; --当前出入库结存
  S_BASE_QUANTITY    DMS.PHAM_DOCU_DETAIL.BASE_QUANTITY%TYPE; --当前出入库数量
  S_EQUANTITY        DMS.PHAM_STOCK_SNAPSHOT_DETAIL.SQUANTITY%TYPE; --本期结存

  --结构体，用于存储当前出入库子表流水
  V_PHAM_STD_CODE    DMS.PHAM_BASIC_INFO.PHAM_STD_CODE%TYPE; --药品编码
  V_PHAM_NAME        DMS.PHAM_BASIC_INFO.PHAM_NAME%TYPE; --药品名称
  V_INOUT_SUB_NUMBER DMS.PHAM_DOCU_DETAIL.INOUT_SUB_NUMBER%TYPE; --出入库子表ID
  V_SQUANTITY        DMS.PHAM_STOCK_SNAPSHOT_DETAIL.SQUANTITY%TYPE; --上期结存
  V_INVENTORY        DMS.PHAM_DOCU_DETAIL.INVENTORY%TYPE; --当前出入库结存
  V_BASE_QUANTITY    DMS.PHAM_DOCU_DETAIL.BASE_QUANTITY%TYPE; --当前出入库数量
  V_EQUANTITY        DMS.PHAM_STOCK_SNAPSHOT_DETAIL.SQUANTITY%TYPE; --本期结存

  --定义游标
  TYPE INVENTORY_MODIFY IS REF CURSOR;
  CROW INVENTORY_MODIFY;

BEGIN

  S_PHAM_STD_CODE := '';--第一次给药品编码赋值

  SELECT COUNT(1) INTO v_tempDept FROM dms.pham_org o WHERE o.org_id = V_DEPT_CODE;
  select COUNT(1) into v_tempStart from pham_stock_snapshot where snapshot_id = startNum;
  select COUNT(1) into v_tempEnd from pham_stock_snapshot where snapshot_id = endNum;

  --错误信息返回--
  if  v_tempDept < 1 then
      return '未找到对应药房代码' || V_DEPT_CODE ;
  end if;

  if v_tempStart < 1   then

     return '未找到对应结存信息' || startNum;
  end if;

  if v_tempEnd < 1  then

     return '未找到对应结存信息'  || endNum;
  end if;
  --错误信息返回--

  --开启游标
  OPEN CROW FOR

  --查询两个结存时间之间的出入库子表流水，查询流水时顺便把上期和本期的结存数也查询出来，并且按照药品编码和出入库子表id排序。
    SELECT B.PHAM_STD_CODE,
           I.PHAM_NAME,
           B.INOUT_SUB_NUMBER,
           NVL((SELECT SUM(D.SQUANTITY)
                 FROM DMS.PHAM_STOCK_SNAPSHOT_DETAIL D
                WHERE D.SNAPSHOT_ID = STARTNUM
                  AND D.DEPT_CODE = V_DEPT_CODE
                  AND D.PHAM_STD_CODE = B.PHAM_STD_CODE),
               0) STQUANTITY,
           B.INVENTORY,
           DECODE(A.PHAM_IO_SIGN, '1', B.BASE_QUANTITY, 0 - B.BASE_QUANTITY),

           NVL((SELECT SUM(D.SQUANTITY)
                 FROM DMS.PHAM_STOCK_SNAPSHOT_DETAIL D
                WHERE D.SNAPSHOT_ID = ENDNUM
                  AND D.DEPT_CODE = V_DEPT_CODE
                  AND D.PHAM_STD_CODE = B.PHAM_STD_CODE),
               0) ETQUANTITY
      FROM DMS.PHAM_DOCU_HEAD   A,
           DMS.PHAM_DOCU_DETAIL B,
           DMS.PHAM_BASIC_INFO  I
     WHERE A.PHAM_IO_DATE BETWEEN
           (SELECT SNAPSHOT_TIME
              FROM PHAM_STOCK_SNAPSHOT
             WHERE SNAPSHOT_ID = STARTNUM) AND
           (SELECT SNAPSHOT_TIME
              FROM PHAM_STOCK_SNAPSHOT
             WHERE SNAPSHOT_ID = ENDNUM)
       AND A.INOUT_NUMBER = B.INOUT_NUMBER
       AND A.DEPT_CODE = V_DEPT_CODE
       AND B.PHAM_STD_CODE = I.PHAM_STD_CODE

     GROUP BY B.PHAM_STD_CODE,
              B.INOUT_SUB_NUMBER,
              A.PHAM_IO_SIGN,
              B.BASE_QUANTITY,
              I.PHAM_NAME,
              B.INVENTORY
     ORDER BY PHAM_STD_CODE, INOUT_SUB_NUMBER;


  --循环获取游标
  LOOP
    FETCH CROW
      INTO V_PHAM_STD_CODE,
           V_PHAM_NAME,
           V_INOUT_SUB_NUMBER,
           V_SQUANTITY,
           V_INVENTORY,
           V_BASE_QUANTITY,
           V_EQUANTITY;
    EXIT WHEN CROW%NOTFOUND;

    --当前游标的记录中 药品编码和上一条药品编码不相时，认为是一条新的药品记录
    IF V_PHAM_STD_CODE != S_PHAM_STD_CODE THEN

      --给上一条流水变量赋初值
      S_PHAM_STD_CODE    := V_PHAM_STD_CODE;
      S_PHAM_NAME        := V_PHAM_NAME;
      S_INOUT_SUB_NUMBER := V_INOUT_SUB_NUMBER;
      S_SQUANTITY        := V_SQUANTITY;
      S_INVENTORY        := V_INVENTORY;
      S_BASE_QUANTITY    := V_BASE_QUANTITY;
      S_EQUANTITY        := V_EQUANTITY;

      --修改当前出入库流水结存为 上期结存
      UPDATE DMS.PHAM_DOCU_DETAIL D
         SET D.INVENTORY = S_SQUANTITY
       WHERE D.INOUT_SUB_NUMBER = V_INOUT_SUB_NUMBER;
    ELSE
      --修改当前出入库流水结存为上一条 流水的结存+出入库数量
      UPDATE DMS.PHAM_DOCU_DETAIL D
         SET D.INVENTORY = S_INVENTORY + S_BASE_QUANTITY
       WHERE D.INOUT_SUB_NUMBER = V_INOUT_SUB_NUMBER;

      --给上一条流水变量赋 值为当前出入库流水
      S_PHAM_STD_CODE    := V_PHAM_STD_CODE;
      S_PHAM_NAME        := V_PHAM_NAME;
      S_INOUT_SUB_NUMBER := V_INOUT_SUB_NUMBER;
      S_SQUANTITY        := V_SQUANTITY;
      S_INVENTORY        := S_INVENTORY + S_BASE_QUANTITY;
      S_BASE_QUANTITY    := V_BASE_QUANTITY;
      S_EQUANTITY        := V_EQUANTITY;
    END IF;

  END LOOP;

  CLOSE CROW;

  COMMIT;

  RETURN '成功修改' || V_DEPT_CODE ||' 结存数量' ;

END;



/

