create view V_PHAM_INFO_ALL as
  SELECT DISTINCT A.PHAM_STD_CODE,
                A.PHAM_CATE_CODE,
                DECODE(A.PHAM_CATE_CODE, '1', 'A', '2', 'B', '3', 'N', NULL) PRICE_CLASS,
                A.PHAM_CODE,
                A.PHAM_NAME,
                A.PHAM_GENERAL_NAME,
                A.PHAM_E_NAME,
                A.PHAM_SPEC,
                A.PHAM_UNIT,
                A.DOSE_UNIT,
                A.DOSE_PER_UNIT,
                A.PACKAGE_UNIT,
                A.PACKAGE_FACTOR,
                pd.RETAIL_PRICE,
                pd.TRADE_PRICE,
                pd.PURCHASE_PRICE,
                TO_CHAR(ROUND(pd.RETAIL_PRICE / A.PACKAGE_FACTOR, 4), 'FM999999.0000') AS PHAM_PRICE,
                A.PHARMACY_FACTORY,
                A.MANAGE_LEVEL,
                B.PRICE_PROPERTY,
                B.TOXICOLOGY_PROPERTY,
                B.PHAM_FORM,
                B.DEF_USAGE_CODE,
                B.DEF_FREQ_CODE,
                B.DEF_PER_DOSE,
                B.DEF_PER_QUAN,

  (SELECT CONT_VALUE
   FROM PHAM_CUST_DEF_CONT
   WHERE PHAM_STD_CODE = A.PHAM_STD_CODE
     AND CONT_TYPE_ID = '3') SKIN_TEST,
                A.HIGH_RISK_LEVEL,
                C.ANTI_LEVEL,
                sfpa.cont_value STOP_FLAG,
                A.PHAM_SIMILAR,
                D.INPUT_CODE,
                D.STD_INDICATOR,
                PCDC.CONT_TYPE_ID,
                ai.area_code
FROM dms.PHAM_BASIC_INFO A
left join dms.PHAM_ALIA_DICT D on D.PHAM_CODE = A.PHAM_STD_CODE
left join dms.PHAM_ATTRIBUTE_INFO B on B.PHAM_STD_CODE = D.PHAM_CODE
left join bds.BDS_PHAM_LEVEL_INFO C on C.PHAM_STD_CODE = D.PHAM_CODE
left join
  (SELECT PHAM_STD_CODE,
          CONT_TYPE_ID
   FROM dms.PHAM_CUST_DEF_CONT
   WHERE 1 = 1
     AND CONT_TYPE_ID IN ('9',
                          '10')) PCDC on D.PHAM_CODE = PCDC.PHAM_STD_CODE
left join dms.pham_basic_price_detail pd on pd.pham_std_code = A.pham_std_code
left join dms.pham_area_price_rel ai on ai.price_level_code = pd.price_level_code
left join dms.pham_cust_def_busi sfpa on sfpa.pham_std_code = A.pham_std_code
and sfpa.cont_type_id = 'StopFlagPlan'


/

