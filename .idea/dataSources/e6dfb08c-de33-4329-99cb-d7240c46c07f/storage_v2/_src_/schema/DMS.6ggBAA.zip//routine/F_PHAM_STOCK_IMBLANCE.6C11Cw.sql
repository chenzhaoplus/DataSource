create function F_PHAM_STOCK_IMBLANCE(v_dept_code varchar2,startNum number,endNum number)
return varchar2 is
pragma autonomous_transaction;

  v_snap_sub_id   number(14);
  v_stocks_sub_id number(14);

  v_startDate date;
  v_endDate date;

  type stock_imblance is ref cursor;
  crow  stock_imblance;
  v_pham_std_code pham_basic_info.pham_std_code%type;
  ce   number(14);

begin


  select snapshot_time into v_startDate from pham_stock_snapshot where snapshot_id = startNum;
  select snapshot_time into v_endDate from pham_stock_snapshot where snapshot_id = endNum;

  if v_startDate is null or v_endDate is null then

     return v_dept_code;
  end if;


  open crow  for
    select t.pham_std_code, (qcQ + ruQ + cuQ + qmQ) ce
      from (

            select t.pham_std_code,
                    nvl(qc.qcQ, 0) qcQ,
                    nvl(ru.ruQ, 0) ruQ,
                    nvl(cu.cuQ, 0) cuQ,
                    nvl(qm.qmQ, 0) qmQ
              from (select *
                       from pham_property_table
                      where org_id = v_dept_code) t

              left join

             (select pham_std_code, sum(squantity) qcQ
                from dms.pham_stock_snapshot_detail
               where snapshot_id = startNum
                 and dept_code =v_dept_code
               group by pham_std_code) qc

                on t.pham_std_code = qc.pham_std_code

              left join (

                         select d.pham_std_code, sum(d.base_quantity) ruQ
                           from dms.pham_docu_head h, dms.pham_docu_detail d
                          where h.inout_number = d.inout_number
                            and dept_code =v_dept_code
                            and h.pham_io_sort not in('3001','1012')
                            and h.pham_io_sign = '1'
                            and h.inout_status = '1'
                            and h.pham_io_date between
                                v_startDate and
                                v_endDate
                          group by d.pham_std_code) ru
                on t.pham_std_code = ru.pham_std_code

              left join (select d.pham_std_code, 0 - sum(d.base_quantity) cuQ
                           from dms.pham_docu_head h, dms.pham_docu_detail d
                          where h.inout_number = d.inout_number
                            and dept_code =v_dept_code
                            and h.pham_io_sort not in('3001','1012')
                            and h.pham_io_sign = '0'
                            and h.inout_status = '1'
                            and h.pham_io_date between
                                v_startDate and
                                v_endDate
                          group by d.pham_std_code) cu
                on t.pham_std_code = cu.pham_std_code

              left join

             (select pham_std_code, 0 - sum(squantity) qmQ
                from dms.pham_stock_snapshot_detail
               where snapshot_id = endNum
                 and dept_code =v_dept_code
               group by pham_std_code) qm

                on t.pham_std_code = qm.pham_std_code) t
      left join pham_basic_info i
        on t.pham_std_code = i.pham_std_code
     where (qcQ + ruQ + cuQ + qmQ) <> 0;




 loop
fetch crow into v_pham_std_code,ce;
exit when crow%notfound;

    select max(stock_sub_id)
      into v_snap_sub_id
      from pham_stock_snapshot_detail b
     where snapshot_id = endNum
       and dept_code =v_dept_code
       and pham_std_code = v_pham_std_code
       and (squantity + ce) >= 0;

    select max(stock_sub_id)
      into v_stocks_sub_id
      from pham_stock_table_sub b, pham_stock_table m
     where b.stock_id = m.stock_id
       and m.dept_code =v_dept_code
       and m.pham_std_code = v_pham_std_code
       and (b.quantity + ce) >= 0;

    if v_snap_sub_id is not null then

      update pham_stock_snapshot_detail s
         set squantity   = squantity + ce,
             s.mquantity = s.mquantity + ce
       where snapshot_id = endNum
         and dept_code =v_dept_code
         and pham_std_code =v_pham_std_code
         and stock_sub_id = v_snap_sub_id;

      insert into PHAM_STOCK_IMBLANCE_LOG
      values
        (dms.f_sequence_gen('PHAM_STOCK_IMBLANCE_LOG', 1),
         v_pham_std_code,
         ce,
         '1',
         sysdate,
         '1',
       v_dept_code);

    else

      insert into PHAM_STOCK_IMBLANCE_LOG
      values
        (dms.f_sequence_gen('PHAM_STOCK_IMBLANCE_LOG', 1),
         v_pham_std_code,
         ce,
         '0',
         sysdate,
         '1',
        v_dept_code);

    end if;


    if v_stocks_sub_id is not null then
      update pham_stock_table_sub ts
         set ts.quantity = ts.quantity + ce
       where stock_sub_id = v_stocks_sub_id;

      insert into PHAM_STOCK_IMBLANCE_LOG
      values
        (dms.f_sequence_gen('PHAM_STOCK_IMBLANCE_LOG', 1),
         v_pham_std_code,
         ce,
         '1',
         sysdate,
         '0',
       v_dept_code);

    else

      insert into PHAM_STOCK_IMBLANCE_LOG
      values
        (dms.f_sequence_gen('PHAM_STOCK_IMBLANCE_LOG', 1),
         v_pham_std_code,
         ce,
         '0',
         sysdate,
         '0',
        v_dept_code);

    end if; 
 

end loop;
--????
close crow;


update pham_stock_table m set quantity = (select nvl( sum(quantity) ,0) from pham_stock_table_sub where stock_id = m.stock_id) 
where dept_code =v_dept_code;

update pham_stock_table m set quantity = 0 where quantity < 0 or quantity is null and dept_code = v_dept_code;


COMMIT;

return v_dept_code;

end;



/

