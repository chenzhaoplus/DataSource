create view INVENTORY_SUB_AND_PHY_QUERY as
  SELECT P.PIPQ,
          P.PISQ,
          P.PHAM_STD_CODE,
          P.INVENTORY_ID
     FROM (SELECT IP.PIPQ,
                  SP.PISQ,
                  SP.pham_std_code,
                  SP.INVENTORY_ID
             FROM (SELECT pis.quantity AS PISQ,
                          pis.pham_batch_number AS pham_batch_number,
                          (CASE
                              WHEN ppt.batch_number_manager_flag IS NULL
                              THEN
                                 '0'
                              ELSE
                                 ppt.batch_number_manager_flag
                           END)
                             AS batch_number_manager_flag,
                          pis.pham_std_code,
                          pis.INVENTORY_ID
                     FROM pham_inventory_sub pis
                          LEFT JOIN PHAM_PROPERTY_TABLE ppt
                             ON pis.pham_std_code = ppt.pham_std_code) SP
                  LEFT JOIN
                  (  SELECT SUM (pip.quantity) AS PIPQ,
                            NULL AS pham_batch_number,
                            ppt.batch_number_manager_flag
                               AS batch_number_manager_flag,
                            pip.pham_std_code,
                            pip.INVENTORY_ID
                       FROM pham_inventory_physical pip
                            LEFT JOIN PHAM_PROPERTY_TABLE ppt
                               ON pip.pham_std_code = ppt.pham_std_code
                      WHERE (   ppt.batch_number_manager_flag IS NULL
                             OR ppt.batch_number_manager_flag = '0')
                   GROUP BY pip.pham_std_code,
                            ppt.batch_number_manager_flag,
                            pip.INVENTORY_ID
                   UNION
                     SELECT SUM (pip.quantity) AS PIPQ,
                            pham_batch_number,
                            ppt.batch_number_manager_flag
                               AS batch_number_manager_flag,
                            pip.pham_std_code,
                            pip.INVENTORY_ID
                       FROM pham_inventory_physical pip
                            LEFT JOIN PHAM_PROPERTY_TABLE ppt
                               ON pip.pham_std_code = ppt.pham_std_code
                      WHERE (ppt.batch_number_manager_flag = '1')
                   GROUP BY pip.pham_std_code,
                            pip.pham_batch_number,
                            ppt.batch_number_manager_flag,
                            pip.INVENTORY_ID) IP
                     ON     SP.INVENTORY_ID = IP.INVENTORY_ID
                        AND SP.pham_std_code = IP.pham_std_code
            WHERE SP.batch_number_manager_flag = '0'
           UNION
           SELECT IP.PIPQ,
                  SP.PISQ,
                  SP.pham_std_code,
                  SP.INVENTORY_ID
             FROM (SELECT pis.quantity AS PISQ,
                          PHAM_BATCH_NUMBER AS pham_batch_number,
                          (CASE
                              WHEN ppt.batch_number_manager_flag IS NULL
                              THEN
                                 '0'
                              ELSE
                                 ppt.batch_number_manager_flag
                           END)
                             AS batch_number_manager_flag,
                          pis.pham_std_code,
                          pis.INVENTORY_ID
                     FROM pham_inventory_sub pis
                          LEFT JOIN PHAM_PROPERTY_TABLE ppt
                             ON pis.pham_std_code = ppt.pham_std_code) SP
                  LEFT JOIN
                  (  SELECT SUM (pip.quantity) AS PIPQ,
                            NULL AS pham_batch_number,
                            ppt.batch_number_manager_flag
                               AS batch_number_manager_flag,
                            pip.pham_std_code,
                            pip.INVENTORY_ID
                       FROM pham_inventory_physical pip
                            LEFT JOIN PHAM_PROPERTY_TABLE ppt
                               ON pip.pham_std_code = ppt.pham_std_code
                      WHERE (   ppt.batch_number_manager_flag IS NULL
                             OR ppt.batch_number_manager_flag = '0')
                   GROUP BY pip.pham_std_code,
                            ppt.batch_number_manager_flag,
                            pip.INVENTORY_ID
                   UNION
                     SELECT SUM (pip.quantity) AS PIPQ,
                            pham_batch_number,
                            ppt.batch_number_manager_flag
                               AS batch_number_manager_flag,
                            pip.pham_std_code,
                            pip.INVENTORY_ID
                       FROM pham_inventory_physical pip
                            LEFT JOIN PHAM_PROPERTY_TABLE ppt
                               ON pip.pham_std_code = ppt.pham_std_code
                      WHERE (ppt.batch_number_manager_flag = '1')
                   GROUP BY pip.pham_std_code,
                            pip.pham_batch_number,
                            ppt.batch_number_manager_flag,
                            pip.INVENTORY_ID) IP
                     ON     SP.INVENTORY_ID = IP.INVENTORY_ID
                        AND SP.pham_std_code = IP.pham_std_code
                        AND SP.pham_batch_number = IP.pham_batch_number
            WHERE SP.batch_number_manager_flag = '1') P


/

