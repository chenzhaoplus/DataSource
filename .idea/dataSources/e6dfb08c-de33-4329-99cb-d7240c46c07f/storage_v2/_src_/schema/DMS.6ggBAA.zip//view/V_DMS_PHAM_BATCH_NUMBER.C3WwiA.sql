create view V_DMS_PHAM_BATCH_NUMBER as
  select "PHAM_STD_CODE",
       "PHAM_FACTORY_NAME",
       "PHAM_BATCH_NUMBER",
       "EXPIRE_DATE",
       "DEPT_CODE"
from
  (select t.pham_std_code,
          t.pham_factory_name,
          t.pham_batch_number,
          t.expire_date,
          t.dept_code
   from dms.pham_stock_snapshot_detail t
   group by t.pham_std_code,
            t.pham_factory_name,
            t.pham_batch_number,
            t.expire_date,
            t.dept_code
   UNION select s.pham_std_code,
                s.pham_factory_name,
                t.pham_batch_number,
                t.expire_date,
                s.dept_code
   from dms.pham_stock_table s,
        dms.pham_stock_table_sub t
   where t.stock_id = s.stock_id)
group by pham_std_code,
         pham_factory_name,
         pham_batch_number,
         expire_date,
         dept_code


/

