create procedure PHARM_STOCK_SNAP_PROC
  as
  
     snapshot_id  number(14);

  begin
      snapshot_id := dms.f_sequence_gen('PHAM_STOCK_SNAPSHOT',1);

      insert into dms.PHAM_STOCK_SNAPSHOT values(snapshot_id,sysdate,trunc(sysdate));

      insert into dms.pham_stock_snapshot_detail 

      select snapshot_id , s.stock_id,b.stock_sub_id,
 s.dept_code,s.pham_std_code,i.pham_code,i.pham_name,i.pham_spec,s.pham_factory_name,s.quantity as mquantity, s.unit,
  b.pham_batch_number,b.expire_date,b.quantity as SQUANTITY,b.pack_quantity_unit,b.factor,b.factor_des,b.note,i.pham_cate_code,i.pham_unit,i.package_unit,i.package_factor,
  i.retail_price,i.trade_price,i.purchase_price
 from dms.pham_stock_table s,dms.pham_stock_table_sub b,dms.pham_basic_info i where  s.stock_id = b.stock_id and s.pham_std_code = i.pham_std_code;

     commit;


  end;



/

