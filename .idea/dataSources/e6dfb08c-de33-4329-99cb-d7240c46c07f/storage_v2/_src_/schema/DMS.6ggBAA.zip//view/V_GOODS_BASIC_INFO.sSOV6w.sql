create view V_GOODS_BASIC_INFO as
  SELECT A.GOODS_CODE,
       A.GOODS_CLINIC_TYPE_CODE AS GOODS_CODE_PRE,
       A.GOODS_CLASS,
       'I' PRICE_CLASS,

  (SELECT CATE_NAME
   FROM DMS.GOODS_INSIDE_CODE_DICT
   WHERE CATE_CODE = A.GOODS_CLASS) AS GOODS_CLASS_NAME,
           A.GOODS_CATE_CODE,
           A.GOODS_NAME,

  (SELECT MAX (INPUT_CODE)
   FROM DMS.GOODS_ALIA_DICT
   WHERE GOODS_CODE = A.GOODS_CODE
     AND STD_INDICATOR = 0) AS INPUT_CODE,
           A.GOODS_GENERAL_NAME,
           A.GOODS_E_NAME,
           A.GOODS_SPEC,
           A.GOODS_MODELS,
           A.GOODS_UNIT,
           A.PACKAGE_UNIT,
           A.PACKAGE_SPEC,
           gbp.RETAIL_PRICE,
           gbp.TRADE_PRICE,
           gbp.PURCHASE_PRICE,
           gbp.GOODS_UNIT_PURCHASE_PRICE,
           gbp.GOODS_UNIT_RETAIL_PRICE,
           A.GOODS_FACTORY,
           A.PRO_AREA,
           A.BRAND_NAME,
           gbp.STOP_FLAG,
           A.Clinic_Use_Flag,
           gap.area_code
FROM DMS.GOODS_BASIC_INFO A
left join dms.goods_basic_price_detail gbp on gbp.goods_code = A.goods_code
left join dms.goods_area_price_rel gap on gap.price_level_code = gbp.price_level_code
WHERE A.SYSTEM_TYPE = 0



/

