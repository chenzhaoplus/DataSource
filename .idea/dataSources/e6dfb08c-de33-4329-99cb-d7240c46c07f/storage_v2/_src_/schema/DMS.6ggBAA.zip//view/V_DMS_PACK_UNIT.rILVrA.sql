create view V_DMS_PACK_UNIT as
  SELECT '0' AS GOODS_TYPE,                               --?? 0????1????2???
          ppu.SERIAL_NO AS SERIAL_NO,                                   --??ID
          ppu.PHAM_STD_CODE AS GOODS_ID,                                --??ID
          ppu.UNIT_TYPE_CODE AS UNIT_TYPE_CODE,                       --??????
          ppu.UNIT_NAME AS UNIT_CODE,                                 --??????
          bct.ITEM_NAME AS UNIT_NAME,                                 --??????
          ppu.FACTOR AS FACTOR,                                --?????????????
          ppu.ORG_ID AS ORG_ID                                          --??ID
     FROM PHAM_PACK_UNIT ppu
          LEFT JOIN (SELECT ITEM_NAME, ITEM_VALUE
                       FROM BDS.BDS_CODE_TABLE_ITEM
                      WHERE T_ID IN (SELECT ID
                                       FROM BDS.BDS_CODE_TABLE
                                      WHERE STANDARD_CODE = 'TJ0024')) bct
             ON bct.ITEM_VALUE = ppu.UNIT_NAME
   UNION
   SELECT CASE WHEN gbi.SYSTEM_TYPE = '0' THEN '1' ELSE '2' END AS GOODS_TYPE,
          gpu.SERIAL_NO AS SERIAL_NO,
          gpu.GOODS_CODE AS GOODS_ID,
          gpu.UNIT_TYPE_CODE AS UNIT_TYPE_CODE,
          gpu.UNIT_NAME AS UNIT_CODE,
          bct.ITEM_NAME AS UNIT_NAME,
          gpu.FACTOR AS FACTOR,
          gpu.ORG_ID AS ORG_ID
     FROM GOODS_PACK_UNIT gpu
          LEFT JOIN GOODS_BASIC_INFO gbi ON gbi.GOODS_CODE = gpu.GOODS_CODE
          LEFT JOIN (SELECT ITEM_NAME, ITEM_VALUE
                       FROM BDS.BDS_CODE_TABLE_ITEM
                      WHERE T_ID IN (SELECT ID
                                       FROM BDS.BDS_CODE_TABLE
                                      WHERE STANDARD_CODE = 'TJ0040')) bct
             ON bct.ITEM_VALUE = gpu.UNIT_NAME


/

