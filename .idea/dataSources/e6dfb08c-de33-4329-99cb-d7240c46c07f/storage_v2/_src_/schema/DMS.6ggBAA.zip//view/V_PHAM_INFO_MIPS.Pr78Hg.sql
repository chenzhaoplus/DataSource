create view V_PHAM_INFO_MIPS as
  SELECT DISTINCT A.PHAM_STD_CODE,
                A.PHAM_CATE_CODE,
                DECODE(A.PHAM_CATE_CODE, '1','A', '2','B', '3','N', NULL) AS PRICE_CLASS,
                A.PHAM_CODE,
                A.PHAM_NAME,
                A.PHAM_GENERAL_NAME,
                A.PHAM_E_NAME,
                A.PHAM_SPEC,
                A.PHAM_UNIT,
                A.DOSE_UNIT,
                A.DOSE_PER_UNIT,
                A.PACKAGE_UNIT,
                A.PACKAGE_FACTOR,
                A.RETAIL_PRICE,
                A.TRADE_PRICE,
                A.PURCHASE_PRICE,
                TO_CHAR(ROUND(RETAIL_PRICE / A.PACKAGE_FACTOR, 4),
                        'FM999999.0000') AS PHAM_PRICE,
                A.PHARMACY_FACTORY,
                A.MANAGE_LEVEL,
                B.PRICE_PROPERTY,
                B.TOXICOLOGY_PROPERTY,
                B.PHAM_FORM,
                B.DEF_USAGE_CODE,
                B.DEF_FREQ_CODE,
                B.DEF_PER_DOSE,
                B.DEF_PER_QUAN,
                (SELECT CONT_VALUE
                   FROM DMS.PHAM_CUST_DEF_CONT
                  WHERE PHAM_STD_CODE = A.PHAM_STD_CODE
                    AND CONT_TYPE_ID = '3') AS SKIN_TEST,
                (SELECT CONT_VALUE
                   FROM DMS.PHAM_CUST_DEF_CONT
                  WHERE PHAM_STD_CODE = A.PHAM_STD_CODE
                    AND CONT_TYPE_ID = 'TJ0055') AS ANTI_LEVEL,
                A.HIGH_RISK_LEVEL,
                A.STOP_FLAG_PLAN STOP_FLAG,
                A.PHAM_SIMILAR,
                D.INPUT_CODE,
                D.STD_INDICATOR,
                PCDC.CONT_TYPE_ID
  FROM DMS.PHAM_BASIC_INFO A,
       DMS.PHAM_ATTRIBUTE_INFO B,
       DMS.PHAM_ALIA_DICT D,
       (SELECT PHAM_STD_CODE, CONT_TYPE_ID
          FROM DMS.PHAM_CUST_DEF_CONT
         WHERE CONT_TYPE_ID IN ('9', '10')) PCDC
 WHERE D.PHAM_CODE = B.PHAM_STD_CODE(+)
   AND D.PHAM_CODE = A.PHAM_STD_CODE
   AND D.PHAM_CODE = PCDC.PHAM_STD_CODE(+)


/

