create procedure     pro_drop_table(in_table_name varchar2) as
 v_num number;
begin
    
    select count(1) into v_num from all_tables where TABLE_NAME = in_table_name and OWNER='DMS'; 
    if   v_num=1   then 
        execute immediate 'drop table DMS.'||in_table_name||' CASCADE CONSTRAINTS';
    end   if; 

end;



/

