create view V_PHAM_BASIC_INFO as
  SELECT basic.PHAM_STD_CODE,
       basic.PHAM_CODE,
       basic.PHAM_CATE_CODE,
       basic.PHAM_NAME,
       basic.PHAM_GENERAL_NAME,
       basic.PHAM_E_NAME,
       basic.PHAM_SPEC,
       basic.SVR_SCOPE_TYPE_ID,
       basic.PHAM_DES,
       basic.SVR_MODE_TYPE_CODE,
       basic.PHAM_UNIT,
       basic.DOSE_UNIT,
       basic.DOSE_PER_UNIT,
       basic.PACKAGE_UNIT,
       basic.PACKAGE_FACTOR,
       basic.PHARMACY_FACTORY,
       basic.QUALIFICATION_CODE,
       basic.ORG_ID_BELONG,
       basic.SHOW_IN_ORDER_FLAG,
       basic.CREATE_TIME,
       basic.EMP_ID_CREATE,
       basic.EDIT_TIME,
       basic.EMP_ID_EDIT,
       basic.BIDDING_FLAG,
       basic.TEMPORARY_FLAG,
       basic.ORG_ID_HOSP,
       basic.HIGH_RISK_LEVEL,
       basic.MANAGE_LEVEL,
       basic.FREE_CHARGE_FLAG,
       basic.BILL_MODEL_CODE,
       basic.PURCHASE_TYPE,
       basic.NOTE,
       basic.PHAM_SIMILAR,
       basic.BASIC_PHAM,
       basic.GB_SERIAL_NO,
       basic.delete_flag,
       pd.retail_price,
       pd.trade_price,
       pd.purchase_price,
       sfpa.cont_value as STOP_FLAG_PLAN,
       sfpu.cont_value as STOP_FLAG_PUR,
       ai.area_code,
       pd.price_level_code
FROM PHAM_BASIC_INFO basic
left join dms.pham_basic_price_detail pd on pd.pham_std_code = basic.pham_std_code
left join dms.pham_area_price_rel ai on ai.price_level_code = pd.price_level_code
left join dms.pham_cust_def_busi sfpa on sfpa.pham_std_code = basic.pham_std_code
and sfpa.cont_type_id = 'StopFlagPlan' and ai.area_code = sfpa.area_code
left join dms.pham_cust_def_busi sfpu on sfpu.pham_std_code = basic.pham_std_code
and sfpu.cont_type_id = 'StopFlagPur'  and ai.area_code = sfpu.area_code



/

