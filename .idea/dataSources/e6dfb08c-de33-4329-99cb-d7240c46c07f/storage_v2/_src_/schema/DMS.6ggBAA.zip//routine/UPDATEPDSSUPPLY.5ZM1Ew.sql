create procedure updatePdsSupply(startTime in varchar2 ,endTime in varchar2 ) as

  v_count number(10);
  type stock_imblance is ref cursor;
  crow                stock_imblance;
  v_pham_std_code     dms.pds_supply_detail.pham_std_code%type;
  v_prescription_time dms.pds_supply_pro.prescription_time%type;
  v_supply_id         dms.pds_supply_pro.supply_id%type;
  v_ordered_by        dms.pds_supply.ordered_by%type;
  v_performed_by      dms.pds_supply_detail.performed_by%type;

begin
  v_count := 0;
  open crow for
    select pd.pham_std_code, psp.prescription_time, psp.supply_id,ps.ordered_by,pd.performed_by
      from pds_supply ps, pds_supply_detail pd, pds_supply_pro psp
     where pd.supply_id = ps.supply_id
       and psp.supply_id = ps.supply_id
       and ps.send_or_return_flag = 0
       and psp.prescription_time between
           to_date(startTime, 'yyyy-MM-dd') and
                   to_date(endTime, 'yyyy-MM-dd')
       and psp.ex_no is null;

  loop
    fetch crow
      into v_pham_std_code, v_prescription_time, v_supply_id,v_ordered_by,v_performed_by;
    exit when crow%notfound;

    update pds_supply_pro psp
       set psp.ex_no =
           (select max(t1.inout_number)
              from dms.pham_docu_head t1, dms.pham_docu_detail t2
             where t1.inout_number = t2.inout_number
               and t1.pham_io_sort in(2007,1001)
               and t1.receiver = v_ordered_by
               and t1.deliverer =v_performed_by
               and t1.pham_io_date between
                   to_date(startTime, 'yyyy-MM-dd') and
                   to_date(endTime, 'yyyy-MM-dd')
               and abs(ROUND(TO_NUMBER(v_prescription_time - t1.pham_io_date) * 24 * 60 * 60)) < 10
               and t2.pham_std_code = v_pham_std_code)
     where psp.ex_no is null
       and psp.supply_id = v_supply_id;
    v_count := v_count + 1;

    if v_count = 500 then
      v_count := 0;
      commit;
    end if;

  end loop;

  commit;

  close crow;

end;



/

