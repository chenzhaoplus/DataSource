create procedure P_EXEC_INVENTORY(inventoryId in number,
                                             empCode     in VARCHAR2,
                                             errorMsg    out VARCHAR2) as
  areaCode  VARCHAR2(2); --院区编码后两位
  simpCode  VARCHAR2(2); --机构简码
  deptCode  VARCHAR2(30);
  inNumber  dms.pham_docu_head.inout_number%type; --盘点入库单
  outNumber dms.pham_docu_head.inout_number%type; --盘点出库单

  v_stock_sub_id dms.pham_stock_table_sub.stock_sub_id%type;

  type stockInoutCursor is ref cursor; --定义库存调整游标
  crow stockInoutCursor; --定义库存调整游标指针

  ---------定义游标中用到的数据结构--------------
  v_pham_std_code     dms.pham_basic_info.pham_std_code%type;
  v_pham_name         dms.pham_basic_info.pham_name%type;
  v_pham_factory_name dms.pham_stock_table.pham_factory_name%type;
  v_pham_batch_number dms.pham_stock_table_sub.pham_batch_number%type;
  v_expire_date       dms.pham_stock_table_sub.expire_date%type;
  v_base_quantity     dms.pham_stock_table_sub.quantity%type;
  ---------定义游标中用到的数据结构--------------

   PRAGMA AUTONOMOUS_TRANSACTION;

begin

  begin
    select substr(o.property1, -2), i.dept_code, p.org_brief_code
      into areaCode, deptCode, simpCode
      from dms.pham_inventory i, bds_organization o, dms.pham_org p
     where i.dept_code = o.code
       and i.dept_code = p.org_id
       and i.inventory_id = inventoryId
       and i.finish_flag = '0'; --查询院区编码、机构编码、机构简码
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      errorMsg := '未找到盘点记录ID：【' || inventoryId || '】或盘点已经提交';
      RETURN;
  end;

  --获取入库单号 02CB2016
  select areaCode || simpCode || to_char(sysdate, 'yyyy') || '盘点入库' ||
         replace(lpad(n.mid_seq, 6), ' ', '0')
    into inNumber
    from dms.business_serial_num n
   where n.busi_serial_name =
         areaCode || simpCode || to_char(sysdate, 'yyyy') || '盘点入库'
     for update;
  update dms.business_serial_num n
     set n.mid_seq = n.mid_seq + 1
   where n.busi_serial_name =
         areaCode || simpCode || to_char(sysdate, 'yyyy') || '盘点入库';
  commit;

  --获取出库单号
  select areaCode || simpCode || to_char(sysdate, 'yyyy') || '盘点出库' ||
         replace(lpad(n.mid_seq, 6), ' ', '0')
    into outNumber
    from dms.business_serial_num n
   where n.busi_serial_name =
         areaCode || simpCode || to_char(sysdate, 'yyyy') || '盘点出库'
     for update;
  update dms.business_serial_num n
     set n.mid_seq = n.mid_seq + 1
   where n.busi_serial_name =
         areaCode || simpCode || to_char(sysdate, 'yyyy') || '盘点出库';

  commit;

  --插入盘点入库单
  insert into dms.pham_docu_head
    (INOUT_NUMBER,
     DEPT_CODE,
     PHAM_IO_SIGN,
     PHAM_IO_SORT,
     RECEIVER,
     DELIVERER,
     PHAM_IO_DATE,
     EMP_ID_OPERATOR,
     EMP_ID_CHECK,
     EMP_ID_INVER,
     PAY_AMOUNT,
     PAY_FINISHED_AMOUNT,
     ACCOUNT_SIGN,
     NOTE,
     DOCU_ORDER_NUMBER,
     PAY_NOTICE_NO,
     PRICE_ADJUSTMENT_ID,
     SUPPLIER_SERIAL_NO,
     CREATE_TIME,
     SUBMIT_TIME,
     ACCOUNT_TIME,
     INOUT_STATUS,
     DIRECT_INOUT_SIGN,
     PDS_APPLY_ID,
     PURCHASE_SUPPLY_SERIAL_NO,
     ACCOUNT_NO,
     ACCOUNT_SUB_NO,
     BUDGET_FLAG,
     AREA_CODE)
    select inNumber,
           i.dept_code,
           '1',
           '3002',
           null,
           i.dept_code,
           sysdate,
           empCode,
           empCode,
           empCode,
           null,
           null,
           '1',
           inventoryId,
           null,
           null,
           null,
           null,
           sysdate,
           sysdate,
           sysdate,
           '1',
           null,
           null,
           null,
           null,
           null,
           '0',
           o.property1
      from dms.pham_inventory i, bds_organization o
     where i.dept_code = o.code
       and i.inventory_id = inventoryId;

  --插入盘点出库单
  insert into dms.pham_docu_head
    (INOUT_NUMBER,
     DEPT_CODE,
     PHAM_IO_SIGN,
     PHAM_IO_SORT,
     RECEIVER,
     DELIVERER,
     PHAM_IO_DATE,
     EMP_ID_OPERATOR,
     EMP_ID_CHECK,
     EMP_ID_INVER,
     PAY_AMOUNT,
     PAY_FINISHED_AMOUNT,
     ACCOUNT_SIGN,
     NOTE,
     DOCU_ORDER_NUMBER,
     PAY_NOTICE_NO,
     PRICE_ADJUSTMENT_ID,
     SUPPLIER_SERIAL_NO,
     CREATE_TIME,
     SUBMIT_TIME,
     ACCOUNT_TIME,
     INOUT_STATUS,
     DIRECT_INOUT_SIGN,
     PDS_APPLY_ID,
     PURCHASE_SUPPLY_SERIAL_NO,
     ACCOUNT_NO,
     ACCOUNT_SUB_NO,
     BUDGET_FLAG,
     AREA_CODE)
    select outNumber,
           i.dept_code,
           '0',
           '3002',
           null,
           i.dept_code,
           sysdate,
           empCode,
           empCode,
           empCode,
           null,
           null,
           '1',
           inventoryId,
           null,
           null,
           null,
           null,
           sysdate,
           sysdate,
           sysdate,
           '1',
           null,
           null,
           null,
           null,
           null,
           '0',
           o.property1
      from dms.pham_inventory i, bds_organization o
     where i.dept_code = o.code
       and i.inventory_id = inventoryId;

  --插入盘点出入库明细表
  insert into pham_docu_detail
    (INOUT_SUB_NUMBER,
     INOUT_NUMBER,
     PHAM_STD_CODE,
     PHAM_FACTORY_NAME,
     PHAM_BATCH_NUMBER,
     RECEIPT_DATE,
     QUANTITY,
     UNIT,
     BASE_QUANTITY,
     BASE_UNIT,
     FACTOR,
     RETAIL_FACTOR,
     PURCHASE_PRICE,
     PURCHASE_AMOUNT,
     TRADE_PRICE,
     TRADE_AMOUNT,
     RETAIL_PRICE,
     RETAIL_AMOUNT,
     PAY_AMOUNT,
     RECEIPT_NUMBER,
     DISCOUNT,
     INVENTORY,
     PHAM_BATCH_NUMBER_FLAG,
     ACCOUNT_SIGN,
     EMP_ID_CHECK,
     EMP_ID_INVER,
     EMP_ID_SIGN,
     NOTE,
     WRITE_OFF_STATUS,
     WRITE_OFF_NUM)
    select dms.f_sequence_gen('PHAM_DOCU_DETAIL', 1),
           case
             when (a.pquantity - a.cquantity) < 0 then
              outNumber
             else
              inNumber
           end,
           a.pham_std_code,
           case
             when a.pham_factory_name = '***' then
              null
             else
              a.pham_factory_name
           end,
           a.pham_batch_number,
           a.expire_date,
           abs(a.pquantity - a.cquantity),
           i.pham_unit,
           abs(a.pquantity - a.cquantity),
           i.pham_unit,
           1.000,
           1.000,
           i.purchase_price,
           round(abs(a.pquantity - a.cquantity) * i.purchase_price /
                 i.package_factor,
                 4),
           i.trade_price,
           round((a.pquantity - a.cquantity) * i.trade_price /
                 i.package_factor,
                 4),
           i.retail_price,
           round(abs(a.pquantity - a.cquantity) * i.retail_price /
                 i.package_factor,
                 4),
           null,
           null,
           null,
           null,
           null,
           1,
           empCode,
           empCode,
           empCode,
           null,
           0,
           null

      from (

            select case
                      when a.pham_std_code is null then
                       b.pham_std_code
                      else
                       a.pham_std_code
                    end pham_std_code,
                    case
                      when a.pham_std_code is null then
                       b.pham_factory_name
                      else
                       a.pham_factory_name
                    end pham_factory_name,
                    case
                      when a.pham_std_code is null then
                       b.pham_batch_number
                      else
                       a.pham_batch_number
                    end pham_batch_number,
                    case
                      when a.pham_std_code is null then
                       b.expire_date
                      else
                       a.expire_date
                    end expire_date,
                    nvl(a.quantity, 0) cquantity,
                    nvl(b.quantity, 0) pquantity
              from (select pham_std_code,
                            nvl(pham_factory_name, '***') pham_factory_name,
                            pham_batch_number,
                            expire_date,
                            nvl(sum(quantity), 0) quantity
                       from dms.pham_inventory_sub
                      where inventory_id = inventoryId
                      group by pham_std_code,
                               pham_factory_name,
                               pham_batch_number,
                               expire_date) a

              full join

             (select pham_std_code,
                     nvl(pham_factory_name, '***') pham_factory_name,
                     pham_batch_number,
                     expire_date,
                     nvl(sum(quantity), 0) quantity
                from dms.pham_inventory_physical
               where inventory_id = inventoryId
               group by pham_std_code,
                        pham_factory_name,
                        pham_batch_number,
                        expire_date) b
                on a.pham_std_code = b.pham_std_code
               and a.pham_factory_name = b.pham_factory_name
               and a.pham_batch_number = b.pham_batch_number
               and a.expire_date = b.expire_date) a,
           dms.pham_basic_info i
     where a.pham_std_code = i.pham_std_code
       and (a.pquantity - a.cquantity) <> 0;

  open crow for
    select a.pham_std_code,
           i.pham_name,
           case
             when a.pham_factory_name = '***' then
              null
             else
              a.pham_factory_name
           end pham_factory_name,
           a.pham_batch_number,
           a.expire_date,
           a.pquantity - a.cquantity basequantity

      from (

            select case
                      when a.pham_std_code is null then
                       b.pham_std_code
                      else
                       a.pham_std_code
                    end pham_std_code,
                    case
                      when a.pham_std_code is null then
                       b.pham_factory_name
                      else
                       a.pham_factory_name
                    end pham_factory_name,
                    case
                      when a.pham_std_code is null then
                       b.pham_batch_number
                      else
                       a.pham_batch_number
                    end pham_batch_number,
                    case
                      when a.pham_std_code is null then
                       b.expire_date
                      else
                       a.expire_date
                    end expire_date,
                    nvl(a.quantity, 0) cquantity,
                    nvl(b.quantity, 0) pquantity
              from (select pham_std_code,
                            nvl(pham_factory_name, '***') pham_factory_name,
                            pham_batch_number,
                            expire_date,
                            nvl(sum(quantity), 0) quantity
                       from dms.pham_inventory_sub
                      where inventory_id = inventoryId
                      group by pham_std_code,
                               pham_factory_name,
                               pham_batch_number,
                               expire_date) a

              full join

             (select pham_std_code,
                     nvl(pham_factory_name, '***') pham_factory_name,
                     pham_batch_number,
                     expire_date,
                     nvl(sum(quantity), 0) quantity
                from dms.pham_inventory_physical
               where inventory_id = inventoryId
               group by pham_std_code,
                        pham_factory_name,
                        pham_batch_number,
                        expire_date) b
                on a.pham_std_code = b.pham_std_code
               and a.pham_factory_name = b.pham_factory_name
               and a.pham_batch_number = b.pham_batch_number
               and a.expire_date = b.expire_date) a,
           dms.pham_basic_info i
     where a.pham_std_code = i.pham_std_code
       and (a.pquantity - a.cquantity) <> 0;

  loop
    fetch crow
      into v_pham_std_code,
           v_pham_name,
           v_pham_factory_name,
           v_pham_batch_number,
           v_expire_date,
           v_base_quantity;
    exit when crow%notfound;

    --查询库存子表是否存在
    select max(stock_sub_id)
      into v_stock_sub_id
      from pham_stock_table_sub b, pham_stock_table m
     where b.stock_id = m.stock_id
       and m.dept_code = deptCode
       and m.pham_std_code = v_pham_std_code
       and b.pham_batch_number = v_pham_batch_number
       and b.expire_date = v_expire_date
       and nvl(m.pham_factory_name,'***') = nvl(v_pham_factory_name,'***')
       and (b.quantity + v_base_quantity) >= 0;

    if (v_base_quantity < 0 and v_stock_sub_id is null) then

      errorMsg := errorMsg ||  v_pham_std_code ||' 【'|| v_pham_name ||'】药品信息库存不够盘点出库,批号【'||v_pham_batch_number||'】;<br />';

    else
      if (v_base_quantity > 0 and v_stock_sub_id is null) then

        --当库存主表不存在则插入库存主表
        insert into dms.pham_stock_table
          (STOCK_ID,
           DEPT_CODE,
           PHAM_STD_CODE,
           PHAM_FACTORY_NAME,
           QUANTITY,
           UNIT)
          select dms.f_sequence_gen('PHAM_STOCK_TABLE', 1),
                 deptCode,
                 v_pham_std_code,
                 v_pham_factory_name,
                 0,
                 i.package_unit
            from dms.pham_basic_info i
           where i.pham_std_code = v_pham_std_code
             and not exists
           (select count(1)
                    from dms.pham_stock_table s
                   where s.pham_std_code = v_pham_std_code
                     and s.dept_code = deptCode
                     and  nvl(s.pham_factory_name,'***') = nvl(v_pham_factory_name,'***') );

        --更新库存主表
        update pham_stock_table
           set quantity = quantity + v_base_quantity
         where pham_std_code = v_pham_std_code
           and nvl(pham_factory_name,'***') = nvl(v_pham_factory_name,'***')
           and dept_code = deptCode;

        --插入库存子表
        insert into dms.pham_stock_table_sub
          (STOCK_SUB_ID,
           STOCK_ID,
           PHAM_BATCH_NUMBER,
           EXPIRE_DATE,
           QUANTITY,
           PACK_QUANTITY_UNIT,
           FACTOR,
           FACTOR_DES,
           NOTE)
          select dms.f_sequence_gen('PHAM_STOCK_TABLE_SUB', 1),
                 (select STOCK_ID
                    from pham_stock_table
                   where pham_std_code = v_pham_std_code
                     and dept_code = deptCode
                     and nvl(pham_factory_name,'***')  = nvl(v_pham_factory_name,'***') ),
                 v_PHAM_BATCH_NUMBER,
                 v_EXPIRE_DATE,
                 v_base_quantity,
                 i.package_unit,
                 i.package_factor,
                 null,
                 null
            from dms.pham_basic_info i
           where i.pham_std_code = v_pham_std_code;

      else
        update pham_stock_table_sub ts
           set ts.quantity = ts.quantity + v_base_quantity
         where stock_sub_id = v_stock_sub_id;

           update pham_stock_table
           set quantity = quantity + v_base_quantity
         where pham_std_code = v_pham_std_code
           and nvl(pham_factory_name,'***') = nvl(v_pham_factory_name,'***')
           and dept_code = deptCode;
        --更新库存子表
      end if;

    end if;

  end loop;

  close crow;

  update dms.pham_inventory i set i.finish_flag = '1',i.emp_id_commit = empCode where i.inventory_id = inventoryId;

  if errorMsg is not null then
    rollback;
  else commit;
  end if;



end;





/

