create view V_PHAM_PACK_UNIT as
  SELECT PHAM_STD_CODE,
          UNIT_TYPE_CODE,
          UNIT_NAME,
          FACTOR
     FROM DMS.PHAM_PACK_UNIT



/

