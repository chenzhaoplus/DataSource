create view V_GOODS_BASIC_INFO_DESP as
  SELECT A.GOODS_CODE,
       A.GOODS_CLASS,
       'I' PRICE_CLASS,

  (SELECT CATE_NAME
   FROM DMS.GOODS_INSIDE_CODE_DICT
   WHERE CATE_CODE = A.GOODS_CLASS) AS GOODS_CLASS_NAME,
           A.GOODS_CATE_CODE,

  (SELECT ITEM_NAME
   FROM BDS.BDS_CODE_TABLE_ITEM
   WHERE T_ID =
       (SELECT ID
        FROM BDS.BDS_CODE_TABLE
        WHERE STANDARD_CODE = 'TJ0028')
     AND ITEM_VALUE = A.GOODS_CATE_CODE) AS GOODS_CATE_NAME,
           case
               when b.goods_invalid_name is not null then (A.GOODS_NAME || '(' || B.Goods_Invalid_Name || ')')
               else a.goods_name
           end GOODS_NAME,

  (SELECT to_char(listagg(INPUT_CODE) within
                  group (
                         order by INPUT_CODE))
   FROM DMS.GOODS_ALIA_DICT
   WHERE GOODS_CODE = A.GOODS_CODE
     AND STD_INDICATOR = 0) AS INPUT_CODE,
           A.GOODS_GENERAL_NAME,
           A.GOODS_E_NAME,
           A.GOODS_SPEC,
           A.GOODS_MODELS,
           A.GOODS_UNIT,

  (SELECT ITEM_NAME
   FROM BDS.BDS_CODE_TABLE_ITEM
   WHERE T_ID =
       (SELECT ID
        FROM BDS.BDS_CODE_TABLE
        WHERE STANDARD_CODE = 'TJ0040')
     AND ITEM_VALUE = A.GOODS_UNIT) AS GOODS_UNIT_NAME,
           A.PACKAGE_UNIT,

  (SELECT ITEM_NAME
   FROM BDS.BDS_CODE_TABLE_ITEM
   WHERE T_ID =
       (SELECT ID
        FROM BDS.BDS_CODE_TABLE
        WHERE STANDARD_CODE = 'TJ0040')
     AND ITEM_VALUE = A.PACKAGE_UNIT) AS PACKAGE_UNIT_NAME,
           A.PACKAGE_SPEC,
           gbp.RETAIL_PRICE,
           gbp.TRADE_PRICE,
           gbp.PURCHASE_PRICE,
           gbp.GOODS_UNIT_PURCHASE_PRICE,
           gbp.GOODS_UNIT_RETAIL_PRICE,
           A.GOODS_FACTORY,
           A.PRO_AREA,
           A.BRAND_NAME,
           gbp.STOP_FLAG,
           A.Clinic_Use_Flag,
           A.Managy_Level,
           A.Org_Id_Hosp,
           A.Apply_Flag,
           A.Track_Level_Code,
           A.Free_Charge_Flag,
           A.Goods_Gb_Code,
           A.Main_Or_Sub,
           A.Note,
           A.Goods_Description,
           A.Domestic,
           A.Goods_Material,
           A.Goods_Standard,
           A.Goods_Number,
           A.Goods_Product_Number,
           gap.area_code,
           A.GOODS_CLINIC_TYPE_CODE as GOODS_CODE_PRE--医用材料编码
              FROM
DMS.GOODS_BASIC_INFO A
LEFT JOIN DMS.Goods_Extends_Info B on a.goods_code = b.goods_code
left join dms.goods_basic_price_detail gbp on gbp.goods_code = a.goods_code
left join dms.goods_area_price_rel gap on gap.price_level_code = gbp.price_level_code
WHERE A.SYSTEM_TYPE = 0



/

