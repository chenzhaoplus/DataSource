create FUNCTION     F_SEQUENCE_GEN(i_busi_serial_name in VARCHAR2, i_num in NUMBER) return number is
  V_CURRENT NUMBER(15);
  PRAGMA AUTONOMOUS_TRANSACTION;
begin
  begin  
  select A.SEQUENCE INTO V_CURRENT from CAREFX_TABLE_SEQ A WHERE A.TABLE_NAME = i_busi_serial_name for update;
  exception
     when NO_DATA_FOUND THEN
        INSERT INTO CAREFX_TABLE_SEQ(TABLE_NAME,SEQUENCE) values (i_busi_serial_name,1);
        --????
        select A.SEQUENCE INTO V_CURRENT from CAREFX_TABLE_SEQ A WHERE A.TABLE_NAME = i_busi_serial_name for update;
       END;
  
  UPDATE  CAREFX_TABLE_SEQ A SET A.SEQUENCE = A.SEQUENCE + DECODE(i_num,NULL,1,i_num) WHERE A.TABLE_NAME = i_busi_serial_name;
  COMMIT;
  return(V_CURRENT);
  EXCEPTION WHEN OTHERS THEN
    ROLLBACK;
    return NULL;
    
end F_SEQUENCE_GEN;



/

