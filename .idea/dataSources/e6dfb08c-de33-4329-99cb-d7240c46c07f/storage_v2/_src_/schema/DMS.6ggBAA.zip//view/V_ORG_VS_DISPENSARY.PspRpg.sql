create view V_ORG_VS_DISPENSARY as
  SELECT PDVSF.ORG_ID,
       PDC.DEPT_PINYIN_CODE,
       PDC.PHAM_DISPENSARY_CODE,
       (SELECT NAME
          FROM BDS.BDS_ORGANIZATION
         WHERE CODE = PDC.PHAM_DISPENSARY_CODE) AS PHAM_CATE_NAME,
       PDVSF.PRIORIYT,
       PDC.SHIFT,
       PDC.INFUSION_CONFIG,
       PDC.INFUSION_OPEN,
       PDC.DISPENSE_PRINT_FLAG,
       PDC.DECOTE_CONN_FLAG,
       PDC.OPEN_FLAG,
       PDC.BEGIN_TIME,
       PDC.END_TIME,
       PDC.PRESC_DATE_BEFORE,
       PDC.QUEUE_CONFIG,
       PDC.QUEUE_ENABLE,
       PDC.QUEUE_TYPE,
       PDC.OUTP_DELIVERY_TYPE,
       PDC.INP_DELIVERY_TYPE,
       PDC.SEARCH_RANGE,
       PDC.DISPENSE_TYPE,
       PDVSF.DISPENSARY_ID,
       PDVSF.IS_ARREAR,
       PDVSF.WITHDRAW_TYPE,
       PDVSF.IS_RETURN,
       PDC.DISCHARGE_MEDICATION,
       (select address from bds.bds_organization where code=PDC.PHAM_DISPENSARY_CODE) address
  FROM DMS.PDS_DISPENSARY_CONFIG PDC, DMS.PDS_PHARM_VS_SERVICE_FROM PDVSF
 WHERE PDC.ID = PDVSF.DISPENSARY_ID
   AND PDC.OPEN_FLAG = 1
   AND TO_CHAR(SYSDATE, 'YYYY-MM-DD HH24:MI') BETWEEN
       TO_CHAR(SYSDATE +
               (SELECT CASE SHIFT
                         WHEN '1' THEN
                          0
                         WHEN '2' THEN
                          CASE
                            WHEN (TO_CHAR(SYSDATE, 'HH24:MI:SS') < '12:00:00') THEN
                             -1
                            ELSE
                             0
                          END
                         ELSE
                          -10
                       END
                  FROM DMS.PDS_DISPENSARY_CONFIG
                 WHERE ID = PDC.ID),
               'YYYY-MM-DD') || TO_CHAR(PDC.BEGIN_TIME, ' HH24:MI') AND
       TO_CHAR(SYSDATE +
               (SELECT CASE SHIFT
                         WHEN '1' THEN
                          0
                         WHEN '2' THEN
                          CASE
                            WHEN (TO_CHAR(SYSDATE, 'HH24:MI:SS') < '12:00:00') THEN
                             0
                            ELSE
                             1
                          END
                         ELSE
                          10
                       END
                  FROM DMS.PDS_DISPENSARY_CONFIG
                 WHERE ID = PDC.ID),
               'YYYY-MM-DD') || TO_CHAR(PDC.END_TIME, ' HH24:MI')
 ORDER BY PDVSF.PRIORIYT, PDC.SHIFT



/

