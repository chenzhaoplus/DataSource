create trigger T_PHAM_BASIC_INFO
  after insert or update
  on PHAM_BASIC_INFO
  for each row
  declare nextid INTEGER;
  BEGIN

      delete from BMS.BMS_DETAIL_VS_CLASS where detail_code=:NEW.PHAM_STD_CODE;

     SELECT MAX(ID)+1 INTO nextid FROM BMS.BMS_DETAIL_VS_CLASS;
     INSERT INTO BMS.BMS_DETAIL_VS_CLASS
      VALUES (nextid,:NEW.PHAM_STD_CODE,'A',case :NEW.PHAM_CATE_CODE WHEN '3' then 'A03' when '2' then 'A02' else 'A01' end,null,'2',NULL);

     nextid:=nextid+1;
     INSERT INTO BMS.BMS_DETAIL_VS_CLASS
     values(nextid,:NEW.PHAM_STD_CODE,'B',case :NEW.PHAM_CATE_CODE WHEN '3' then '2' when '2' then '1' else 'A' end,null,'2',NULL);
    nextid :=nextid+1;
    INSERT INTO BMS.BMS_DETAIL_VS_CLASS
    VALUES(nextid,:NEW.PHAM_STD_CODE,'C',case :NEW.PHAM_CATE_CODE WHEN '3' then 'A03' when '2' then 'A02' else 'A01' end,null,'2',NULL);
    nextid :=nextid+1;

    INSERT INTO BMS.BMS_DETAIL_VS_CLASS
    VALUES(nextid,:NEW.PHAM_STD_CODE,'D',case :NEW.PHAM_CATE_CODE WHEN '3' then '2' when '2' then '1' else 'B' end,null,'2',NULL);
    nextid :=nextid+1;

    INSERT INTO BMS.BMS_DETAIL_VS_CLASS
    VALUES(nextid,:NEW.PHAM_STD_CODE,'E',case :NEW.PHAM_CATE_CODE WHEN '3' then '16' when '2' then '10' else 'A' end,null,'2',NULL);
    nextid :=nextid+1;

    INSERT INTO BMS.BMS_DETAIL_VS_CLASS
    VALUES(nextid,:NEW.PHAM_STD_CODE,'F',case :NEW.PHAM_CATE_CODE WHEN '3' then 'P772' when '2' then 'P771' else 'P769' end,null,'2',NULL);
 END;


/

