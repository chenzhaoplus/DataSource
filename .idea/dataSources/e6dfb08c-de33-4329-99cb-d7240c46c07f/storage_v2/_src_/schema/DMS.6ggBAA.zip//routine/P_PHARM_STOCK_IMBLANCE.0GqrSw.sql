create procedure P_PHARM_STOCK_IMBLANCE

 as

  start_id number(14);
  end_id   number(14);
  type pham_org_cursor is ref cursor;
  prow      pham_org_cursor;
  dept_code bds.bds_organization.code%type;
  ycCount   number(14); 
  outResult varchar2(30);
  myException EXCEPTION;

begin

  select max(snapshot_id)
    into start_id
    FROM dms.pham_stock_snapshot t
   where t.st_date = trunc(sysdate - 2);

  select max(snapshot_id)
    into end_id
    FROM dms.pham_stock_snapshot t
   where t.st_date = trunc(sysdate-1);

   if start_id is null then
     dbms_output.put_line('start_id is null'); 
     raise myException;
   end if;

   if end_id is null then
    dbms_output.put_line('end_id is null'); 
     raise myException;
   end if;

  open prow for

    select code
      from bds.bds_organization org --where code = '21250203';
     where org.property3 in ('51', '52')
       and org.property1 in ('H0002', 'H0003');

  loop
    fetch prow
      into dept_code;
    exit when prow%notfound;

    select count(1)
      into ycCount
      from (

            select i.pham_name,
                    t.*,
                    i.package_factor,
                    i.trade_price,
                    (qcQ + ruQ + cuQ + qmQ) ce,
                    i.package_factor,
                    round((qcQ + ruQ + cuQ + qmQ) * i.trade_price /
                          i.package_factor,
                          2)
              from (

                     select t.pham_std_code,
                             nvl(qc.qcQ, 0) qcQ,
                             nvl(ru.ruQ, 0) ruQ,
                             nvl(cu.cuQ, 0) cuQ,
                             nvl(qm.qmQ, 0) qmQ
                       from (select *
                                from pham_property_table
                               where org_id = dept_code) t

                       left join

                      (select pham_std_code, sum(squantity) qcQ
                         from dms.pham_stock_snapshot_detail
                        where snapshot_id = start_id
                          and dept_code = dept_code
                        group by pham_std_code) qc

                         on t.pham_std_code = qc.pham_std_code

                       left join (

                                  select d.pham_std_code, sum(d.base_quantity) ruQ
                                    from dms.pham_docu_head   h,
                                          dms.pham_docu_detail d
                                   where h.inout_number = d.inout_number
                                     and dept_code = dept_code
                                     and h.pham_io_sort not in ('3001', '1012')
                                     and h.pham_io_sign = '1'
                                     and h.inout_status = '1'
                                     and h.pham_io_date between
                                         (select snapshot_time
                                            from pham_stock_snapshot
                                           where snapshot_id = start_id) and
                                         (select snapshot_time
                                            from pham_stock_snapshot
                                           where snapshot_id = end_id)
                                   group by d.pham_std_code) ru
                         on t.pham_std_code = ru.pham_std_code

                       left join (select d.pham_std_code,
                                         0 - sum(d.base_quantity) cuQ
                                    from dms.pham_docu_head   h,
                                         dms.pham_docu_detail d
                                   where h.inout_number = d.inout_number
                                     and dept_code = dept_code
                                     and h.pham_io_sort not in ('3001', '1012')
                                     and h.pham_io_sign = '0'
                                     and h.inout_status = '1'
                                     and h.pham_io_date between
                                         (select snapshot_time
                                            from pham_stock_snapshot
                                           where snapshot_id = start_id) and
                                         (select snapshot_time
                                            from pham_stock_snapshot
                                           where snapshot_id = end_id)
                                   group by d.pham_std_code) cu
                         on t.pham_std_code = cu.pham_std_code

                       left join

                      (select pham_std_code, 0 - sum(squantity) qmQ
                         from dms.pham_stock_snapshot_detail
                        where snapshot_id = end_id
                          and dept_code = dept_code
                        group by pham_std_code) qm

                         on t.pham_std_code = qm.pham_std_code) t
              left join pham_basic_info i
                on t.pham_std_code = i.pham_std_code
             where (qcQ + ruQ + cuQ + qmQ) <> 0

            );

    if ycCount is not null then

      select dms.f_pham_stock_imblance(dept_code, start_id, end_id) into outResult from dual;
      dbms_output.put_line('result：' || outResult); 
      
    end if;
    
    end loop;

  end;



/

