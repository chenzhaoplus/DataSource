create view V_PHAM_STOCK_STATU as
  SELECT PST.PHAM_STD_CODE,
            PST.DEPT_CODE,
            NVL (MAX (PPT.LOW_LIMIT), 0) LOW_LIMIT,
            SUM (PST.QUANTITY) QUANTITY,
            --0???????1??????
            CASE
               WHEN NVL (SUM (PST.QUANTITY), 0) - NVL (MAX (PPT.LOW_LIMIT), 0) >
                       0
               THEN
                  1
               WHEN NVL (SUM (PST.QUANTITY), 0) - NVL (MAX (PPT.LOW_LIMIT), 0) <=
                       0
               THEN
                  0
            END
               IS_STOCK,
            --0?????1????
            NVL (PPT.SUPPLY_INDICATOR, 1) SUPPLY_INDICATOR
       FROM PHAM_PROPERTY_TABLE PPT, PHAM_STOCK_TABLE PST
      WHERE     PPT.PHAM_STD_CODE(+) = PST.PHAM_STD_CODE
            AND PPT.ORG_ID(+) = PST.DEPT_CODE
   GROUP BY PST.PHAM_STD_CODE, PST.DEPT_CODE, PPT.SUPPLY_INDICATOR


/

