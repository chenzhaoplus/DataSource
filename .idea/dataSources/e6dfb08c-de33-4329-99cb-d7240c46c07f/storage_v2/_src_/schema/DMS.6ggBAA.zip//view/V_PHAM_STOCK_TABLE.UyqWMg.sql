create view V_PHAM_STOCK_TABLE as
  select t.stock_id,
       t.dept_code,
       t.pham_std_code,
       t.pham_factory_name,
       t.unit,
       nvl(sum(s.quantity),0) as quantity
from dms.pham_stock_table t
left join dms.pham_stock_table_sub s on t.stock_id = s.stock_id
group by t.stock_id,
         t.dept_code,
         t.pham_std_code,
         t.pham_factory_name,
         t.unit



/

