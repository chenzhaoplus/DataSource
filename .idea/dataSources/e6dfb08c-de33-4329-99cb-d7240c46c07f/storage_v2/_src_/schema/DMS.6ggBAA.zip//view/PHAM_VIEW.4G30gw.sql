create view PHAM_VIEW as
  select a.pham_code "药品编码",a.pham_name "药品名称",a.pham_spce "药品规格",
(select item_value from bds.bds_code_table_item where t_id =24  and item_name=a.pham_unit) as "基本单位",
(select item_value from bds.bds_code_table_item where t_id =24  and item_name=a.package_unit)  "零售单位" ,
a.package_factor as "零售单位包装量" ，
a.dose_per_unit as "基本单位剂量",
(select item_value from bds.bds_code_table_item where t_id =22  and item_name=a.dose_unit)  as "剂量单位",
a.retail_price "售价",
b.pham_std_code,b.pham_name,b.pham_spec,b.pham_unit,b.package_unit,b.package_factor,b.dose_per_unit,b.dose_unit,b.retail_price
from dms.pham_basic_info_news a
left join dms.pham_basic_info b on a.pham_code=b.pham_std_code


/

