create view V_PHAM_INFO as
  SELECT DISTINCT A.PHAM_STD_CODE,
                A.PHAM_CATE_CODE,
                DECODE(A.PHAM_CATE_CODE, '1','A', '2','B', '3','N', NULL) AS PRICE_CLASS,
                A.PHAM_CODE,
                A.PHAM_NAME,
                A.PHAM_GENERAL_NAME,
                A.PHAM_E_NAME,
                A.PHAM_SPEC,
                A.PHAM_UNIT,
                A.DOSE_UNIT,
                A.DOSE_PER_UNIT,
                A.PACKAGE_UNIT,
                A.PACKAGE_FACTOR,
                pd.RETAIL_PRICE,
                pd.TRADE_PRICE,
                pd.PURCHASE_PRICE,
                TO_CHAR(ROUND(pd.RETAIL_PRICE / A.PACKAGE_FACTOR, 4), 'FM999999.0000') AS PHAM_PRICE,
                A.PHARMACY_FACTORY,
                A.MANAGE_LEVEL,
                B.PRICE_PROPERTY,
                B.TOXICOLOGY_PROPERTY,
                B.PHAM_FORM,
                B.DEF_USAGE_CODE,
                B.DEF_FREQ_CODE,
                B.DEF_PER_DOSE,
                B.DEF_PER_QUAN,

  (SELECT CONT_VALUE
   FROM DMS.PHAM_CUST_DEF_CONT
   WHERE PHAM_STD_CODE = A.PHAM_STD_CODE
     AND CONT_TYPE_ID = '3') AS SKIN_TEST,

  (SELECT CONT_VALUE
   FROM DMS.PHAM_CUST_DEF_CONT
   WHERE PHAM_STD_CODE = A.PHAM_STD_CODE
     AND CONT_TYPE_ID = 'TJ0055') AS ANTI_LEVEL,
                A.HIGH_RISK_LEVEL,
                sfpa.cont_value STOP_FLAG,
                A.PHAM_SIMILAR,
                D.INPUT_CODE,
                D.STD_INDICATOR,
                PCDC.CONT_TYPE_ID,
                B.DOSAGE_UNITS,
                B.DEF_COURSE,
                B.DEF_COURSE_UNIT,
                B.CH_DEF_USAGE_CODE,
                B.OI_DOSAGE_UNITS,
                b.pham_oi_sign,
                ai.area_code as AREA_CODE
FROM DMS.PHAM_BASIC_INFO A
left join DMS.PHAM_ALIA_DICT D on D.PHAM_CODE = A.PHAM_STD_CODE
left join DMS.PHAM_ATTRIBUTE_INFO B on D.PHAM_CODE = B.PHAM_STD_CODE
left join
  (SELECT PHAM_STD_CODE,
          CONT_TYPE_ID
   FROM DMS.PHAM_CUST_DEF_CONT
   WHERE CONT_TYPE_ID IN ('9',
                          '10',
                          '36',
                          '37')) PCDC on PCDC.PHAM_STD_CODE = D.PHAM_CODE
--left join
--  (SELECT PHAM_STD_CODE,
--          CONT_TYPE_ID
--   FROM dms.PHAM_CUST_DEF_CONT
--  WHERE 1 = 1
--     AND CONT_TYPE_ID IN ('9',
--                          '10')) PCDC on D.PHAM_CODE = PCDC.PHAM_STD_CODE
left join dms.pham_basic_price_detail pd on pd.pham_std_code = A.pham_std_code
left join dms.pham_area_price_rel ai on ai.price_level_code = pd.price_level_code
left join dms.pham_cust_def_busi sfpa on sfpa.pham_std_code = A.pham_std_code
and sfpa.cont_type_id = 'StopFlagPlan'
WHERE sfpa.cont_value = 1


/

