create procedure SP_REPORT_PHEALTH_CHILD_WORK(
     errorcode out int,				--返回错误代码
     errormsg out varchar2,	--返回错误参数
     p_org_id number    --机构代码
) is
/**
* REPORT公共卫生_冠心病管理统计---按性别
* 统计项 7岁以下儿童数  5岁以下儿童数 3岁以下儿童数  婴儿死亡数 婴儿数  新生儿死亡数 新生儿数 5岁以下儿童死亡数
*       实查人数 母乳喂养人数  新生儿访视人数 保健管理人数 3岁以下保健管理人数
* bus_type 4 管理卡  7 管理评估  2 随访
*/
  v_report_date  VARCHAR(8):= to_char(sysdate,'yyyymmdd'); --报表日期
  v_baby_days number := 10;    --出生10天以内为婴儿
  v_new_baby_days number := 30;  --出生30天以内为新生儿
  v_num number;
  v_create_date date := sysdate;--创建时间
begin
   select count(0) into v_num  from REPORT_PHEALTH_CHILD_WORK where REPORT_DATE = v_report_date and ORG_ID = p_org_id ;
   if v_num>0 then
      select create_date into v_create_date from REPORT_PHEALTH_CHILD_WORK where REPORT_DATE = v_report_date and ORG_ID = p_org_id  and rownum=1;
   end if;

   delete from REPORT_PHEALTH_CHILD_WORK where REPORT_DATE = v_report_date and ORG_ID = p_org_id;

   insert into REPORT_PHEALTH_CHILD_WORK(REPORT_DATE,SEVEN_SUM,FIVE_SUM,THREE_SUM,BABY_DEATH_SUM,BABY_SUM,NEONATE_DEATH_SUM,NEONATE_SUM,FIVE_DEATH_SUM,
               CHECK_SUM,BREAST_SUM,VISTIT_SUM,CARE_SUM,THREE_CARE_SUM,ORG_ID,UPDATE_TIME,CREATE_DATE)
   select v_report_date,
     -- 7岁以下儿童数
     (2 ),
     -- 5岁以下儿童数
     (2),
     -- 3岁以下儿童数
     (2),
     -- 婴儿死亡数
     (2),
     --婴儿数
     (2),
     --新生儿死亡数
     (2),
     --新生儿数
     (2),
     --5岁以下儿童死亡数
     (2),
     --实查人数 具体指什么人数
     (2),
     --母乳喂养人数
     (select count(0) from
         (select p.patient_id from phealth_soap_service p where p.patient_id in
            (select s.id from ehr_person s where s.pt_org_id = p_org_id and sysdate-s.birthday < 6*365) and p.bus_type = 41 group by p.patient_id)),
     --新生儿访视人数
     (select count(0) from
         (select p.patient_id from phealth_soap_service p where p.patient_id in
            (select s.id from ehr_person s where s.pt_org_id = p_org_id and sysdate-s.birthday < v_new_baby_days) and p.bus_type = 34 group by p.patient_id)),
     --保健管理人数
     (select count(0) from
         (select p.patient_id from phealth_soap_service p where p.patient_id in
            (select s.id from ehr_person s where s.pt_org_id = p_org_id ) and p.bus_type = 43 group by p.patient_id)),
     --3岁以下保健管理人数
     (select count(0) from
         (select p.patient_id from phealth_soap_service p where p.patient_id in
            (select s.id from ehr_person s where s.pt_org_id = p_org_id and sysdate-s.birthday < 3*365 ) and p.bus_type = 43 group by p.patient_id)),
      p_org_id,sysdate, v_create_date
   from ehr_person a
   where a.pt_org_id = p_org_id;
   errorcode := 0;
   errormsg := 'ok';

   exception when others then
   begin
        errorcode := -1;
        errormsg := SQLCODE||':'||SUBSTR(SQLERRM, 1, 200);
        rollback;
   end;
end SP_REPORT_PHEALTH_CHILD_WORK;

/

