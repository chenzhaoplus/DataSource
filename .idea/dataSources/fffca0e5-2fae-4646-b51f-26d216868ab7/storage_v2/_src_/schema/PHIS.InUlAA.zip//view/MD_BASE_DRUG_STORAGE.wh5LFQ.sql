create view MD_BASE_DRUG_STORAGE as
  select org_id, room_code, drug_code, factory_code, factory_name, store_unit_code, store_unit_name, retail_price,DRUG_DOSE, sum(store_amount) store_amount, sum(in_money) in_money, sum(batch_money) batch_money, sum(retail_money) retail_money
    from
   md_room_storage_detail t group by org_id, room_code, drug_code, factory_code, factory_name, store_unit_code, store_unit_name, retail_price,DRUG_DOSE
/

