create procedure SP_REPORT_EHR_AGE
 /*                                                                  */
 /*            SP_REPORT_EHR_AGE 年龄构成抽数据存储过程              */
 /********************************************************************/
AS
      REPORTTIME  VARCHAR(8);--报表时间
     -- NUM NUMBER; --序号

BEGIN

      REPORTTIME :=to_char(sysdate - 1,'yyyymmdd');

      begin
         savepoint point; ---记录保存点---

         --1.删除旧记录
          DELETE FROM REPORT_EHR_AGE WHERE REPORT_DATE = REPORTTIME ;


         --2.插入新记录
          INSERT INTO REPORT_EHR_AGE
                 (REPORT_DATE,ORG_ID,UPDATE_TIME,CREATE_DATE,AGE_TYPE,HJ_MAN,HJ_WOMAN,FHJ_MAN,FHJ_WOMAN,DISTRICT_ID)
          SELECT REPORTTIME,F.PT_ORG_ID , sysdate as UPDATE_TIME,sysdate as CREATE_DATE,F.AGE_TYPE,
                 SUM(F.HJ_MAN) as HJ_MAN,SUM(F.HJ_WOMAN) as HJ_WOMAN,SUM(F.FHJ_MAN) as FHJ_MAN,SUM(F.FHJ_WOMAN) as FHJ_WOMAN,
                F.DISTRICT_ID
          FROM (
               select PT_ORG_ID ,COMMITTEE as DISTRICT_ID, '0-5' as AGE_TYPE,
                         sum(case when jztype = '1' and sex = '1' then 1 else 0 end) as HJ_MAN,
                         sum(case when jztype = '1' and sex = '2' then 1 else 0 end) as HJ_WOMAN,
                         sum((case when jztype = '2' and sex = '1' then 1 else 0 end)+(case when jztype is null and sex = '1' then 1 else 0 end)) as FHJ_MAN,
                         sum((case when jztype = '2' and sex = '2' then 1 else 0 end)+(case when jztype is null and sex = '2' then 1 else 0 end)) as FHJ_WOMAN
               from   ehr_person
               where ( status = '0')
                     and (sysdate - birthday)<5*365 and COMMITTEE is not null
               group by PT_ORG_ID ,COMMITTEE

               union all

               select PT_ORG_ID ,COMMITTEE as DISTRICT_ID, '5-10' as AGE_TYPE,
                         sum(case when jztype = '1' and sex = '1' then 1 else 0 end) as HJ_MAN,
                         sum(case when jztype = '1' and sex = '2' then 1 else 0 end) as HJ_WOMAN,
                         sum((case when jztype = '2' and sex = '1' then 1 else 0 end)+(case when jztype is null and sex = '1' then 1 else 0 end)) as FHJ_MAN,
                         sum((case when jztype = '2' and sex = '2' then 1 else 0 end)+(case when jztype is null and sex = '2' then 1 else 0 end)) as FHJ_WOMAN
               from   ehr_person
               where ( status = '0')
                     and (sysdate - birthday)>=5*365 and (sysdate - birthday)<10*365
                     and COMMITTEE is not null
               group by PT_ORG_ID ,COMMITTEE

               union all

               select PT_ORG_ID ,COMMITTEE as DISTRICT_ID, '10-15' as AGE_TYPE,
                         sum(case when jztype = '1' and sex = '1' then 1 else 0 end) as HJ_MAN,
                         sum(case when jztype = '1' and sex = '2' then 1 else 0 end) as HJ_WOMAN,
                         sum((case when jztype = '2' and sex = '1' then 1 else 0 end)+(case when jztype is null and sex = '1' then 1 else 0 end)) as FHJ_MAN,
                         sum((case when jztype = '2' and sex = '2' then 1 else 0 end)+(case when jztype is null and sex = '2' then 1 else 0 end)) as FHJ_WOMAN
               from   ehr_person
               where ( status = '0')
                     and (sysdate - birthday)>=10*365 and (sysdate - birthday)<15*365
                     and COMMITTEE is not null
               group by PT_ORG_ID ,COMMITTEE

               union all

               select PT_ORG_ID ,COMMITTEE as DISTRICT_ID, '15-20' as AGE_TYPE,
                         sum(case when jztype = '1' and sex = '1' then 1 else 0 end) as HJ_MAN,
                         sum(case when jztype = '1' and sex = '2' then 1 else 0 end) as HJ_WOMAN,
                         sum((case when jztype = '2' and sex = '1' then 1 else 0 end)+(case when jztype is null and sex = '1' then 1 else 0 end)) as FHJ_MAN,
                         sum((case when jztype = '2' and sex = '2' then 1 else 0 end)+(case when jztype is null and sex = '2' then 1 else 0 end)) as FHJ_WOMAN
               from   ehr_person
               where ( status = '0')
                     and (sysdate - birthday)>=15*365 and (sysdate - birthday)<20*365
                     and COMMITTEE is not null
               group by PT_ORG_ID ,COMMITTEE

               union all

               select PT_ORG_ID ,COMMITTEE as DISTRICT_ID, '20-25' as AGE_TYPE,
                         sum(case when jztype = '1' and sex = '1' then 1 else 0 end) as HJ_MAN,
                         sum(case when jztype = '1' and sex = '2' then 1 else 0 end) as HJ_WOMAN,
                         sum((case when jztype = '2' and sex = '1' then 1 else 0 end)+(case when jztype is null and sex = '1' then 1 else 0 end)) as FHJ_MAN,
                         sum((case when jztype = '2' and sex = '2' then 1 else 0 end)+(case when jztype is null and sex = '2' then 1 else 0 end)) as FHJ_WOMAN
               from   ehr_person
               where ( status = '0')
                     and (sysdate - birthday)>=20*365 and (sysdate - birthday)<25*365
                     and COMMITTEE is not null
               group by PT_ORG_ID ,COMMITTEE

               union all

               select PT_ORG_ID ,COMMITTEE as DISTRICT_ID, '25-30' as AGE_TYPE,
                         sum(case when jztype = '1' and sex = '1' then 1 else 0 end) as HJ_MAN,
                         sum(case when jztype = '1' and sex = '2' then 1 else 0 end) as HJ_WOMAN,
                         sum((case when jztype = '2' and sex = '1' then 1 else 0 end)+(case when jztype is null and sex = '1' then 1 else 0 end)) as FHJ_MAN,
                         sum((case when jztype = '2' and sex = '2' then 1 else 0 end)+(case when jztype is null and sex = '2' then 1 else 0 end)) as FHJ_WOMAN
               from   ehr_person
               where ( status = '0')
                     and (sysdate - birthday)>=25*365 and (sysdate - birthday)<30*365
                     and COMMITTEE is not null
               group by PT_ORG_ID ,COMMITTEE

               union all

               select PT_ORG_ID ,COMMITTEE as DISTRICT_ID, '30-35' as AGE_TYPE,
                         sum(case when jztype = '1' and sex = '1' then 1 else 0 end) as HJ_MAN,
                         sum(case when jztype = '1' and sex = '2' then 1 else 0 end) as HJ_WOMAN,
                         sum((case when jztype = '2' and sex = '1' then 1 else 0 end)+(case when jztype is null and sex = '1' then 1 else 0 end)) as FHJ_MAN,
                         sum((case when jztype = '2' and sex = '2' then 1 else 0 end)+(case when jztype is null and sex = '2' then 1 else 0 end)) as FHJ_WOMAN
               from   ehr_person
               where ( status = '0')
                     and (sysdate - birthday)>=30*365 and (sysdate - birthday)<35*365
                     and COMMITTEE is not null
               group by PT_ORG_ID ,COMMITTEE

               union all

               select PT_ORG_ID ,COMMITTEE as DISTRICT_ID, '35-40' as AGE_TYPE,
                         sum(case when jztype = '1' and sex = '1' then 1 else 0 end) as HJ_MAN,
                         sum(case when jztype = '1' and sex = '2' then 1 else 0 end) as HJ_WOMAN,
                         sum((case when jztype = '2' and sex = '1' then 1 else 0 end)+(case when jztype is null and sex = '1' then 1 else 0 end)) as FHJ_MAN,
                         sum((case when jztype = '2' and sex = '2' then 1 else 0 end)+(case when jztype is null and sex = '2' then 1 else 0 end)) as FHJ_WOMAN
               from   ehr_person
               where ( status = '0')
                     and (sysdate - birthday)>=35*365 and (sysdate - birthday)<40*365
                     and COMMITTEE is not null
               group by PT_ORG_ID ,COMMITTEE

               union all

               select PT_ORG_ID ,COMMITTEE as DISTRICT_ID, '40-45' as AGE_TYPE,
                         sum(case when jztype = '1' and sex = '1' then 1 else 0 end) as HJ_MAN,
                         sum(case when jztype = '1' and sex = '2' then 1 else 0 end) as HJ_WOMAN,
                         sum((case when jztype = '2' and sex = '1' then 1 else 0 end)+(case when jztype is null and sex = '1' then 1 else 0 end)) as FHJ_MAN,
                         sum((case when jztype = '2' and sex = '2' then 1 else 0 end)+(case when jztype is null and sex = '2' then 1 else 0 end)) as FHJ_WOMAN
               from   ehr_person
               where ( status = '0')
                     and (sysdate - birthday)>=40*365 and (sysdate - birthday)<45*365
                     and COMMITTEE is not null
               group by PT_ORG_ID ,COMMITTEE

               union all

               select PT_ORG_ID ,COMMITTEE as DISTRICT_ID, '45-50' as AGE_TYPE,
                         sum(case when jztype = '1' and sex = '1' then 1 else 0 end) as HJ_MAN,
                         sum(case when jztype = '1' and sex = '2' then 1 else 0 end) as HJ_WOMAN,
                         sum((case when jztype = '2' and sex = '1' then 1 else 0 end)+(case when jztype is null and sex = '1' then 1 else 0 end)) as FHJ_MAN,
                         sum((case when jztype = '2' and sex = '2' then 1 else 0 end)+(case when jztype is null and sex = '2' then 1 else 0 end)) as FHJ_WOMAN
               from   ehr_person
               where ( status = '0')
                     and (sysdate - birthday)>=45*365 and (sysdate - birthday)<50*365
                     and COMMITTEE is not null
               group by PT_ORG_ID ,COMMITTEE

               union all

               select PT_ORG_ID ,COMMITTEE as DISTRICT_ID, '50-55' as AGE_TYPE,
                         sum(case when jztype = '1' and sex = '1' then 1 else 0 end) as HJ_MAN,
                         sum(case when jztype = '1' and sex = '2' then 1 else 0 end) as HJ_WOMAN,
                         sum((case when jztype = '2' and sex = '1' then 1 else 0 end)+(case when jztype is null and sex = '1' then 1 else 0 end)) as FHJ_MAN,
                         sum((case when jztype = '2' and sex = '2' then 1 else 0 end)+(case when jztype is null and sex = '2' then 1 else 0 end)) as FHJ_WOMAN
               from   ehr_person
               where ( status = '0')
                     and (sysdate - birthday)>=50*365 and (sysdate - birthday)<55*365
                     and COMMITTEE is not null
               group by PT_ORG_ID ,COMMITTEE

               union all

               select PT_ORG_ID ,COMMITTEE as DISTRICT_ID, '55-60' as AGE_TYPE,
                         sum(case when jztype = '1' and sex = '1' then 1 else 0 end) as HJ_MAN,
                         sum(case when jztype = '1' and sex = '2' then 1 else 0 end) as HJ_WOMAN,
                         sum((case when jztype = '2' and sex = '1' then 1 else 0 end)+(case when jztype is null and sex = '1' then 1 else 0 end)) as FHJ_MAN,
                         sum((case when jztype = '2' and sex = '2' then 1 else 0 end)+(case when jztype is null and sex = '2' then 1 else 0 end)) as FHJ_WOMAN
               from   ehr_person
               where ( status = '0')
                     and (sysdate - birthday)>=55*365 and (sysdate - birthday)<60*365
                     and COMMITTEE is not null
               group by PT_ORG_ID ,COMMITTEE

               union all

               select PT_ORG_ID ,COMMITTEE as DISTRICT_ID, '60-65' as AGE_TYPE,
                         sum(case when jztype = '1' and sex = '1' then 1 else 0 end) as HJ_MAN,
                         sum(case when jztype = '1' and sex = '2' then 1 else 0 end) as HJ_WOMAN,
                         sum((case when jztype = '2' and sex = '1' then 1 else 0 end)+(case when jztype is null and sex = '1' then 1 else 0 end)) as FHJ_MAN,
                         sum((case when jztype = '2' and sex = '2' then 1 else 0 end)+(case when jztype is null and sex = '2' then 1 else 0 end)) as FHJ_WOMAN
               from   ehr_person
               where ( status = '0')
                     and (sysdate - birthday)>=60*365 and (sysdate - birthday)<65*365
                     and COMMITTEE is not null
               group by PT_ORG_ID ,COMMITTEE

               union all

               select PT_ORG_ID ,COMMITTEE as DISTRICT_ID, '65-70' as AGE_TYPE,
                         sum(case when jztype = '1' and sex = '1' then 1 else 0 end) as HJ_MAN,
                         sum(case when jztype = '1' and sex = '2' then 1 else 0 end) as HJ_WOMAN,
                         sum((case when jztype = '2' and sex = '1' then 1 else 0 end)+(case when jztype is null and sex = '1' then 1 else 0 end)) as FHJ_MAN,
                         sum((case when jztype = '2' and sex = '2' then 1 else 0 end)+(case when jztype is null and sex = '2' then 1 else 0 end)) as FHJ_WOMAN
               from   ehr_person
               where ( status = '0')
                     and (sysdate - birthday)>=65*365 and (sysdate - birthday)<70*365
                     and COMMITTEE is not null
               group by PT_ORG_ID ,COMMITTEE

               union all

               select PT_ORG_ID ,COMMITTEE as DISTRICT_ID, '70-75' as AGE_TYPE,
                         sum(case when jztype = '1' and sex = '1' then 1 else 0 end) as HJ_MAN,
                         sum(case when jztype = '1' and sex = '2' then 1 else 0 end) as HJ_WOMAN,
                         sum((case when jztype = '2' and sex = '1' then 1 else 0 end)+(case when jztype is null and sex = '1' then 1 else 0 end)) as FHJ_MAN,
                         sum((case when jztype = '2' and sex = '2' then 1 else 0 end)+(case when jztype is null and sex = '2' then 1 else 0 end)) as FHJ_WOMAN
               from   ehr_person
               where ( status = '0')
                     and (sysdate - birthday)>=70*365 and (sysdate - birthday)<75*365
                     and COMMITTEE is not null
               group by PT_ORG_ID ,COMMITTEE

               union all

               select PT_ORG_ID ,COMMITTEE as DISTRICT_ID, '75-00' as AGE_TYPE,
                         sum(case when jztype = '1' and sex = '1' then 1 else 0 end) as HJ_MAN,
                         sum(case when jztype = '1' and sex = '2' then 1 else 0 end) as HJ_WOMAN,
                         sum((case when jztype = '2' and sex = '1' then 1 else 0 end)+(case when jztype is null and sex = '1' then 1 else 0 end)) as FHJ_MAN,
                         sum((case when jztype = '2' and sex = '2' then 1 else 0 end)+(case when jztype is null and sex = '2' then 1 else 0 end)) as FHJ_WOMAN
               from   ehr_person
               where ( status = '0')
                     and (sysdate - birthday)>=75*365
                     and COMMITTEE is not null
               group by PT_ORG_ID ,COMMITTEE
          ) F
          GROUP BY F.PT_ORG_ID ,F.DISTRICT_ID,F.AGE_TYPE;

          commit;

         --3.异常处理

          exception   when   others   then
            begin
              rollback to savepoint point;
              rollback;
            end;


      end;
end SP_REPORT_EHR_AGE;

/

