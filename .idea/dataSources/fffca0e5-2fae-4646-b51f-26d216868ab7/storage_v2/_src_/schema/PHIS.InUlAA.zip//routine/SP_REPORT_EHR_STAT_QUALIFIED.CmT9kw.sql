create procedure SP_REPORT_EHR_STAT_QUALIFIED
/************&&&&&&&&&&***************/
/***REPORT健康档案_健康档案建档统计及合格率*****/
/***********************************************/

as
 ISNULL_SEX        NUMBER(1);
 ISNULL_BIRTHDAY   NUMBER(1);
 ISNULL_IDNO       NUMBER(1);
 ISNULL_PPHONE     NUMBER(1);
 ISNULL_JZTYPE     NUMBER(1);
 ISNULL_NATIONALITY         NUMBER(1);
 ISNULL_BLOOD_TYPE          NUMBER(1);
 ISNULL_EDUCATE             NUMBER(1);
 ISNULL_OCCUPATION          NUMBER(1);
 ISNULL_MARRIED             NUMBER(1);
 ISNULL_PAY_TYPE_ID         NUMBER(1);
 ISNULL_ALLERGIC            NUMBER(1);
 IMPERFECT_CAUSE            NUMBER(1);
 -----------
 PHONE_NUMS                 NUMBER(2);
 FLAG                      char(1);--是否合格？？？
 IS_EXIST                   NUMBER(1);
 V_REPORT_DATE  VARCHAR(8);   ---报表时间
begin
  ISNULL_ALLERGIC :=1;
  IMPERFECT_CAUSE :=1;
  begin
    savepoint point; ---记录保存点---


     /*************************************************************/
     /********统计REPORT健康档案_健康档案建档统计及合格率**********/
     /***********************************************************/

      V_REPORT_DATE :=to_char(sysdate - 1,'yyyymmdd');
      ----
      delete report_ehr_stat_qualified t where  t.report_date=V_REPORT_DATE;
      -----------
      insert into report_ehr_stat_qualified(report_date,org_id,doctor_type,doctor_id,total_amount,cur_amount
      ,qualified_total_amount,qualified_cur_amount,unqualified_total_amount,unqualified_cur_amount,update_time,create_date,district_id)

     select V_REPORT_DATE,org_id,DOCTOR_TYPE,manager_id,sum(TOTAL_AMOUNT),sum(CUR_AMOUNT)
      ,sum(QUALIFIED_CUR_AMOUNT),sum(QUALIFIED_TOTAL_AMOUNT),sum(UNQUALIFIED_TOTAL_AMOUNT)
      ,sum(UNQUALIFIED_CUR_AMOUNT),sysdate,sysdate,district_id
        from(
          select t.org_id,t.district_id,t.manager_id,
          case when t.creater_id = t.manager_id then '2' else '1' end as DOCTOR_TYPE,
          count(0) as TOTAL_AMOUNT,
          sum(case when to_char(t.create_date,'yyyymmdd')=V_REPORT_DATE then 1 else 0 end) as CUR_AMOUNT,
          sum(case when t.status = '1' and to_char(t.archive_date,'yyyymmdd')=V_REPORT_DATE then 1 else 0 end) as QUALIFIED_CUR_AMOUNT,
          sum(case when t.status = '1' then 1 else 0 end) as QUALIFIED_TOTAL_AMOUNT,
          sum(case when t.status = '0' then 1 else 0 end) as UNQUALIFIED_TOTAL_AMOUNT,
          sum(case when t.status = '0' and to_char(t.archive_date,'yyyymmdd')=V_REPORT_DATE then 1 else 0 end) as UNQUALIFIED_CUR_AMOUNT
          from  REPORT_EHR_NOPASS_ARCHIVE t
          where t.isDeleted = '0'
          group by t.org_id,t.district_id,t.creater_id,t.manager_id
      ) group by org_id,district_id,manager_id,DOCTOR_TYPE;
     ------
     --commit;
     commit;
     --3.异常处理

        exception   when   others   then
          begin
            rollback to savepoint point;
            rollback;
          end;

  end;

end SP_REPORT_EHR_STAT_QUALIFIED;

/

