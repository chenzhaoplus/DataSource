create procedure SP_REPORT_EHR_NOPASS_ARCHIVE
/************************************************/
/*********REPORT健康档案_不完善健康档案*********/
/************&&&&&&&&&&***************/
/***REPORT健康档案_健康档案建档统计及合格率*****/
/***********************************************/

as
 ISNULL_SEX        NUMBER(1);
 ISNULL_BIRTHDAY   NUMBER(1);
 ISNULL_IDNO       NUMBER(1);
 ISNULL_PPHONE     NUMBER(1);
 ISNULL_JZTYPE     NUMBER(1);
 ISNULL_NATIONALITY         NUMBER(1);
 ISNULL_BLOOD_TYPE          NUMBER(1);
 ISNULL_EDUCATE             NUMBER(1);
 ISNULL_OCCUPATION          NUMBER(1);
 ISNULL_MARRIED             NUMBER(1);
 ISNULL_PAY_TYPE_ID         NUMBER(1);
 ISNULL_ALLERGIC            NUMBER(1);
 IMPERFECT_CAUSE            NUMBER(1);
 -----------
 PHONE_NUMS                 NUMBER(2);
 FLAG                      char(1);--是否合格？？？
 IS_EXIST                   NUMBER(1);
 V_REPORT_DATE  VARCHAR(8);   ---报表时间
begin
  ISNULL_ALLERGIC :=1;
  IMPERFECT_CAUSE :=1;
  begin
    savepoint point; ---记录保存点---

    ----  生成 REPORT_EHR_NOPASS_ARCHIVE 数据 begin
    --由于 java程序会实时修改以下表，所以隐藏，以下部分在第一次生成所有数据的时候有用

    delete REPORT_EHR_NOPASS_ARCHIVE;

    insert into REPORT_EHR_NOPASS_ARCHIVE(
    PATIENT_ID,ISNULL_SEX,ISNULL_BIRTHDAY,ISNULL_IDNO,ISNULL_JZTYPE
    ,ISNULL_NATIONALITY,ISNULL_BLOOD_TYPE,ISNULL_EDUCATE,ISNULL_OCCUPATION,ISNULL_MARRIED
    ,ISNULL_PAY_TYPE_ID,ISNULL_ALLERGIC,IMPERFECT_CAUSE
    ,ORG_ID,UPDATE_TIME,CREATE_DATE,ARCHIVE_DATE,CREATER_ID,MANAGER_ID,DISTRICT_ID)
    select t.id
    , case when t.sex is null then 0 else 1 END As sex
    , case when t.birthday is null then 0 else 1 END As birthday
    , case
      --证件类型  为“其他”时，证件号码不管是不是空，值都为0(不合格)
      --证件类型不为“其他”时，证件号码  为null或空时, 值为0
      --证件类型不为“其他”时，证件号码不为null并且不为空时, 值为1
      when t.papers_type = '99' then 0
      when ( ( t.papers_type != '99' ) and ( ( trim( t.idno ) is null )  ) ) then 0         --or ( trim.idno = '' )
      when ( ( t.papers_type != '99' ) and ( ( trim( t.idno ) is not null ) ) ) then 1      --and ( trim( t.idno ) != '' )
      END As idno
    , case when t.jztype is null then 0 else 1 END As jztype
    , case when t.nationality is null then 0 else 1 END As nationality
    , case when t.blood_type is null then 0 else 1 END As blood_type
    , case when t.educate is null then 0 else 1 END As educate
    , case when t.occupation is null then 0 else 1 END As occupation
    , case when t.married is null then 0 else 1 END As married
    , case when t.pay_type_id is null then 0 else 1 END As pay_type_id
    , 1, 1
    , t.PT_ORG_ID , sysdate, sysdate, t.archive_date, t.archive_user_id, t.admin_user_id, t.committee
    from ehr_person t
    where --( t.status = '0')
    --and
    ( t.archive_date is not null )
    and ( t.admin_user_id is not null )
    and ( t.archive_user_id is not null )
    and ( t.PT_ORG_ID  is not null )
    and ( t.committee is not null )
    ;

    update REPORT_EHR_NOPASS_ARCHIVE a set a.Isnull_Pphone = '0';
    update REPORT_EHR_NOPASS_ARCHIVE a
    set a.Isnull_Pphone = '1'
    where exists (
      select t1.person_id from ehr_phone t1
      where t1.person_id = a.patient_id
            and trim( t1.phone_num ) is not null
      group by t1.person_id
    )
    ;
    --大亚湾电话，证件号码暂时不做判断，Isnull_Pphone，ISNULL_IDNO都为1
    --    update REPORT_EHR_NOPASS_ARCHIVE a set a.Isnull_Pphone = '1';
    --    update REPORT_EHR_NOPASS_ARCHIVE a set a.ISNULL_IDNO = '1';

     ----判断是否合格
    UPDATE REPORT_EHR_NOPASS_ARCHIVE
    SET status = '1'
    WHERE 1=1
          and ISNULL_SEX=1
          and ISNULL_BIRTHDAY=1
          and ISNULL_IDNO=1
          and ISNULL_PPHONE = 1
          and ISNULL_JZTYPE=1      --户籍
          and ISNULL_NATIONALITY=1 --民族
          and ISNULL_BLOOD_TYPE=1  --血型
          and ISNULL_EDUCATE=1     --教育
          and ISNULL_OCCUPATION=1  --职业
          and ISNULL_MARRIED=1     --婚姻
          and ISNULL_PAY_TYPE_ID=1 --付费类型
--          and ISNULL_ALLERGIC=1 --插入时缺省为1
--          and IMPERFECT_CAUSE=1 --插入时缺省为1
    ;

    UPDATE REPORT_EHR_NOPASS_ARCHIVE SET isDeleted = '0';
    UPDATE REPORT_EHR_NOPASS_ARCHIVE r SET r.isDeleted = '1'
    Where r.patient_id in (
          select id from ehr_person ep where ep.status = '1'
    )
    ;

    ----  生成 REPORT_EHR_NOPASS_ARCHIVE 数据 end


     commit;
     --3.异常处理

        exception   when   others   then
          begin
            rollback to savepoint point;
            rollback;
          end;

  end;

end SP_REPORT_EHR_NOPASS_ARCHIVE;

/

