create procedure SP_REPORT_PHEALTH_DISTRICT_TJ(
     errorcode out int,        --返回错误代码
     errormsg out varchar2,	--返回错误参数
     committeesId number,    --居委会ID
     orgIdPar number    --居委会ID
) is
  hypertensionc number; --高血压人数
  diabetes number; --糖尿病人数
  tumour number; --肿瘤病人数
  reportDate varchar2(9); --报表日期
  countNum number; --指定居委会报表的总数
  currentDate date; --当前时间
  committeesName varchar2(50); --居委会名字
  orgName varchar2(50); --机构名字
begin
  reportDate:= to_char(sysdate,'YYYYMMDD');
  currentDate:= sysdate;
  --取得高血压人数
  select nvl(count(0),0) into hypertensionc from phealth_hypertensionc_person p inner join ehr_person e on p.person_id = e.id
  where e.committee = committeesId and p.if_confirmed = '1' and e.pt_org_id = orgIdPar;
  --取得糖尿病人数
  select nvl(count(0),0) into diabetes from phealth_diabetes_roster pd inner join ehr_person e on pd.PATIENT_ID = e.id
  where e.committee = committeesId and pd.if_confirmed = '1' and e.pt_org_id = orgIdPar;
  --取得肿瘤病人数
  select nvl(count(0),0) into tumour from phealth_tumour_roster pt inner join ehr_person e on pt.patient_id = e.id
  where e.committee = committeesId and pt.if_confirmed = '1' and e.pt_org_id = orgIdPar;
  --查询报表总数
  select count(0) into countNum from report_phealth_person where COMMITTEES_ID = committeesId and org_id = orgIdPar;
  --如果指定报表存在则更新
  if countNum > 0 then
    update report_phealth_person
    set REPORT_DATE = reportDate,HYPERTENSISONC_COUNT = hypertensionc,DIABETES_COUNT = diabetes,TUMOR_COUNT = tumour,
        UPDATE_DATE = currentDate
    where COMMITTEES_ID = committeesId and ORG_ID = orgIdPar;
  else
  --取得居委会名字和几个名字
  select F_NAME into committeesName from sys_districts where F_CODE = committeesId;
  select name into orgName from sys_organizations where id = orgIdPar;
  --新增
  insert into report_phealth_person (COMMITTEES_ID,COMMITTEES_NAME,ORG_ID,ORG_NAME,HYPERTENSISONC_COUNT,DIABETES_COUNT,
  TUMOR_COUNT,UPDATE_DATE,CREATE_DATE,REPORT_DATE)
  values (committeesId,committeesName,orgIdPar,orgName,hypertensionc,diabetes,tumour,currentDate,currentDate,reportDate);
  end if;
  errorcode:= 0;
  errormsg:= 'OK';
  exception when others then
   begin
        errorcode := -1;
        errormsg := SQLCODE||':'||SUBSTR(SQLERRM, 1, 200);
        rollback;
   end;
end SP_REPORT_PHEALTH_DISTRICT_TJ;

/

