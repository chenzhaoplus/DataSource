create procedure SP_REPORT_EHR_BEARING_WOMAN
/**
*REPORT健康档案_社区育龄妇女构成
*/
as
V_REPORT_DATE  VARCHAR(8);
begin
   V_REPORT_DATE :=to_char(sysdate - 1,'yyyymmdd');
   begin
     savepoint point; ---记录保存点---
     -----delete
     delete from REPORT_EHR_BEARING_WOMAN where report_date=V_REPORT_DATE;
     -- insert
      insert into REPORT_EHR_BEARING_WOMAN(REPORT_DATE,ORG_ID,HJ_AMOUNT,FHJ_AMOUNT,QT_AMOUNT,UPDATE_TIME,CREATE_DATE,DISTRICT_ID)
      select V_REPORT_DATE,PT_ORG_ID ,HJ_WOMAN,FHJ_WOMAN,OTHER_WOMAN,sysdate,sysdate,DISTRICT_ID
      from(
          select PT_ORG_ID ,COMMITTEE as DISTRICT_ID,
          sum(case when jztype = '1' and sex = '2' then 1 else 0 end) as HJ_WOMAN,
          sum(case when jztype = '2' and sex = '2' then 1 else 0 end) as FHJ_WOMAN,
          sum(case when jztype is null and sex = '2' then 1 else 0 end) as OTHER_WOMAN
          from phealth_born_women_roster t1,ehr_person t2
          where ( t2.status = '0') and  t1.patient_id=t2.id
                and  COMMITTEE is not null
          group by PT_ORG_ID ,COMMITTEE
      );
     --commit;
       commit;

        --3.异常处理

        exception   when   others   then
          begin
            rollback to savepoint point;
            rollback;
          end;
    end;
end SP_REPORT_EHR_BEARING_WOMAN;

/

