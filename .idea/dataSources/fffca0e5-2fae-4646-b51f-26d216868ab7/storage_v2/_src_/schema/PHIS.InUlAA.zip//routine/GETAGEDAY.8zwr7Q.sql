create function getAgeDay(birthday date) return varchar2 is
  var number;
begin
  if(trunc(sysdate, 'yyyy') = trunc(birthday, 'yyyy')) then
    if(trunc(sysdate, 'mm') = trunc(birthday, 'mm')) then
      return trunc(sysdate - birthday) || '天';
    else
      return trunc(months_between(sysdate, birthday)) || '月';
    end if;
  else
    return trunc(months_between(sysdate, birthday)/12) || '岁';
  end if;
end getAgeDay;
/

