create function calcuRadio(divider in number, dividend in number) return varchar2 is
  Result varchar2(20);
  var number;
begin
  if(dividend is null) then
    return null;
  end if;
  if(dividend =0) then
    return '100%';
  end if;
  var := abs(divider/dividend)*100;
  if(var>=0.0095) then
        Result :=  to_char(round(var,2),'fm9999999990.00') || '%';
  elsif (var>=0.00095) then
        Result := to_char(round(var*1,3),'fm9999999990.00') || '%';
  elsif (var>=0.000095) then
        Result := to_char(round(var*1,4),'fm9999999990.00') || '%';
  else
       Result :=  to_char(round(var,5),'fm9999999990.00') || '%';
  end if;
  return(Result);
end calcuRadio;
/

