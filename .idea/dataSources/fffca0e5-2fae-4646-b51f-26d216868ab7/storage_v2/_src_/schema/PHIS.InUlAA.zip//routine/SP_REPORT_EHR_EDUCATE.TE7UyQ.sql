create procedure SP_REPORT_EHR_EDUCATE
/**
*健康档案_学历统计
*/
as
 V_REPORT_DATE  VARCHAR(8);
begin
   V_REPORT_DATE :=to_char(sysdate - 1,'yyyymmdd');
   begin
     savepoint point; ---记录保存点---
     delete from REPORT_EHR_EDUCATE t where t.report_date=V_REPORT_DATE;
     --insert
     insert into report_ehr_educate(sums,educate,educate_name,org_id,update_time,create_date,report_date,district_id)
     select t4.sums,t4.educate,t4.educate_name,t4.PT_ORG_ID ,sysdate,sysdate,V_REPORT_DATE,committee
     from(
            select t2.educate,t2.PT_ORG_ID ,t2.committee,t2.sums,
            case when nvl(t2.educate,'98')='98' then '不详' else t3.dict_name end as educate_name
            from(
                 select t.educate,t.PT_ORG_ID ,t.committee,count(t.educate)sums
                 from (
                      select t1.PT_ORG_ID ,t1.committee,
                      case when nvl(t1.educate,'98')='98' then '98' else t1.educate end as educate
                      from ehr_person t1 where ( t1.status = '0') and  t1.PT_ORG_ID  is not null and t1.committee is not null
                 ) t
                 group by t.educate,t.PT_ORG_ID ,t.committee
            )t2
            left join std_gbdict_detail t3
            on t3.gb_code='GB/T4658-1984' and t3.detail_code=t2.educate
     )t4;

     commit;

        --3.异常处理

        exception   when   others   then
          begin
            rollback to savepoint point;
            rollback;
          end;

    end;
end SP_REPORT_EHR_EDUCATE;

/

