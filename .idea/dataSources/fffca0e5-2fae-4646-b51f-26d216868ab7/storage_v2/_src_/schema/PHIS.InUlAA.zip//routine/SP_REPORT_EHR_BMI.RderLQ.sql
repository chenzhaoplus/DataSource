create procedure SP_REPORT_EHR_BMI
  /********************************************************************/
   /*                                                                  */
   /*      健康档案_社区BMI指数                                       */
   /*                                                                  */
   /********************************************************************/
as
V_REPORT_DATE  VARCHAR(8);
begin
   V_REPORT_DATE :=to_char(sysdate - 1,'yyyymmdd');
   begin
     savepoint point; ---记录保存点---

     delete from REPORT_EHR_BMI where report_date=V_REPORT_DATE;

     --insert
     insert into REPORT_EHR_BMI(REPORT_DATE,ORG_ID,BMI_GROUP_ID,BMI_GROUP_NAME,BMI_SCOPE_M,AMOUNT_M,BMI_SCOPE_F,AMOUNT_F
     ,UPDATE_TIME,CREATE_DATE,HJ_MALE_COUNT,HJ_FEMALE_COUNT,FHJ_MALE_COUNT,FHJ_FEMALE_COUNT,DISTRICT_ID,AMOUNT)

     select V_REPORT_DATE,cc.PT_ORG_ID ,BMI_GROUP_ID,BMI_GROUP_NAME,BMI_SCOPE_M,acount_m,BMI_SCOPE_F,acount_f
     ,sysdate,sysdate,HJ_MAN,HJ_WOMAN,FHJ_MAN,FHJ_WOMAN,cc.DISTRICT_ID,AMOUNT
     from (
          select a.PT_ORG_ID ,a.DISTRICT_ID,a.BMI_GROUP_ID,b.BMI_GROUP_NAME,b.BMI_SCOPE_M,sum(a.acount_m) acount_m,
                 b.BMI_SCOPE_F,sum(a.acount_f) acount_f,sum(acount_m +acount_f) amount
          from  (
                select t.PT_ORG_ID , t.sex,t.committee as DISTRICT_ID,
                       case when bmi is null then 1006 else (
                            case when t.sex = '1' and t.bmi<20 then 1001
                                 when t.sex = '1' and t.bmi>=20 and t.bmi<25 then 1002
                                 when t.sex = '1' and t.bmi>=25 and t.bmi<30 then 1003
                                 when t.sex = '1' and t.bmi>=30 and t.bmi<35 then 1004
                                 when t.sex = '1' and t.bmi>=25 then 1005
                                 when t.sex = '2' and t.bmi<19 then 1001
                                 when t.sex = '2' and t.bmi>=19 and t.bmi<24 then 1002
                                 when t.sex = '2' and t.bmi>=24 and t.bmi<29 then 1003
                                 when t.sex = '2' and t.bmi>=29 and t.bmi<34 then 1004
                                 when t.sex = '2' and t.bmi>=34 then 1005
                            end
                       ) end BMI_GROUP_ID,
                       decode(t.sex,1,1,0) as acount_m,
                       decode(t.sex,2,1,0) as acount_f
                from   (
                    select e.PT_ORG_ID ,e.sex,e.committee,k.bmi
                    from   ehr_health_kpi k, ehr_person e
                    where ( e.status = '0') and k.person_id = e.id
                 ) t
          ) a
          inner join (
                select 1001 BMI_GROUP_ID,'过轻' BMI_GROUP_NAME,'< 20' BMI_SCOPE_M,'< 19' BMI_SCOPE_F from dual
                union all
                select 1002 BMI_GROUP_ID,'适中' BMI_GROUP_NAME,'20 - 25' BMI_SCOPE_M,'19 - 24' BMI_SCOPE_F from dual
                union all
                select 1003 BMI_GROUP_ID,'过重' BMI_GROUP_NAME,'25 - 30' BMI_SCOPE_M,'24 - 29' BMI_SCOPE_F from dual
                union all
                select 1004 BMI_GROUP_ID,'肥胖' BMI_GROUP_NAME,'30 - 35' BMI_SCOPE_M,'29 - 34' BMI_SCOPE_F from dual
                union all
                select 1005 BMI_GROUP_ID,'非常肥胖' BMI_GROUP_NAME,'> 35' BMI_SCOPE_M,'> 34' BMI_SCOPE_F from dual
                union all
                select 1006 BMI_GROUP_ID,'未填写' BMI_GROUP_NAME,'未填写' BMI_SCOPE_M,'未填写' BMI_SCOPE_F from dual
          ) b on a.BMI_GROUP_ID = b.BMI_GROUP_ID
          group by a.PT_ORG_ID ,a.DISTRICT_ID,a.BMI_GROUP_ID,b.BMI_GROUP_NAME,b.BMI_SCOPE_M,b.BMI_SCOPE_F
          ) cc
          left join
          (
            select PT_ORG_ID ,COMMITTEE as DISTRICT_ID,
               sum(case when jztype = '1' and sex = '1' then 1 else 0 end) as HJ_MAN,
               sum(case when jztype = '1' and sex = '2' then 1 else 0 end) as HJ_WOMAN,
               sum((case when jztype = '2' and sex = '1' then 1 else 0 end)+(case when jztype is null and sex = '1' then 1 else 0 end)) as FHJ_MAN,
               sum((case when jztype = '2' and sex = '2' then 1 else 0 end)+(case when jztype is null and sex = '2' then 1 else 0 end)) as FHJ_WOMAN
                from   ehr_person
                where ( status = '0') and COMMITTEE is not null
                group by PT_ORG_ID ,COMMITTEE
           )dd
           on cc.PT_ORG_ID =dd.PT_ORG_ID  and cc.DISTRICT_ID=dd.DISTRICT_ID;
      --commit;
       commit;

        --3.异常处理

        exception   when   others   then
          begin
            rollback to savepoint point;
            rollback;
          end;

     end;
end SP_REPORT_EHR_BMI;

/

