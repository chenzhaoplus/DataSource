create procedure SP_REPORT_PHEALTH_MENTAL(
     errorcode out int,        --返回错误代码
     errormsg out varchar2,  --返回错误参数
     p_org_id number    --机构代码
) is
/**
* REPORT公共卫生_精神病管理考核指标
* 统计项 患病总人数   已管理人数   规范管理人数  按时服药人数 复发人数
* bus_type 24 管理卡  19 管理评估  17 随访
*/
  v_report_date  VARCHAR(8):= to_char(sysdate,'yyyymmdd'); --报表日期
  v_icd10 varchar(100) := 'I10.X02';     --诊断对应ICD10编码
  v_spec_id number := 10011;
  v_num number;  --已存在统计数据总数
  v_person_count number; --患病总人数
  v_spec_count number; --已管理人数
  v_check_count number; --规范管理人数
  v_drug_count number; --按时服药人数
  v_relapse_count number; --复发人数
  v_code_drug varchar2(50) := '10000392';--按时服药数据元代码
--  v_code_drug_value varchar(200) := '5146001, 5146002, 1';--按时服药相应数据元值（不同页面不同值都可理解为按时服药，所以有3个值）
  v_code_drug_value_1 varchar(10) :='1';--按时服药相应数据元值（不同页面不同值都可理解为按时服药，所以有3个值）
  v_code_drug_value_2 varchar(10) :='5146001';--按时服药相应数据元值（不同页面不同值都可理解为按时服药，所以有3个值）
  v_code_drug_value_3 varchar(10) :='5146002';--按时服药相应数据元值（不同页面不同值都可理解为按时服药，所以有3个值）
  v_start_time_code varchar(20) := '10000257'; --初次发病时间对应数据元值
begin
  select count(0) into v_num from REPORT_PHEALTH_MENTAL where REPORT_DATE = v_report_date and ORG_ID = p_org_id and SPEC_ID = v_spec_id;
  -- 患病总人数
  select count(0) into v_person_count
  from phealth_mental_illness_roster r
  inner join ehr_person ep on ( (r.patient_id = ep.id) and (ep.status = 0) and (ep.pt_org_id = p_org_id) );
  -- 已管理人数
  select count(0) into v_spec_count from phealth_spec_case where spec_id = v_spec_id
        and person_id in (select id from ehr_person where pt_org_id = p_org_id and (status = 0) );
  -- 规范管理人数
  select count(0) into v_check_count from
  (
    select
    (select count(0) from phealth_soap_service where patient_id = pids.patient_id and bus_type=24 and ( status = '0')) cardNum,
    --(select count(0) from phealth_soap_service where patient_id = pids.patient_id and bus_type=19 and ( status = '0')) evaluteNum,
    (select count(0) from phealth_soap_service where patient_id = pids.patient_id and bus_type=20 and ( status = '0')) visitNum
    from (
         select  distinct patient_id from phealth_soap_service
         where patient_id in (
               select id from ehr_person where pt_org_id = p_org_id and (status = 0)
         ) and ( status = '0')
    ) pids
  ) tt
  where tt.cardNum>0
  --and tt.evaluteNum>0
  and tt.visitNum>0;
  --按时服药人数
  select count( distinct s2.patient_id ) into v_drug_count
  from PHEALTH_SOAP_SERVICE_metadata s2,
  (
     select s.patient_id, max(s.measure_date) as measure_date
     from PHEALTH_SOAP_SERVICE_metadata s
     inner join ehr_person e on s.Patient_Id = e.id  and (e.status = 0)
     inner join phealth_mental_illness_roster r on (r.patient_id = e.id)
     where e.pt_org_id = p_org_id and ( s.status = '0')
     group by s.patient_id
  ) s3
  where ( s2.metadata_code = v_code_drug )
  and ( s2.metadata_value in ( v_code_drug_value_1, v_code_drug_value_2, v_code_drug_value_3  ) )
  and ( s2.patient_id = s3.patient_id ) and ( s2.measure_date = s3.measure_date )
  and ( s2.status = '0')
  ;
  --复发人数
  select count( distinct s2.patient_id ) into v_relapse_count
  from PHEALTH_SOAP_SERVICE_metadata s2,
  (
     select s.patient_id, max(s.measure_date) as measure_date
     from PHEALTH_SOAP_SERVICE_metadata s
     inner join ehr_person e on s.Patient_Id = e.id  and (e.status = 0)
     inner join phealth_mental_illness_roster r on (r.patient_id = e.id)
     where e.pt_org_id = p_org_id and ( s.status = '0')
     group by s.patient_id
  ) s3
  where ( s2.metadata_code = v_start_time_code ) --初次发病时间有数据，不为null，即是复发
  and ( s2.patient_id = s3.patient_id ) and ( s2.measure_date = s3.measure_date )
  and ( s2.status = '0')
  ;

  if v_num>0 then
    update REPORT_PHEALTH_MENTAL
    set PERSON_COUNT = v_person_count,
        SPEC_COUNT = v_spec_count,
        CHECK_COUNT = v_check_count,
        DURG_COUNT = v_drug_count,
        RELAPSE_COUNT = v_relapse_count,
        UPDATE_TIME = sysdate
    where REPORT_DATE = v_report_date and ORG_ID = p_org_id and SPEC_ID = v_spec_id;
  else
    insert into REPORT_PHEALTH_MENTAL(REPORT_DATE, ORG_ID, SPEC_ID, PERSON_COUNT, SPEC_COUNT, CHECK_COUNT, DURG_COUNT, RELAPSE_COUNT, UPDATE_TIME, CREATE_DATE)
    values(v_report_date, p_org_id, v_spec_id, v_person_count, v_spec_count, v_check_count, v_drug_count, v_relapse_count, sysdate, sysdate);
  end if;
  errorcode := 0;
  errormsg := 'ok';

  commit;
  exception when others then
  begin
      errorcode := -1;
      errormsg := SQLCODE||':'||SUBSTR(SQLERRM, 1, 200);
      rollback;
  end;
end SP_REPORT_PHEALTH_MENTAL;
/

