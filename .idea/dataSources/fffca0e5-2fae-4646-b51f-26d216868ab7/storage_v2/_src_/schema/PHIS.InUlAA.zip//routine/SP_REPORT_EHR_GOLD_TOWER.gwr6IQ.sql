create procedure SP_REPORT_EHR_GOLD_TOWER
  /********************************************************************/
   /*                                                                  */
   /*          健康档案_社区人口金字塔                                   */
   /*                                                                  */
   /********************************************************************/
as
 V_REPORT_DATE  VARCHAR(8);
begin
   V_REPORT_DATE :=to_char(sysdate - 1,'yyyymmdd');
   begin
     savepoint point; ---记录保存点---

     --1.删除旧记录
       DELETE FROM REPORT_EHR_GOLD_TOWER WHERE REPORT_DATE = V_REPORT_DATE ;
     --2.插入新记录
     insert into report_ehr_gold_tower(report_date,org_id,sex,num_one,num_two,num_three,num_four,num_five,num_six
     ,num_seven,num_eight,num_nine,num_ten,num_eleven,num_twelve,num_thirteen,num_fourteen,num_fifteen,num_totl
     ,update_time,create_date,district_id)
     select V_REPORT_DATE,f.PT_ORG_ID ,f.sex,sum(num_one)as num_one,sum(num_two) as num_two, sum(num_three)as num_three,  sum(num_four) as num_four,
     sum(num_five) as num_five,  sum(num_six) as num_six
     , sum(num_seven) as num_seven,  sum(num_eight) as num_eight,  sum(num_nine) as num_nine,  sum(num_ten) as num_ten,  sum(num_eleven) as num_eleven,
     sum(num_twelve) as num_twelve,  sum(num_thirteen) as num_thirteen,  sum(num_fourteen) as num_fourteen,  sum(num_fifteen) as num_fifteen,
     sum(num_totl) as num_totl,sysdate,sysdate,f.DISTRICT_ID
     from(
         select PT_ORG_ID ,COMMITTEE as DISTRICT_ID, sex,
         count(0) as NUM_ONE,0 as num_two, 0 as num_three, 0 as num_four, 0 as num_five, 0 as num_six
         , 0 as num_seven, 0 as num_eight, 0 as num_nine, 0 as num_ten, 0 as num_eleven,
         0 as num_twelve, 0 as num_thirteen, 0 as num_fourteen, 0 as num_fifteen, 0 as num_totl
         from   ehr_person
         where ( status = '0') and  (sysdate - birthday)<5*365 and COMMITTEE is not null
         group by PT_ORG_ID ,sex,COMMITTEE

         union all

         select PT_ORG_ID ,COMMITTEE as DISTRICT_ID, sex,
         0 as NUM_ONE,count(0) as num_two, 0 as num_three, 0 as num_four, 0 as num_five, 0 as num_six
         , 0 as num_seven, 0 as num_eight, 0 as num_nine, 0 as num_ten, 0 as num_eleven,
         0 as num_twelve, 0 as num_thirteen, 0 as num_fourteen, 0 as num_fifteen, 0 as num_totl
         from   ehr_person
         where ( status = '0') and (sysdate - birthday)>=5*365
         and    (sysdate - birthday)<10*365   and COMMITTEE is not null
         group by PT_ORG_ID ,sex,COMMITTEE

         union all

         select PT_ORG_ID ,COMMITTEE as DISTRICT_ID, sex,
         0 as NUM_ONE,0 as num_two, count(0) as num_three, 0 as num_four, 0 as num_five, 0 as num_six
         , 0 as num_seven, 0 as num_eight, 0 as num_nine, 0 as num_ten, 0 as num_eleven,
         0 as num_twelve, 0 as num_thirteen, 0 as num_fourteen, 0 as num_fifteen, 0 as num_totl
         from   ehr_person
         where ( status = '0') and (sysdate - birthday)>=10*365
         and    (sysdate - birthday)<15*365
         and COMMITTEE is not null
         group by PT_ORG_ID ,sex,COMMITTEE

         union all

         select PT_ORG_ID ,COMMITTEE as DISTRICT_ID, sex,
         0 as NUM_ONE,0 as num_two, 0 as num_three, count(0) as num_four, 0 as num_five, 0 as num_six
         , 0 as num_seven, 0 as num_eight, 0 as num_nine, 0 as num_ten, 0 as num_eleven,
         0 as num_twelve, 0 as num_thirteen, 0 as num_fourteen, 0 as num_fifteen, 0 as num_totl
         from   ehr_person
         where ( status = '0') and (sysdate - birthday)>=15*365
         and    (sysdate - birthday)<20*365
         and COMMITTEE is not null
         group by PT_ORG_ID ,sex,COMMITTEE

         union all

         select PT_ORG_ID ,COMMITTEE as DISTRICT_ID, sex,
         0 as NUM_ONE,0 as num_two, 0 as num_three, 0 as num_four, count(0) as num_five, 0 as num_six
         , 0 as num_seven, 0 as num_eight, 0 as num_nine, 0 as num_ten, 0 as num_eleven,
         0 as num_twelve, 0 as num_thirteen, 0 as num_fourteen, 0 as num_fifteen, 0 as num_totl
         from   ehr_person
         where  ( status = '0') and  (sysdate - birthday)>=20*365
         and    (sysdate - birthday)<25*365
         and COMMITTEE is not null
         group by PT_ORG_ID ,sex,COMMITTEE

         union all

         select PT_ORG_ID ,COMMITTEE as DISTRICT_ID, sex,
         0 as NUM_ONE,0 as num_two, 0 as num_three, 0 as num_four, 0 as num_five, count(0) as num_six
         , 0 as num_seven, 0 as num_eight, 0 as num_nine, 0 as num_ten, 0 as num_eleven,
         0 as num_twelve, 0 as num_thirteen, 0 as num_fourteen, 0 as num_fifteen, 0 as num_totl
         from   ehr_person
         where ( status = '0') and (sysdate - birthday)>=25*365
         and    (sysdate - birthday)<30*365
         and COMMITTEE is not null
         group by PT_ORG_ID ,sex,COMMITTEE

         union all

         select PT_ORG_ID ,COMMITTEE as DISTRICT_ID, sex,
         0 as NUM_ONE,0 as num_two, 0 as num_three, 0 as num_four, 0 as num_five, 0 as num_six
         , count(0) as num_seven, 0 as num_eight, 0 as num_nine, 0 as num_ten, 0 as num_eleven,
         0 as num_twelve, 0 as num_thirteen, 0 as num_fourteen, 0 as num_fifteen, 0 as num_totl
         from   ehr_person
         where ( status = '0') and (sysdate - birthday)>=30*365
         and    (sysdate - birthday)<35*365
         and COMMITTEE is not null
         group by PT_ORG_ID ,sex,COMMITTEE

         union all

         select PT_ORG_ID ,COMMITTEE as DISTRICT_ID, sex,
         0 as NUM_ONE,0 as num_two, 0 as num_three, 0 as num_four, 0 as num_five, 0 as num_six
         , 0 as num_seven, count(0) as num_eight, 0 as num_nine, 0 as num_ten, 0 as num_eleven,
         0 as num_twelve, 0 as num_thirteen, 0 as num_fourteen, 0 as num_fifteen, 0 as num_totl
         from   ehr_person
         where ( status = '0') and (sysdate - birthday)>=35*365
         and    (sysdate - birthday)<40*365
         and COMMITTEE is not null
         group by PT_ORG_ID ,sex,COMMITTEE

         union all

         select PT_ORG_ID ,COMMITTEE as DISTRICT_ID, sex,
         0 as NUM_ONE,0 as num_two, 0 as num_three, 0 as num_four, 0 as num_five, 0 as num_six
         , 0 as num_seven, 0 as num_eight, count(0) as num_nine, 0 as num_ten, 0 as num_eleven,
         0 as num_twelve, 0 as num_thirteen, 0 as num_fourteen, 0 as num_fifteen, 0 as num_totl
         from   ehr_person
         where ( status = '0') and (sysdate - birthday)>=40*365
         and    (sysdate - birthday)<45*365
         and COMMITTEE is not null
         group by PT_ORG_ID ,sex,COMMITTEE

         union all

         select PT_ORG_ID ,COMMITTEE as DISTRICT_ID, sex,
         0 as NUM_ONE,0 as num_two, 0 as num_three, 0 as num_four, 0 as num_five, 0 as num_six
         , 0 as num_seven, 0 as num_eight, 0 as num_nine, count(0) as num_ten, 0 as num_eleven,
         0 as num_twelve, 0 as num_thirteen, 0 as num_fourteen, 0 as num_fifteen, 0 as num_totl
         from   ehr_person
         where ( status = '0') and (sysdate - birthday)>=45*365
         and    (sysdate - birthday)<50*365
         and COMMITTEE is not null
         group by PT_ORG_ID ,sex,COMMITTEE

         union all

         select PT_ORG_ID ,COMMITTEE as DISTRICT_ID, sex,
         0 as NUM_ONE,0 as num_two, 0 as num_three, 0 as num_four, 0 as num_five, 0 as num_six
         , 0 as num_seven, 0 as num_eight, 0 as num_nine, 0 as num_ten, count(0) as num_eleven,
         0 as num_twelve, 0 as num_thirteen, 0 as num_fourteen, 0 as num_fifteen, 0 as num_totl
         from   ehr_person
         where ( status = '0') and (sysdate - birthday)>=50*365
         and    (sysdate - birthday)<55*365
         and COMMITTEE is not null
         group by PT_ORG_ID ,sex,COMMITTEE

         union all

         select PT_ORG_ID ,COMMITTEE as DISTRICT_ID, sex,
         0 as NUM_ONE,0 as num_two, 0 as num_three, 0 as num_four, 0 as num_five, 0 as num_six
         , 0 as num_seven, 0 as num_eight, 0 as num_nine, 0 as num_ten, 0 as num_eleven,
         count(0) as num_twelve, 0 as num_thirteen, 0 as num_fourteen, 0 as num_fifteen, 0 as num_totl
         from   ehr_person
         where ( status = '0') and (sysdate - birthday)>=55*365
         and    (sysdate - birthday)<60*365
         and COMMITTEE is not null
         group by PT_ORG_ID ,sex,COMMITTEE

         union all

         select PT_ORG_ID ,COMMITTEE as DISTRICT_ID, sex,
           0 as NUM_ONE,0 as num_two, 0 as num_three, 0 as num_four, 0 as num_five, 0 as num_six
         , 0 as num_seven, 0 as num_eight, 0 as num_nine, 0 as num_ten, 0 as num_eleven,
         0 as num_twelve, count(0)  as num_thirteen, 0 as num_fourteen, 0 as num_fifteen, 0 as num_totl
         from   ehr_person
         where ( status = '0') and (sysdate - birthday)>=60*365
         and    (sysdate - birthday)<65*365
         and COMMITTEE is not null
         group by PT_ORG_ID ,sex,COMMITTEE

         union all

         select PT_ORG_ID ,COMMITTEE as DISTRICT_ID, sex,
         0 as NUM_ONE,0 as num_two, 0 as num_three, 0 as num_four, 0 as num_five, 0 as num_six
         , 0 as num_seven, 0 as num_eight, 0 as num_nine, 0 as num_ten, 0 as num_eleven,
         0 as num_twelve, 0  as num_thirteen, count(0) as num_fourteen, 0 as num_fifteen, 0 as num_totl
         from   ehr_person
         where ( status = '0') and (sysdate - birthday)>=65*365
         and    (sysdate - birthday)<70*365
         and COMMITTEE is not null
         group by PT_ORG_ID ,sex,COMMITTEE

         union all

         select PT_ORG_ID ,COMMITTEE as DISTRICT_ID, sex,
         0 as NUM_ONE,0 as num_two, 0 as num_three, 0 as num_four, 0 as num_five, 0 as num_six
         , 0 as num_seven, 0 as num_eight, 0 as num_nine, 0 as num_ten, 0 as num_eleven,
         0 as num_twelve, 0  as num_thirteen, 0 as num_fourteen, count(0) as num_fifteen, 0 as num_totl
         from   ehr_person
         where ( status = '0') and (sysdate - birthday)>=70*365
         and    (sysdate - birthday)<75*365
         and COMMITTEE is not null
         group by PT_ORG_ID ,sex,COMMITTEE

         union all

         select PT_ORG_ID ,COMMITTEE as DISTRICT_ID, sex,
         0 as NUM_ONE,0 as num_two, 0 as num_three, 0 as num_four, 0 as num_five, 0 as num_six
         , 0 as num_seven, 0 as num_eight, 0 as num_nine, 0 as num_ten, 0 as num_eleven,
         0 as num_twelve, 0  as num_thirteen, 0 as num_fourteen, 0 as num_fifteen, count(0) as num_totl
         from   ehr_person
         where ( status = '0') and (sysdate - birthday)>=75*365
         and COMMITTEE is not null
         group by PT_ORG_ID ,sex,COMMITTEE

     ) f group by PT_ORG_ID ,sex,DISTRICT_ID;

     commit;
     --3.异常处理

        exception   when   others   then
          begin
            rollback to savepoint point;
            rollback;
          end;
    end;
end SP_REPORT_EHR_GOLD_TOWER;

/

