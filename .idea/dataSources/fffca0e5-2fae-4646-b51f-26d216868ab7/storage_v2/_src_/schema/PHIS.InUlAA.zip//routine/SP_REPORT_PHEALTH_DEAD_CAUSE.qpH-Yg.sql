create procedure SP_REPORT_PHEALTH_DEAD_CAUSE(
     errorcode out int,				--返回错误代码
     errormsg out varchar2,	--返回错误参数
     p_org_id number    --机构代码
) is
/**
* REPORT公共卫生_儿童保健考核指标统计
* 统计项 死亡人数 辖区管理档案数
* bus_type 34 新生儿家庭视访记录  58 分娩登记表
*
*/
  v_report_date  VARCHAR(8):= to_char(sysdate,'yyyymmdd'); --报表日期
  v_num number;
  v_dead_reason_id varchar2(20) := '1234';
  v_dead_reason_name varchar2(200) := 'deadname';
  v_create_date date := sysdate;--创建时间
begin
   select count(0) into v_num  from REPORT_PHEALTH_DEAD_CAUSE where REPORT_DATE = v_report_date and ORG_ID = p_org_id ;
   if v_num>0 then
      select create_date into v_create_date from REPORT_PHEALTH_DEAD_CAUSE where REPORT_DATE = v_report_date and ORG_ID = p_org_id and  rownum=1;
   end if;

   delete from REPORT_PHEALTH_DEAD_CAUSE where REPORT_DATE = v_report_date and ORG_ID = p_org_id ;

   insert into REPORT_PHEALTH_DEAD_CAUSE(SUMS,DEAD_ICD10,DEAD_NAME,REPORT_DATE,PERSON_MNG_SUM,ORG_ID,UPDATE_TIME,CREATE_DATE)
   select
     -- 死亡人数
     (select count(0) from ehr_person
          where pt_org_id = p_org_id and sysdate-birthday < 36*30
          group by id
      ),
      v_dead_reason_id,v_dead_reason_name,
      v_report_date,
     -- 辖区管理档案数
     (select count(0) from ehr_person where pt_org_id = p_org_id ),
      p_org_id,
     sysdate, v_create_date
   from ehr_person a
   where a.pt_org_id = p_org_id;
   errorcode := 0;
   errormsg := 'ok';

   exception when others then
   begin
        errorcode := -1;
        errormsg := SQLCODE||':'||SUBSTR(SQLERRM, 1, 200);
        rollback;
   end;
end SP_REPORT_PHEALTH_DEAD_CAUSE;

/

