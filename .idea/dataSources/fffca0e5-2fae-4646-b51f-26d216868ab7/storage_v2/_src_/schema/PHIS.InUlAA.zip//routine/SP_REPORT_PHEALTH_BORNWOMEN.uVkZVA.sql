create procedure SP_REPORT_PHEALTH_BORNWOMEN(
     errorcode out int,				--返回错误代码
     errormsg out varchar2,	--返回错误参数
     p_org_id number    --机构代码
) is
/**
* REPORT公共卫生_孕产妇统计
* 统计项 育龄妇女总人数   孕妇人数   产妇人数
*/
  v_report_date  VARCHAR(8):= to_char(sysdate,'yyyymmdd'); --报表日期
  v_spec_id number := 10003;
  v_num number;  --已存在统计数据总数
  v_person_count number; --育龄妇女总人数
  v_born_count number; --孕妇人数
  v_borned_count number; --产妇人数
begin
   select count(0) into v_num from REPORT_PHEALTH_BORNWOMEN where REPORT_DATE = v_report_date and ORG_ID = p_org_id and SPEC_ID = v_spec_id;
   -- 育龄妇女总人数
   select count(0) into v_person_count from PHEALTH_BORN_WOMEN_ROSTER
          where PATIENT_ID in (select id from ehr_person where pt_org_id = p_org_id and (status = 0));-- and if_create_card='0';
   -- 孕妇人数
   select count(0) into v_born_count from PHEALTH_BORN_WOMEN_ROSTER
          where PATIENT_ID in (select id from ehr_person where pt_org_id = p_org_id and (status = 0)) and if_create_card='1' and IF_BORNED_CARD='0';
   -- 产妇人数
   select count(0) into v_borned_count from PHEALTH_BORN_WOMEN_ROSTER
          where PATIENT_ID in (select id from ehr_person where pt_org_id = p_org_id and (status = 0)) and IF_BORNED_CARD='1';

   if v_num>0 then
      update REPORT_PHEALTH_BORNWOMEN
      set PERSON_COUNT = v_person_count,
          BORN_COUNT = v_born_count,
          BORNED_COUNT = v_borned_count,
          UPDATE_TIME = sysdate
      where REPORT_DATE = v_report_date and ORG_ID = p_org_id and SPEC_ID = v_spec_id;
   else
       insert into REPORT_PHEALTH_BORNWOMEN(REPORT_DATE, ORG_ID, SPEC_ID, PERSON_COUNT, BORN_COUNT, BORNED_COUNT, UPDATE_TIME, CREATE_DATE)
       values(v_report_date, p_org_id, v_spec_id, v_person_count, v_born_count, v_borned_count, sysdate, sysdate);
   end if;
   errorcode := 0;
   errormsg := 'ok';

   commit;
   exception when others then
   begin
        errorcode := -1;
        errormsg := SQLCODE||':'||SUBSTR(SQLERRM, 1, 200);
        rollback;
   end;
end SP_REPORT_PHEALTH_BORNWOMEN;

/

