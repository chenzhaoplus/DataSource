create procedure SP_REPORT_PHEALTH_HY_AGE(
     errorcode out int,				--返回错误代码
     errormsg out varchar2,	--返回错误参数
     p_org_id number    --机构代码
) is
/**
* REPORT公共卫生_高血压管理统计---按年龄
* 统计项 患病总人数   已管理人数   规范管理人数  血压达标人数
* bus_type 4 管理卡  7 管理评估  2 随访
*/
  v_report_date  VARCHAR(8):= to_char(sysdate,'yyyymmdd'); --报表日期
  v_icd10 varchar(100) := 'I10.X02';     --诊断对应ICD10编码
  v_spec_id number := 10005;
  v_num number;
  v_create_date date := sysdate;--创建时间
  v_loop number := 15;
  v_loop_inc number := 5;
  v_loop_begin number:=0;
  v_loop_end number:=0;
begin
   select count(0) into v_num  from REPORT_PHEALTH_HY_AGE where REPORT_DATE = v_report_date and ORG_ID = p_org_id and SPEC_ID = v_spec_id;
   if v_num>0 then
      select create_date into v_create_date from REPORT_PHEALTH_HY_AGE where REPORT_DATE = v_report_date and ORG_ID = p_org_id and SPEC_ID = v_spec_id and rownum=1;
   end if;

   delete from REPORT_PHEALTH_HY_AGE where REPORT_DATE = v_report_date and ORG_ID = p_org_id and SPEC_ID = v_spec_id;
   --75岁以上
   insert into REPORT_PHEALTH_HY_AGE(REPORT_DATE,ORG_ID,SPEC_ID,AGE_GROUP_ID,AGE_GROUP_NAME,PERSON_COUNT,SPEC_COUNT,CHECK_COUNT,TO_PAR_COUNT,UPDATE_TIME,CREATE_DATE)
       select v_report_date, p_org_id, v_spec_id,100, '75岁以上',
         -- 患病总人数
         (
           select count(0) from phealth_hypertensionc_person r
           inner join ehr_person ep on ( (r.person_id = ep.id) and (ep.status = 0)
           and (ep.pt_org_id = p_org_id) )
           where ( sysdate-ep.birthday >= v_loop*v_loop_inc*365)
--         select count(0) from ehr_issue where to_char(create_date,'yyyymmdd')= v_report_date and icd10 = v_icd10
--                and person_id in (select id from ehr_person where pt_org_id = p_org_id and sysdate-birthday >= v_loop*v_loop_inc*365)
         ),
         -- 已管理人数
         (select count(0) from phealth_spec_case where spec_id = v_spec_id
                and person_id in (select id from ehr_person where pt_org_id = p_org_id and sysdate-birthday >= v_loop*v_loop_inc*365
                               and status = 0
                )),
         -- 规范管理人数
         (select count(0) from
            (
            select
            (select count(0) from phealth_soap_service where patient_id = pids.id and bus_type=4 and ( status = '0')) cardNum,
            (select count(0) from phealth_soap_service where patient_id = pids.id and bus_type=7 and ( status = '0')) evaluteNum,
            (select count(0) from phealth_soap_service where patient_id = pids.id and bus_type=2 and ( status = '0')) visitNum
            from
            (select id from ehr_person where pt_org_id = p_org_id and sysdate-birthday >=  v_loop*v_loop_inc*365
             and status = 0
            ) pids
            ) tt
         where tt.cardNum>0 and tt.evaluteNum>0 and tt.visitNum>0),
         --血压达标人数
         (
            select count(a.id) from ehr_health_kpi a
            inner join ehr_person b on a.person_id = b.id and b.pt_org_id = p_org_id
                       and sysdate-b.birthday >=  v_loop*v_loop_inc*365
                       and b.status = 0
            inner join phealth_spec_case c on a.person_id = c.person_id and c.spec_id = v_spec_id
            where checkPressureToPar(b.birthday, a.leftdiastolicpressure, a.leftsystolicpressure)=1
         ),
         sysdate, v_create_date
       from dual;
   --0至75岁
   while v_loop>0 loop
       v_loop_begin := v_loop*v_loop_inc;
       v_loop_end := (v_loop-1)*v_loop_inc;

       insert into REPORT_PHEALTH_HY_AGE(REPORT_DATE,ORG_ID,SPEC_ID,AGE_GROUP_ID,AGE_GROUP_NAME,PERSON_COUNT,SPEC_COUNT,CHECK_COUNT,TO_PAR_COUNT,UPDATE_TIME,CREATE_DATE)
       select v_report_date, p_org_id, v_spec_id,v_loop*v_loop_inc, v_loop_end||'-'||v_loop_begin||'岁',
         -- 患病总人数
         (
           select count(0) from phealth_hypertensionc_person r
           inner join ehr_person ep on ( (r.person_id = ep.id) and (ep.status = 0)
           and (ep.pt_org_id = p_org_id) )
           where ( sysdate-ep.birthday < v_loop_begin*365) and (sysdate-birthday >= v_loop_end*365)
--               (select count(0) from ehr_issue where to_char(create_date,'yyyymmdd')= v_report_date and icd10 = v_icd10
--                and person_id in (select id from ehr_person where pt_org_id = p_org_id and sysdate-birthday < v_loop_begin*365 and sysdate-birthday >= v_loop_end*365)),
         ),
         -- 已管理人数
         (select count(0) from phealth_spec_case where spec_id = v_spec_id
                and person_id in (select id from ehr_person where pt_org_id = p_org_id and sysdate-birthday < v_loop_begin*365 and sysdate-birthday >= v_loop_end*365 and status = 0 )),
         -- 规范管理人数
         (select count(0) from
            (
            select
            (select count(0) from phealth_soap_service where patient_id = pids.id and bus_type=4 and ( status = '0')) cardNum,
            (select count(0) from phealth_soap_service where patient_id = pids.id and bus_type=7 and ( status = '0')) evaluteNum,
            (select count(0) from phealth_soap_service where patient_id = pids.id and bus_type=2 and ( status = '0')) visitNum
            from
            (select id from ehr_person where pt_org_id = p_org_id and sysdate-birthday < v_loop_begin*365 and sysdate-birthday >= v_loop_end*365 and status = 0) pids
            ) tt
         where tt.cardNum>0 and tt.evaluteNum>0 and tt.visitNum>0),
         --血压达标人数
         (
             select count(kpi.id) from ehr_health_kpi kpi
             inner join ehr_person p on kpi.person_id = p.id and p.pt_org_id = p_org_id
                        and sysdate-p.birthday < v_loop_begin*365 and sysdate-p.birthday >= v_loop_end*365
                        and p.status = 0
             inner join phealth_spec_case spec on kpi.person_id = spec.person_id and spec.spec_id = v_spec_id
             where checkPressureToPar(p.birthday, kpi.leftdiastolicpressure, kpi.leftsystolicpressure)=1
         ),
          sysdate, v_create_date
       from dual;

       v_loop:= v_loop-1;
    end loop;
   errorcode := 0;
   errormsg := 'ok';

   commit;
   exception when others then
   begin
        errorcode := -1;
        errormsg := SQLCODE||':'||SUBSTR(SQLERRM, 1, 200);
        rollback;
   end;
end SP_REPORT_PHEALTH_HY_AGE;

/

