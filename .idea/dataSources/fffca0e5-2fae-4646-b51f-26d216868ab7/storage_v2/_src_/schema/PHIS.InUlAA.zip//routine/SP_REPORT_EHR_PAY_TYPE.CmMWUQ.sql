create procedure SP_REPORT_EHR_PAY_TYPE
  /********************************************************************/
   /*                                                                  */
   /*      REPORT健康档案_社区付费类型                                 */
   /*                                                                  */
   /********************************************************************/

as
V_REPORT_DATE  VARCHAR(8);
begin
   V_REPORT_DATE :=to_char(sysdate - 1,'yyyymmdd');
   begin
     savepoint point; ---记录保存点---

     delete from REPORT_EHR_PAY_TYPE where report_date=V_REPORT_DATE;

     --insert
     insert into report_ehr_pay_type(report_date,org_id,pay_id,pay_name,amount,update_time,create_date,district_id)
      select V_REPORT_DATE,t2.PT_ORG_ID , t2.pay_type_id,t3.cv_value_meanings as pay_name,t2.sums,sysdate,sysdate,t2.committee from
      (
      select t.pay_type_id,t.PT_ORG_ID ,t.committee,count(t.pay_type_id)sums
        from (select t1.PT_ORG_ID ,t1.committee,
             case when nvl(t1.pay_type_id,'8')='8' then '8' else t1.pay_type_id end as pay_type_id
              from ehr_person t1 where ( t1.status = '0') and t1.PT_ORG_ID  is not null and t1.committee is not null
        ) t
      group by t.pay_type_id,t.PT_ORG_ID ,t.committee
      )t2 left join std_cvdict_detail t3 on t3.cv_code='CV5600.04' and t3.cv_value=t2.pay_type_id
      ;

      --commit;
       commit;

        --3.异常处理

        exception   when   others   then
          begin
            rollback to savepoint point;
            rollback;
          end;

    end;
end SP_REPORT_EHR_PAY_TYPE;

/

