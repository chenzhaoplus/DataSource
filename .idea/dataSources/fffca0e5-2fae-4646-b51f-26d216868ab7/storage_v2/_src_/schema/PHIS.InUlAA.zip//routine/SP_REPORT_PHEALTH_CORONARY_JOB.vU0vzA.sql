create procedure SP_REPORT_PHEALTH_CORONARY_JOB(
     errorcode out int,				--返回错误代码
     errormsg out varchar2,	--返回错误参数
     p_org_id number    --机构代码
) is
/**
* REPORT公共卫生_冠心病管理统计---按职业
* 统计项 患病总人数   已管理人数   规范管理人数  血压达标人数
* bus_type 4 管理卡  7 管理评估  2 随访
*/
  v_report_date  VARCHAR(8):= to_char(sysdate,'yyyymmdd'); --报表日期
  v_icd10 varchar(100) := 'I10.X02';     --诊断对应ICD10编码
  v_spec_id number := 10005;
  v_job_id varchar(100) := 'GB/T16565-1999';--职业对应国标代码
  v_num number;
  v_create_date date := sysdate;--创建时间
begin
   select count(0) into v_num  from REPORT_PHEALTH_CORONARY_JOB where REPORT_DATE = v_report_date and ORG_ID = p_org_id and SPEC_ID = v_spec_id;
   if v_num>0 then
      select create_date into v_create_date from REPORT_PHEALTH_CORONARY_JOB where REPORT_DATE = v_report_date and ORG_ID = p_org_id and SPEC_ID = v_spec_id and rownum=1;
   end if;

   delete from REPORT_PHEALTH_CORONARY_JOB where REPORT_DATE = v_report_date and ORG_ID = p_org_id and SPEC_ID = v_spec_id;

   insert into REPORT_PHEALTH_CORONARY_JOB(REPORT_DATE,ORG_ID,SPEC_ID,JOB_ID,JOB_NAME,PERSON_COUNT,SPEC_COUNT,CHECK_COUNT,TO_PAR_COUNT,UPDATE_TIME,CREATE_DATE)
   select v_report_date, p_org_id, v_spec_id,a.occupation, (select DICT_NAME from std_gbdict_detail where gb_code=v_job_id and detail_code=a.occupation),
     -- 患病总人数
     (select count(0) from ehr_issue where icd10 = v_icd10
            and person_id in (select id from ehr_person where pt_org_id = p_org_id and occupation = a.occupation)),
     -- 已管理人数
     (select count(0) from phealth_spec_case where spec_id = v_spec_id
            and person_id in (select id from ehr_person where pt_org_id = p_org_id and occupation = a.occupation)),
     -- 规范管理人数
     (select count(count(0)) from phealth_soap_service s inner join ehr_person p on s.patient_id = p.id
       where  p.pt_org_id = p_org_id  and p.occupation=a.occupation
       group by s.patient_id
       having sum(case when bus_type=4 then 1 else 0 end)>0 and
       sum(case when bus_type=7 then 1 else 0 end)>0 and sum(case when bus_type=2 then 1 else 0 end)>0
      ),
     --血压达标人数
     (select count(kpi.id) from ehr_health_kpi kpi inner join ehr_person p on kpi.person_id = p.id and p.pt_org_id = p_org_id
             inner join phealth_spec_case spec on kpi.person_id = spec.person_id and spec.spec_id = v_spec_id
             where p.occupation = a.occupation and checkPressureToPar(p.birthday, kpi.leftdiastolicpressure, kpi.leftsystolicpressure)=1),
      sysdate, v_create_date
   from ehr_person a
   where a.pt_org_id = p_org_id
   group by a.occupation;
   errorcode := 0;
   errormsg := 'ok';

   exception when others then
   begin
        errorcode := -1;
        errormsg := SQLCODE||':'||SUBSTR(SQLERRM, 1, 200);
        rollback;
   end;
end SP_REPORT_PHEALTH_CORONARY_JOB;

/

