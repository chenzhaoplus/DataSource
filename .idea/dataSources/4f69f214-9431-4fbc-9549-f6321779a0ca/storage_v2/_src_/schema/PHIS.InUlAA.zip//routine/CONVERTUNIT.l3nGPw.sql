create function convertUnit( orgId in number, drugCode in varchar2, oldUnit in number, newUnit in number) return number is
  Result number;
begin
  -- orgId 机构ID
  -- drugCode 药品代码
  -- oldUnit 旧单位代码
  -- newUnit 新单位代码
  -- return  旧单位与新单位比率,值为 旧单位/新单位
  return 1;
end convertUnit;
/

