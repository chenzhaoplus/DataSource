create view MD_BASE_FEE_ITEMS as
  select
  mbd.org_id orgId, 1 itemType, mbd.m_code itemCode, mbd.m_name itemName, mbd.zjcpy pybm, mbd.zjcwb wbbm, mbd.zjcqt qtbm, (case mbd.m_type when '1' then '01' when '2' then '03' when '3' then '02' end) flag, mbd.m_std spec, mbd.unit, mbd.unit_name unitName, mbds.retail_price price, mbds.factory_code factoryCode, mbds.factory_name factoryName, mbds.store_amount stock,
  mbds.store_unit_code kcUnit, mbds.store_unit_name kcUnitName, (case when kcu.scale is null then 1 else kcu.scale end) kcScale,
  mbd.mz_unit mzUnit, mbd.mz_unit_name mzUnitName, (case when mzu.scale is null then 1 else mzu.scale end) mzScale,
  mbd.zy_unit zyUnit, mbd.zy_unit_name zyUnitName, (case when zyu.scale is null then 1 else zyu.scale end) zyScale,
  to_char(mbd.mz_nouse) mzNonuse, to_char(mbd.zy_nouse) zyNonuse, mbds.room_code, mbds.DRUG_DOSE drugDose
from md_base_drug_storage mbds
left join md_base_drug mbd on mbd.org_id = mbds.org_id and mbd.m_code = mbds.drug_code
left join md_base_drug_unit kcu on kcu.org_id = mbd.org_id and kcu.m_code = mbds.drug_code and kcu.unit_code = mbds.store_unit_code
left join md_base_drug_unit mzu on mzu.org_id = mbd.org_id and mzu.m_code = mbd.m_code and mzu.unit_code = mbd.mz_unit
left join md_base_drug_unit zyu on zyu.org_id = mbd.org_id and zyu.m_code = mbd.m_code and zyu.unit_code = mbd.zy_unit

union all

select
  org_id orgId, 2 itemType, system_code itemCode, system_name itemName, zjc_py pybm, zjc_wb wbbm, zjc_qt qtbm, flag, standard spec, null unit, unit unitName, price, null factoryCode, null factoryName, null stock,
  null kcUnit, unit kcUnitName, 1 kcScale,
  null mzUnit, unit mzUnitName, 1 mzScale,
  null zyUnit, unit zyUnitName, 1 zyScale,
  mz_nouse mzNonuse, zy_nouse zyNonuse,null room_code,null drugDose
from md_base_treat_item
where org_id != 0

union all

select t0.org_id, 4 itemType, t0.item_code itemCode, t0.item_name itemName, zjc_py pybm, zjc_wb wbbm, zjc_qt qtbm, flag, null spec, null unit, null unitName, t3.price, null factoryCode, null factoryName, null stock,
  null kcUnit, null kcUnitName, 1 kcScale,
  null mzUnit, null mzUnitName, 1 mzScale,
  null zyUnit, null zyUnitName, 1 zyScale,
  to_char(t0.mz_nouse) mzNonuse, to_char(t0.zy_nouse) zyNonuse,null room_code,null drugDose
from md_base_treat_advice t0
left join (
     select t1.org_id, t1.main_id, sum(t1.sl * t2.price) price from md_base_treat_advice_detail t1
     inner join md_base_treat_item t2 on t2.org_id = t1.org_id and t2.system_code = t1.system_code
     group by t1.org_id, t1.main_id
) t3 on t3.org_id = t0.org_id and t3.main_id = t0.record_id
/*
union all

select
  mbs.org_id orgId, mbs.normal_code itemCode, mbs.item_name itemName, mbs.zjc_py pybm, mbs.zjc_wb wbbm, mbs.zjc_qt qtbm, '11' flag, mbs.standard spec, mbss.unit_code unit, mbs.unit_name unitName, mbss.price, mbss.factory_name factory, null provider, mbss.kcsl stock,
  mbs.mz_unit mzUnit, mbs.mz_unit_name mzUnitName, (case when mzu.scale is null then 1 else mzu.scale end) mzScale,
  mbs.zy_unit zyUnit, zyu.unit zy_unit_name, (case when zyu.scale is null then 1 else zyu.scale end) zyScale,
  to_char(mbss.mz_noused) mzNonuse, to_char(mbss.zy_noused) zyNonuse
from md_base_stuff_item mbs
left join md_base_stuff_storage mbss on mbs.org_id = mbss.org_id and to_char(mbs.normal_code) = to_char(mbss.normal_code)
left join md_base_stuff_unit bsu on bsu.org_id = mbs.org_id and bsu.normal_code = mbs.normal_code and bsu.unit_code = mbs.unit
left join md_base_stuff_unit mzu on mzu.org_id = mbs.org_id and mzu.normal_code = mbs.normal_code and mzu.unit_code = mbs.mz_unit
left join md_base_stuff_unit zyu on zyu.org_id = mbs.org_id and zyu.normal_code = mbs.normal_code and mzu.unit_code = mbs.zy_unit
where mbs.org_id != 0*/

