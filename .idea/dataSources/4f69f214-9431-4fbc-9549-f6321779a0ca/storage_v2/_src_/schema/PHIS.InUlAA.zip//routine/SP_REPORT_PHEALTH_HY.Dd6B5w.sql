create procedure SP_REPORT_PHEALTH_HY(
     errorcode out int,				--返回错误代码
     errormsg out varchar2,	--返回错误参数
     p_org_id number    --机构代码
) is
/**
* REPORT公共卫生_高血压管理考核指标
* 统计项 患病总人数   已管理人数   规范管理人数  血压达标人数
* bus_type 4 管理卡  7 管理评估  2 随访
*/
  v_report_date  VARCHAR(8):= to_char(sysdate,'yyyymmdd'); --报表日期
  v_icd10 varchar(100) := 'I10.X02';     --诊断对应ICD10编码
  v_spec_id number := 10005;
  v_num number;  --已存在统计数据总数
  v_person_count number; --患病总人数
  v_spec_count number; --已管理人数
  v_check_count number; --规范管理人数
  v_to_par_count number; --血压达标人数
begin
   select count(0) into v_num from REPORT_PHEALTH_HYPERTENSIONC where REPORT_DATE = v_report_date and ORG_ID = p_org_id and SPEC_ID = v_spec_id;
   -- 患病总人数
   select count(0) into v_person_count
   from phealth_hypertensionc_person r
   inner join ehr_person ep on ( (r.person_id = ep.id) and (ep.status = 0) and (ep.pt_org_id = p_org_id) );
--   select count(0) into v_person_count from ehr_issue where icd10 = v_icd10
--          and person_id in (select id from ehr_person where pt_org_id = p_org_id);
   -- 已管理人数
   select count(0) into v_spec_count from phealth_spec_case where spec_id = v_spec_id
          and person_id in (select id from ehr_person where pt_org_id = p_org_id and status = 0);
   -- 规范管理人数
   select count(0) into v_check_count from
      (
      select
      (select count(0) from phealth_soap_service where patient_id = pids.patient_id and bus_type=4 and ( status = '0')) cardNum,
      (select count(0) from phealth_soap_service where patient_id = pids.patient_id and bus_type=7 and ( status = '0')) evaluteNum,
      (select count(0) from phealth_soap_service where patient_id = pids.patient_id and bus_type=2 and ( status = '0')) visitNum
      from
      (select  distinct patient_id from phealth_soap_service
      where patient_id in (select id from ehr_person where pt_org_id = p_org_id and status = 0)
       and ( status = '0')
      ) pids
      ) tt
   where tt.cardNum>0 and tt.evaluteNum>0 and tt.visitNum>0;
   --血压达标人数
   select count(a.id) into v_to_par_count from ehr_health_kpi a inner join ehr_person b on a.person_id = b.id and b.pt_org_id = p_org_id
   inner join phealth_spec_case c on a.person_id = c.person_id and c.spec_id = v_spec_id
   where checkPressureToPar(b.birthday, a.leftdiastolicpressure, a.leftsystolicpressure)=1 and b.status = 0;

   if v_num>0 then
      update REPORT_PHEALTH_HYPERTENSIONC
      set PERSON_COUNT = v_person_count,
          SPEC_COUNT = v_spec_count,
          CHECK_COUNT = v_check_count,
          TO_PAR_COUNT = v_to_par_count,
          UPDATE_TIME = sysdate
      where REPORT_DATE = v_report_date and ORG_ID = p_org_id and SPEC_ID = v_spec_id;
   else
       insert into REPORT_PHEALTH_HYPERTENSIONC(REPORT_DATE, ORG_ID, SPEC_ID, PERSON_COUNT, SPEC_COUNT, CHECK_COUNT, TO_PAR_COUNT, UPDATE_TIME, CREATE_DATE)
       values(v_report_date, p_org_id, v_spec_id, v_person_count, v_spec_count, v_check_count, v_to_par_count, sysdate, sysdate);
   end if;
   errorcode := 0;
   errormsg := 'ok';

   commit;
   exception when others then
   begin
        errorcode := -1;
        errormsg := SQLCODE||':'||SUBSTR(SQLERRM, 1, 200);
        rollback;
   end;
end SP_REPORT_PHEALTH_HY;

/

