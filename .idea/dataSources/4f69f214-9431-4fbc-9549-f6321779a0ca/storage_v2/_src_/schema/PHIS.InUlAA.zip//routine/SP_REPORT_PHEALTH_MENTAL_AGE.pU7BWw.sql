create procedure SP_REPORT_PHEALTH_MENTAL_AGE(
     errorcode out int,				--返回错误代码
     errormsg out varchar2,	--返回错误参数
     p_org_id number    --机构代码
) is
/**
* REPORT公共卫生_精神病管理统计---按年龄段
* 统计项 患病总人数   已管理人数   规范管理人数  按时服药人数  复发人数
* bus_type 24 管理卡  19 管理评估  17 随访
*/
  v_report_date  VARCHAR(8):= to_char(sysdate,'yyyymmdd'); --报表日期
  v_icd10 varchar(100) := 'I10.X02';     --诊断对应ICD10编码
  v_spec_id number := 10011;
  v_num number;
  v_create_date date := sysdate;--创建时间
  v_loop number := 15;
  v_loop_inc number := 5;
  v_loop_begin number:=0;
  v_loop_end number:=0;
  v_code_drug varchar2(50) := '10000392';--按时服药数据元代码
--  v_code_drug_value varchar(200) := '5146001, 5146002, 1';--按时服药相应数据元值（不同页面不同值都可理解为按时服药，所以有3个值）
  v_code_drug_value_1 varchar(10) :='1';--按时服药相应数据元值（不同页面不同值都可理解为按时服药，所以有3个值）
  v_code_drug_value_2 varchar(10) :='5146001';--按时服药相应数据元值（不同页面不同值都可理解为按时服药，所以有3个值）
  v_code_drug_value_3 varchar(10) :='5146002';--按时服药相应数据元值（不同页面不同值都可理解为按时服药，所以有3个值）
  v_start_time_code varchar(20) := '10000257'; --初次发病时间对应数据元值
begin
    select count(0) into v_num  from REPORT_PHEALTH_MENTAL_AGE where REPORT_DATE = v_report_date and ORG_ID = p_org_id and SPEC_ID = v_spec_id;
    if v_num>0 then
      select create_date into v_create_date from REPORT_PHEALTH_MENTAL_AGE where REPORT_DATE = v_report_date and ORG_ID = p_org_id and SPEC_ID = v_spec_id and rownum=1;
    end if;

    delete from REPORT_PHEALTH_MENTAL_AGE where REPORT_DATE = v_report_date and ORG_ID = p_org_id and SPEC_ID = v_spec_id;
    --75岁以上
    insert into REPORT_PHEALTH_MENTAL_AGE(REPORT_DATE,ORG_ID,SPEC_ID,AGE_GROUP_ID,AGE_GROUP_NAME,PERSON_COUNT,SPEC_COUNT,CHECK_COUNT,DURG_COUNT,RELAPSE_COUNT,UPDATE_TIME,CREATE_DATE)
    select v_report_date, p_org_id, v_spec_id,100, '75岁以上',
    -- 患病总人数
    (
        select count(0) from phealth_mental_illness_roster r
        inner join ehr_person ep on ( (r.patient_id = ep.id) and (ep.status = 0)
        and (ep.pt_org_id = p_org_id) )
        where ( sysdate-ep.birthday >= v_loop*v_loop_inc*365)
        --select count(0) from ehr_issue where to_char(create_date,'yyyymmdd')= v_report_date and icd10 = v_icd10
        --       and person_id in (select id from ehr_person where pt_org_id = p_org_id and sysdate-birthday >= v_loop*v_loop_inc*365)
    ),
    -- 已管理人数
    (select count(0) from phealth_spec_case where spec_id = v_spec_id
        and person_id in (select id from ehr_person where pt_org_id = p_org_id and sysdate-birthday >= v_loop*v_loop_inc*365 and (status = 0) )),
    -- 规范管理人数
    (select count(0) from
        (
        select
        (select count(0) from phealth_soap_service where patient_id = pids.id and bus_type=24 and ( status = '0')) cardNum,
        (select count(0) from phealth_soap_service where patient_id = pids.id and bus_type=19 and ( status = '0')) evaluteNum,
        (select count(0) from phealth_soap_service where patient_id = pids.id and bus_type=17 and ( status = '0')) visitNum
        from
        (select id from ehr_person where pt_org_id = p_org_id and sysdate-birthday >=  v_loop*v_loop_inc*365 and (status = 0) ) pids
        ) tt
        where tt.cardNum>0 and tt.evaluteNum>0 and tt.visitNum>0
    ),
    --按时服药人数
    (
        select count( distinct s2.patient_id )
        from PHEALTH_SOAP_SERVICE_metadata s2,
        (
           select s.patient_id, max(s.measure_date) as measure_date
           from PHEALTH_SOAP_SERVICE_metadata s
           inner join ehr_person e on s.Patient_Id = e.id
           inner join phealth_mental_illness_roster r on (r.patient_id = e.id)
           where e.pt_org_id = p_org_id
           and sysdate-e.birthday >= v_loop*v_loop_inc*365
           and (e.status = 0)  and ( s.status = '0')
           group by s.patient_id
        ) s3
        where ( s2.metadata_code = v_code_drug )
        and ( s2.metadata_value in ( v_code_drug_value_1, v_code_drug_value_2, v_code_drug_value_3  ) )
        and ( s2.patient_id = s3.patient_id ) and ( s2.measure_date = s3.measure_date )
         and ( s2.status = '0')
    ),
    --复发人数
    (
        select count( distinct s2.patient_id )
        from PHEALTH_SOAP_SERVICE_metadata s2,
        (
           select s.patient_id, max(s.measure_date) as measure_date
           from PHEALTH_SOAP_SERVICE_metadata s
           inner join ehr_person e on s.Patient_Id = e.id
           inner join phealth_mental_illness_roster r on (r.patient_id = e.id)
           where e.pt_org_id = p_org_id and ( s.status = '0')
           and sysdate-e.birthday >= v_loop*v_loop_inc*365
           and (e.status = 0)
           group by s.patient_id
        ) s3
        where ( s2.metadata_code = v_start_time_code ) --初次发病时间有数据，不为null，即是复发
        and ( s2.patient_id = s3.patient_id ) and ( s2.measure_date = s3.measure_date )
        and ( s2.status = '0')
    ),
    sysdate, v_create_date
    from dual;
    --0至75岁
    while v_loop>0 loop
        v_loop_begin := v_loop*v_loop_inc;
        v_loop_end := (v_loop-1)*v_loop_inc;

        insert into REPORT_PHEALTH_MENTAL_AGE(REPORT_DATE,ORG_ID,SPEC_ID,AGE_GROUP_ID,AGE_GROUP_NAME,PERSON_COUNT,SPEC_COUNT,CHECK_COUNT,DURG_COUNT,RELAPSE_COUNT,UPDATE_TIME,CREATE_DATE)
        select v_report_date, p_org_id, v_spec_id,v_loop*v_loop_inc, v_loop_end||'-'||v_loop_begin||'岁',
        -- 患病总人数
        (
        select count(0) from phealth_mental_illness_roster r
        inner join ehr_person ep on ( (r.patient_id = ep.id) and (ep.status = 0)
        and (ep.pt_org_id = p_org_id) )
        where ( sysdate-ep.birthday < v_loop_begin*365) and (sysdate-birthday >= v_loop_end*365)

        --select count(0) from ehr_issue where to_char(create_date,'yyyymmdd')= v_report_date and icd10 = v_icd10
        --       and person_id in (select id from ehr_person where pt_org_id = p_org_id and sysdate-birthday < v_loop_begin*365 and sysdate-birthday >= v_loop_end*365)
        ),
        -- 已管理人数
        (
           select count(0) from phealth_spec_case where spec_id = v_spec_id
           and person_id in (select id from ehr_person where pt_org_id = p_org_id and sysdate-birthday < v_loop_begin*365 and sysdate-birthday >= v_loop_end*365 and (status = 0) )
        ),
        -- 规范管理人数
        (select count(0) from
            (
                select
                (select count(0) from phealth_soap_service where patient_id = pids.id and bus_type=24 and ( status = '0')) cardNum,
                (select count(0) from phealth_soap_service where patient_id = pids.id and bus_type=19 and ( status = '0')) evaluteNum,
                (select count(0) from phealth_soap_service where patient_id = pids.id and bus_type=17 and ( status = '0')) visitNum
                from
                (select id from ehr_person where pt_org_id = p_org_id and sysdate-birthday < v_loop_begin*365 and sysdate-birthday >= v_loop_end*365 and (status = 0) ) pids
            ) tt
            where tt.cardNum>0 and tt.evaluteNum>0 and tt.visitNum>0
        ),
        --按时服药人数
        (
            select count( distinct s2.patient_id )
            from PHEALTH_SOAP_SERVICE_metadata s2,
            (
               select s.patient_id, max(s.measure_date) as measure_date
               from PHEALTH_SOAP_SERVICE_metadata s
               inner join ehr_person e on s.Patient_Id = e.id
               inner join phealth_mental_illness_roster r on (r.patient_id = e.id)
               where e.pt_org_id = p_org_id
               and sysdate-e.birthday < v_loop_begin*365 and sysdate-e.birthday >= v_loop_end*365
               and (e.status = 0)  and ( s.status = '0')
               group by s.patient_id
            ) s3
            where ( s2.metadata_code = v_code_drug )
            and ( s2.metadata_value in ( v_code_drug_value_1, v_code_drug_value_2, v_code_drug_value_3  ) )
            and ( s2.patient_id = s3.patient_id ) and ( s2.measure_date = s3.measure_date )
            and ( s2.status = '0')
        ),
        --复发人数
        (
            select count( distinct s2.patient_id )
            from PHEALTH_SOAP_SERVICE_metadata s2,
            (
               select s.patient_id, max(s.measure_date) as measure_date
               from PHEALTH_SOAP_SERVICE_metadata s
               inner join ehr_person e on s.Patient_Id = e.id
               inner join phealth_mental_illness_roster r on (r.patient_id = e.id)
               where e.pt_org_id = p_org_id
               and sysdate-e.birthday < v_loop_begin*365 and sysdate-e.birthday >= v_loop_end*365
               and (e.status = 0)  and ( s.status = '0')
               group by s.patient_id
            ) s3
            where ( s2.metadata_code = v_start_time_code ) --初次发病时间有数据，不为null，即是复发
            and ( s2.patient_id = s3.patient_id ) and ( s2.measure_date = s3.measure_date )
            and ( s2.status = '0')
        ),
        sysdate, v_create_date
        from dual;

        v_loop:= v_loop-1;
    end loop;
    errorcode := 0;
    errormsg := 'ok';

   commit;
   exception when others then
   begin
        errorcode := -1;
        errormsg := SQLCODE||':'||SUBSTR(SQLERRM, 1, 200);
        rollback;
   end;
end SP_REPORT_PHEALTH_MENTAL_AGE;

/

