create procedure SP_REPORT_EHR_CHILD
/**
*健康档案_社区儿童构成统计表
*/
as
 V_REPORT_DATE  VARCHAR(8);
begin
   V_REPORT_DATE :=to_char(sysdate - 1,'yyyymmdd');
   begin
     savepoint point; ---记录保存点---
     delete from report_ehr_child where report_date=V_REPORT_DATE;
     --insert
     insert into report_ehr_child(report_date,org_id,age_group_id,age_group_name,hj_man,hj_woman,fhj_man,fhj_woman,qt_man
     ,qt_woman,update_time,create_date,district_id)

          SELECT V_REPORT_DATE, F.PT_ORG_ID ,F.age_type as age_group_id,F.age_name as age_group_name
                      ,SUM(F.HJ_MAN) as HJ_MAN,SUM(HJ_WOMAN) as HJ_WOMAN,SUM(FHJ_MAN) as FHJ_MAN,
                       SUM(F.FHJ_WOMAN) as FHJ_WOMAN,SUM(OTHER_MAN) as qt_man,SUM(OTHER_WOMAN) as qt_woman,
                      sysdate,sysdate,F.DISTRICT_ID
          FROM (
                  -- 年龄段 "0-"
                  select PT_ORG_ID ,'509000207' as age_type,'0岁组' as age_name,COMMITTEE as DISTRICT_ID,
                         sum(case when jztype = '1' and sex = '1' then 1 else 0 end) as HJ_MAN,
                         sum(case when jztype = '1' and sex = '2' then 1 else 0 end) as HJ_WOMAN,
                         sum(case when jztype = '2' and sex = '1' then 1 else 0 end) as FHJ_MAN,
                         sum(case when jztype = '2' and sex = '2' then 1 else 0 end) as FHJ_WOMAN,
                         sum((case when nvl(jztype,'-1') not in('1','2') and sex = '1'  then 1 else 0 end)) as OTHER_MAN,
                         sum((case when nvl(jztype,'-1') not in('1','2') and sex = '2'  then 1 else 0 end)) as OTHER_WOMAN
                  from   ehr_person
                  where ( status = '0') and (sysdate - birthday)>=0*365
                  and    (sysdate - birthday)<1*365
                   and COMMITTEE is not null
                  group by PT_ORG_ID ,COMMITTEE

                  union all

                  -- 年龄段 "1-"
                  select PT_ORG_ID ,'509000208' as age_type,'1岁组' as age_name,COMMITTEE as DISTRICT_ID,
                         sum(case when jztype = '1' and sex = '1' then 1 else 0 end) as HJ_MAN,
                         sum(case when jztype = '1' and sex = '2' then 1 else 0 end) as HJ_WOMAN,
                         sum(case when jztype = '2' and sex = '1' then 1 else 0 end) as FHJ_MAN,
                         sum(case when jztype = '2' and sex = '2' then 1 else 0 end) as FHJ_WOMAN,
                         sum((case when nvl(jztype,'-1') not in('1','2') and sex = '1'  then 1 else 0 end)) as OTHER_MAN,
                         sum((case when nvl(jztype,'-1') not in('1','2') and sex = '2'  then 1 else 0 end)) as OTHER_WOMAN
                   from   ehr_person
                  where ( status = '0') and (sysdate - birthday)>=1*365
                  and    (sysdate - birthday)<2*365
                   and COMMITTEE is not null
                  group by PT_ORG_ID ,COMMITTEE

                  union all

                  -- 年龄段 "2-"
                  select PT_ORG_ID ,'509000209' as age_type,'2岁组' as age_name,COMMITTEE as DISTRICT_ID,
                         sum(case when jztype = '1' and sex = '1' then 1 else 0 end) as HJ_MAN,
                         sum(case when jztype = '1' and sex = '2' then 1 else 0 end) as HJ_WOMAN,
                         sum(case when jztype = '2' and sex = '1' then 1 else 0 end) as FHJ_MAN,
                         sum(case when jztype = '2' and sex = '2' then 1 else 0 end) as FHJ_WOMAN,
                         sum((case when nvl(jztype,'-1') not in('1','2') and sex = '1'  then 1 else 0 end)) as OTHER_MAN,
                         sum((case when nvl(jztype,'-1') not in('1','2') and sex = '2'  then 1 else 0 end)) as OTHER_WOMAN
                  from   ehr_person
                  where ( status = '0') and (sysdate - birthday)>=2*365
                  and    (sysdate - birthday)<3*365
                   and COMMITTEE is not null
                  group by PT_ORG_ID ,COMMITTEE

                  union all

                  -- 年龄段 "3-"
                  select PT_ORG_ID ,'509000210' as age_type,'3岁组' as age_name,COMMITTEE as DISTRICT_ID,
                         sum(case when jztype = '1' and sex = '1' then 1 else 0 end) as HJ_MAN,
                         sum(case when jztype = '1' and sex = '2' then 1 else 0 end) as HJ_WOMAN,
                         sum(case when jztype = '2' and sex = '1' then 1 else 0 end) as FHJ_MAN,
                         sum(case when jztype = '2' and sex = '2' then 1 else 0 end) as FHJ_WOMAN,
                         sum((case when nvl(jztype,'-1') not in('1','2') and sex = '1'  then 1 else 0 end)) as OTHER_MAN,
                         sum((case when nvl(jztype,'-1') not in('1','2') and sex = '2'  then 1 else 0 end)) as OTHER_WOMAN
                  from   ehr_person
                  where ( status = '0') and (sysdate - birthday)>=3*365
                  and    (sysdate - birthday)<4*365
                   and COMMITTEE is not null
                  group by PT_ORG_ID ,COMMITTEE

                  union all

                  -- 年龄段 "4-"
                  select PT_ORG_ID ,'509000211' as age_type,'4岁组' as age_name,COMMITTEE as DISTRICT_ID,
                         sum(case when jztype = '1' and sex = '1' then 1 else 0 end) as HJ_MAN,
                         sum(case when jztype = '1' and sex = '2' then 1 else 0 end) as HJ_WOMAN,
                         sum(case when jztype = '2' and sex = '1' then 1 else 0 end) as FHJ_MAN,
                         sum(case when jztype = '2' and sex = '2' then 1 else 0 end) as FHJ_WOMAN,
                         sum((case when nvl(jztype,'-1') not in('1','2') and sex = '1'  then 1 else 0 end)) as OTHER_MAN,
                         sum((case when nvl(jztype,'-1') not in('1','2') and sex = '2'  then 1 else 0 end)) as OTHER_WOMAN
                  from   ehr_person
                  where ( status = '0') and (sysdate - birthday)>=4*365
                  and    (sysdate - birthday)<5*365
                   and COMMITTEE is not null
                  group by PT_ORG_ID ,COMMITTEE

                  union all

                  -- 年龄段 "5-"
                  select PT_ORG_ID ,'509000212' as age_type,'5岁组' as age_name,COMMITTEE as DISTRICT_ID,
                         sum(case when jztype = '1' and sex = '1' then 1 else 0 end) as HJ_MAN,
                         sum(case when jztype = '1' and sex = '2' then 1 else 0 end) as HJ_WOMAN,
                         sum(case when jztype = '2' and sex = '1' then 1 else 0 end) as FHJ_MAN,
                         sum(case when jztype = '2' and sex = '2' then 1 else 0 end) as FHJ_WOMAN,
                         sum((case when nvl(jztype,'-1') not in('1','2') and sex = '1'  then 1 else 0 end)) as OTHER_MAN,
                         sum((case when nvl(jztype,'-1') not in('1','2') and sex = '2'  then 1 else 0 end)) as OTHER_WOMAN
                  from   ehr_person
                  where ( status = '0') and (sysdate - birthday)>=5*365
                  and    (sysdate - birthday)<6*365
                   and COMMITTEE is not null
                  group by PT_ORG_ID ,COMMITTEE

                  union all

                  -- 年龄段 "6-"
                  select PT_ORG_ID ,'509000213' as age_type,'6岁组' as age_name,COMMITTEE as DISTRICT_ID,
                         sum(case when jztype = '1' and sex = '1' then 1 else 0 end) as HJ_MAN,
                         sum(case when jztype = '1' and sex = '2' then 1 else 0 end) as HJ_WOMAN,
                         sum(case when jztype = '2' and sex = '1' then 1 else 0 end) as FHJ_MAN,
                         sum(case when jztype = '2' and sex = '2' then 1 else 0 end) as FHJ_WOMAN,
                         sum((case when nvl(jztype,'-1') not in('1','2') and sex = '1'  then 1 else 0 end)) as OTHER_MAN,
                         sum((case when nvl(jztype,'-1') not in('1','2') and sex = '2'  then 1 else 0 end)) as OTHER_WOMAN
                  from   ehr_person
                  where ( status = '0') and (sysdate - birthday)>=6*365
                  and    (sysdate - birthday)<7*365
                   and COMMITTEE is not null
                  group by PT_ORG_ID ,COMMITTEE

                  union all

                  -- 年龄段 "7-"
                  select PT_ORG_ID ,'509000214' as age_type,'7-14岁组' as age_name,COMMITTEE as DISTRICT_ID,
                         sum(case when jztype = '1' and sex = '1' then 1 else 0 end) as HJ_MAN,
                         sum(case when jztype = '1' and sex = '2' then 1 else 0 end) as HJ_WOMAN,
                         sum(case when jztype = '2' and sex = '1' then 1 else 0 end) as FHJ_MAN,
                         sum(case when jztype = '2' and sex = '2' then 1 else 0 end) as FHJ_WOMAN,
                         sum((case when nvl(jztype,'-1') not in('1','2') and sex = '1'  then 1 else 0 end)) as OTHER_MAN,
                         sum((case when nvl(jztype,'-1') not in('1','2') and sex = '2'  then 1 else 0 end)) as OTHER_WOMAN
                  from   ehr_person
                  where ( status = '0') and (sysdate - birthday)>=7*365
                  and    (sysdate - birthday)<14*365
                   and COMMITTEE is not null
                  group by PT_ORG_ID ,COMMITTEE

                  union all

                  -- 年龄段 "新生儿"
                /**  select PT_ORG_ID ,'509000215' as age_type,'新生儿' as age_name,COMMITTEE as DISTRICT_ID,
                         sum(case when jztype = '1' and sex = '1' then 1 else 0 end) as HJ_MAN,
                         sum(case when jztype = '1' and sex = '2' then 1 else 0 end) as HJ_WOMAN,
                         sum(case when jztype = '2' and sex = '1' then 1 else 0 end) as FHJ_MAN,
                         sum(case when jztype = '2' and sex = '2' then 1 else 0 end) as FHJ_WOMAN,
                         sum((case when nvl(jztype,'-1') not in('1','2') and sex = '1'  then 1 else 0 end)) as OTHER_MAN,
                         sum((case when nvl(jztype,'-1') not in('1','2') and sex = '2'  then 1 else 0 end)) as OTHER_WOMAN
                  from   ehr_person
                  where ( status = '0') and (sysdate - birthday)>=0
                  and    (sysdate - birthday)<28
                   and COMMITTEE is not null
                  group by PT_ORG_ID ,COMMITTEE

                  union all

                  -- 年龄段 "婴儿"
                  select PT_ORG_ID ,'509000216' as age_type,'婴儿' as age_name,COMMITTEE as DISTRICT_ID,
                         sum(case when jztype = '1' and sex = '1' then 1 else 0 end) as HJ_MAN,
                         sum(case when jztype = '1' and sex = '2' then 1 else 0 end) as HJ_WOMAN,
                         sum(case when jztype = '2' and sex = '1' then 1 else 0 end) as FHJ_MAN,
                         sum(case when jztype = '2' and sex = '2' then 1 else 0 end) as FHJ_WOMAN,
                         sum((case when nvl(jztype,'-1') not in('1','2') and sex = '1'  then 1 else 0 end)) as OTHER_MAN,
                         sum((case when nvl(jztype,'-1') not in('1','2') and sex = '2'  then 1 else 0 end)) as OTHER_WOMAN
                  from   ehr_person
                  where ( status = '0') and (sysdate - birthday)>=0*365
                  and    (sysdate - birthday)<1*365
                   and COMMITTEE is not null
                  group by PT_ORG_ID ,COMMITTEE

                  union all

                  -- 年龄段 "3岁以下儿童"
                  select PT_ORG_ID ,'509000217' as age_type,'3岁以下儿童' as age_name,COMMITTEE as DISTRICT_ID,
                         sum(case when jztype = '1' and sex = '1' then 1 else 0 end) as HJ_MAN,
                         sum(case when jztype = '1' and sex = '2' then 1 else 0 end) as HJ_WOMAN,
                         sum(case when jztype = '2' and sex = '1' then 1 else 0 end) as FHJ_MAN,
                         sum(case when jztype = '2' and sex = '2' then 1 else 0 end) as FHJ_WOMAN,
                         sum((case when nvl(jztype,'-1') not in('1','2') and sex = '1'  then 1 else 0 end)) as OTHER_MAN,
                         sum((case when nvl(jztype,'-1') not in('1','2') and sex = '2'  then 1 else 0 end)) as OTHER_WOMAN
                  from ehr_person
                  where ( status = '0') and (sysdate - birthday)>=0*365
                  and    (sysdate - birthday)<3*365
                   and COMMITTEE is not null
                  group by PT_ORG_ID ,COMMITTEE

                  union all

                  -- 年龄段 "5岁以下儿童"
                  select PT_ORG_ID ,'509000218' as age_type,'5岁以下儿童' as age_name,COMMITTEE as DISTRICT_ID,
                         sum(case when jztype = '1' and sex = '1' then 1 else 0 end) as HJ_MAN,
                         sum(case when jztype = '1' and sex = '2' then 1 else 0 end) as HJ_WOMAN,
                         sum(case when jztype = '2' and sex = '1' then 1 else 0 end) as FHJ_MAN,
                         sum(case when jztype = '2' and sex = '2' then 1 else 0 end) as FHJ_WOMAN,
                         sum((case when nvl(jztype,'-1') not in('1','2') and sex = '1'  then 1 else 0 end)) as OTHER_MAN,
                         sum((case when nvl(jztype,'-1') not in('1','2') and sex = '2'  then 1 else 0 end)) as OTHER_WOMAN
                  from   ehr_person
                  where ( status = '0') and (sysdate - birthday)>=0*365
                  and    (sysdate - birthday)<5*365
                    and COMMITTEE is not null
                  group by PT_ORG_ID ,COMMITTEE

                  union all**/

                  -- 年龄段 "7岁以下儿童"
                  select PT_ORG_ID ,'509000219' as age_type,'7岁以下儿童' as age_name,COMMITTEE as DISTRICT_ID,
                         sum(case when jztype = '1' and sex = '1' then 1 else 0 end) as HJ_MAN,
                         sum(case when jztype = '1' and sex = '2' then 1 else 0 end) as HJ_WOMAN,
                         sum(case when jztype = '2' and sex = '1' then 1 else 0 end) as FHJ_MAN,
                         sum(case when jztype = '2' and sex = '2' then 1 else 0 end) as FHJ_WOMAN,
                         sum((case when nvl(jztype,'-1') not in('1','2') and sex = '1'  then 1 else 0 end)) as OTHER_MAN,
                         sum((case when nvl(jztype,'-1') not in('1','2') and sex = '2'  then 1 else 0 end)) as OTHER_WOMAN
                  from   ehr_person
                  where ( status = '0') and (sysdate - birthday)>=0*365
                  and    (sysdate - birthday)<7*365
                  and COMMITTEE is not null
                  group by PT_ORG_ID ,COMMITTEE
            ) F GROUP BY F.PT_ORG_ID ,F.DISTRICT_ID,F.age_type,F.age_name;
            --commit;
            commit;
            --3.异常处理

        exception   when   others   then
          begin
            rollback to savepoint point;
            rollback;
          end;
      end;
end SP_REPORT_EHR_CHILD;

/

