create function mul(num1 in number, num2 in number, num3 in number) return number is
  Result number;
begin

  return (num1 * power(10,num3)) * (num2 * power(10,num3))/ power(10,2*num3);
end mul;
/

