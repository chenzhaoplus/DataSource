create function get_Drug_store_Price( orgId in number, drugCode in varchar2, factoryCode in varchar2, unit in number) return number is
  Result number;
begin
  -- orgId 机构ID
  -- drugCode 药品代码
  -- oldUnit 厂家代码
  -- unit 单位代码
  -- return  单位对应单价
 select a.RETAIL_PRICE * 
        (select scale from md_base_drug_unit where org_id = orgId and m_code = drugCode and unit_code = unit)/
        (select scale from md_base_drug_unit where org_id = orgId and m_code = drugCode and unit_code = a.unit_code) 
 into Result
  from md_base_drug_price a
  where a.org_id = orgId and a.m_code = drugCode and a.factory_code = factoryCode;
  return round(Result,4);
  exception
  when NO_DATA_FOUND then
  return null;
end get_Drug_store_Price;
/

