create procedure SP_REPORT_EHR_FAMILY_STRUCTURE

/********************************************************************/
/*                                                                  */
/*           健康档案_家庭人口结构                                  */
/*                                                                  */
/********************************************************************/

as
  REPORT_DATE  VARCHAR(8);
begin

   REPORT_DATE :=to_char(sysdate - 1,'yyyymmdd');

   begin
     savepoint point; ---记录保存点---

     delete from REPORT_EHR_FAMILY_STRUCTURE where report_date=REPORT_DATE;

     --insert
     insert into REPORT_EHR_FAMILY_STRUCTURE(REPORT_DATE,ORG_ID,STRUCTURE_TYPE,STRUCTURE_TYPE_NAME,SUMS,
     UPDATE_TIME,CREATE_DATE,DISTRICT_ID)
     select REPORT_DATE,PT_ORG_ID ,STRUCTURE_TYPE,STRUCTURE_TYPE_NAME,count(0) sums,sysdate,sysdate,district_id
      from (
        select PT_ORG_ID ,district_id,nvl(t2.cv_value,'388999') as STRUCTURE_TYPE ,nvl(t2.cv_value_meanings,'未知类型') as STRUCTURE_TYPE_NAME from
        (
               select p.PT_ORG_ID ,p.committee district_id,t1.structure_type from ehr_family_rela t3, ehr_family t1,ehr_person p
               where ( p.status = '0') and t1.id=t3.family_id and t3.person_id=p.id and p.committee is not null
        )t4
        left join std_cvdict_detail t2
        on t2.cv_code='LW_CV_388' and t4.structure_type=t2.cv_value
      )group by PT_ORG_ID ,district_id,structure_type,STRUCTURE_TYPE_NAME;
     --commit;
       commit;

        --3.异常处理

        exception   when   others   then
          begin
            rollback to savepoint point;
            rollback;
          end;

    end;
end SP_REPORT_EHR_FAMILY_STRUCTURE;

/

