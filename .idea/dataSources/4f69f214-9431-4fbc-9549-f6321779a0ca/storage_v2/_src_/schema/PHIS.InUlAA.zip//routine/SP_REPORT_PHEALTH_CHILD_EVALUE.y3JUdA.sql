create procedure SP_REPORT_PHEALTH_CHILD_EVALUE(
     errorcode out int,				--返回错误代码
     errormsg out varchar2,	--返回错误参数
     p_org_id number    --机构代码
) is
/**
* REPORT公共卫生_儿童保健考核指标统计
* 统计项 应管理人数（辖区年度内0-36个月）   辖区年度内0-36个月儿童档案人数  辖区年度内0-36个月儿童新建档案人数
*        活产数 1次及以上访视的新生儿人数 1次及以上访视的0～36个月儿童数  4次及以上访视的0～36个月儿童数
* bus_type 34 新生儿家庭视访记录  58 分娩登记表
*
*/
  v_report_date  VARCHAR(8):= to_char(sysdate,'yyyymmdd'); --报表日期
  v_new_baby_days number :=30;           --出生30天之内的为新生儿
  v_num number;
  v_create_date date := sysdate;--创建时间
begin
   select count(0) into v_num  from REPORT_PHEALTH_CHILD_EVALUE where REPORT_DATE = v_report_date and ORG_ID = p_org_id ;
   if v_num>0 then
      select create_date into v_create_date from REPORT_PHEALTH_CHILD_EVALUE where REPORT_DATE = v_report_date and ORG_ID = p_org_id and  rownum=1;
   end if;

   delete from REPORT_PHEALTH_CHILD_EVALUE where REPORT_DATE = v_report_date and ORG_ID = p_org_id ;

   insert into REPORT_PHEALTH_CHILD_EVALUE(REPORT_DATE,ORG_ID,SHOULD_SUM,FILING_SUM,NEW_SUM,LIVE_SUM,VISIT_NEONATE_SUM,VISIT_CHILD_SUM,FOUR_VISIT_CHILD_SUM,UPDATE_TIME,CREATE_DATE)
   values( v_report_date, p_org_id,
     -- 应管理人数（辖区年度内0-6岁）
     (select count(0) from ehr_person s
      inner join phealth_child_roster pcr on (s.id = pcr.patient_id)
      where s.pt_org_id = p_org_id and (s.status = '0')
      ),
     -- 辖区年度内0-6岁儿童档案人数
     (select count(0) from ehr_person s
      inner join phealth_child_roster pcr on (s.id = pcr.patient_id)
      inner join PHealth_spec_case ps on ps.id = pcr.spec_id --and ( ps.person_id = pcr.patient_id )
      where s.pt_org_id = p_org_id and (s.status = '0')
      and ps.IS_MANAGEMENT = '1'

   /*
 select count(*) from PHEALTH_CHILD_ROSTER p
 inner join EHR_PERSON e on p.PATIENT_ID = e.ID and e.status = '0'
 inner join PHealth_spec_case ps on ps.id = p.spec_id and ( e.id = ps.person_id )
 WHERE e.COMMITTEE in (select a.f_code from sys_districts a start with a.f_code = 441303 connect by prior a.f_code = a.f_PARENT_code)
 and e.PT_ORG_ID in (select b.id from sys_organizations b start with b.id = 581422008 connect by prior b.id = b.parent_id)
 and ps.IS_MANAGEMENT = '1'
 */
          ),
     -- 辖区年度内0-6岁儿童新建档案人数
     (select count(0) from ehr_person s
      inner join phealth_child_roster pcr on (s.id = pcr.patient_id)
      inner join PHealth_spec_case ps on ps.id = pcr.spec_id --and ( ps.person_id = pcr.patient_id )
          where s.pt_org_id = p_org_id and to_char(ARCHIVE_DATE,'yyyy')=to_char(sysdate,'yyyy')
           and (s.status = 0)
      and ps.IS_MANAGEMENT = '1'
          ),
     --活产数
     (select count(0) from ehr_person s
      inner join phealth_child_roster pcr on (s.id = pcr.patient_id)
      where s.pt_org_id = p_org_id and (s.status = 0)
     /*
         select count(0) from
         (
                select patient_id from phealth_soap_service
                where patient_id in(
                      select id from ehr_person where pt_org_id = p_org_id and sex='2'
                ) and bus_type = 58
                group by patient_id
         )
         */
     ),
     --1次及以上访视的新生儿人数
     (
         select count(0) from
         (
                select patient_id from phealth_soap_service
                where patient_id in (
                      select id from ehr_person where pt_org_id = p_org_id and sysdate-birthday < v_new_baby_days and (status = 0)
                ) and bus_type = 34 and ( status = '0')
                group by patient_id
         )
     ),
     --1次及以上访视的0～36个月儿童数
     (
         select count(0) from
         (
                select patient_id from phealth_soap_service
                where patient_id in (
                      select id from ehr_person where pt_org_id = p_org_id and sysdate-birthday < 36*30 and (status = 0)
                ) and bus_type = 34 and ( status = '0')
                group by patient_id
         )
     ),
     --4次及以上访视的0～36个月儿童数
     (
         select count(0) from
         (
                select patient_id from phealth_soap_service
                where patient_id in (
                      select id from ehr_person where pt_org_id = p_org_id and sysdate-birthday < 36*30 and (status = 0)
                ) and bus_type = 34 and ( status = '0')
                group by patient_id having count(0)>3
         )
     ),
     sysdate, v_create_date);

   errorcode := 0;
   errormsg := 'ok';

   commit;
   exception when others then
   begin
        errorcode := -1;
        errormsg := SQLCODE||':'||SUBSTR(SQLERRM, 1, 200);
        rollback;
   end;
end SP_REPORT_PHEALTH_CHILD_EVALUE;

/

