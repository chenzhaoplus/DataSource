create function getOlderType(age in number, married in number, disabledNum in number, mentalNum in number)
return varchar2 is
begin
  if(age >= 75)then
  	if(married = 1)then
    	if(disabledNum > 0)then
      	if(mentalNum > 0)then
        	return '高龄单身残疾精神障碍';
        end if;
        return '高龄单身残疾';
      elsif(mentalNum > 0)then
      	return '高龄单身精神障碍';
      end if;
      return '高龄单身';
    else
      if(disabledNum > 0)then
				if(mentalNum > 0)then
					return '高龄残疾精神障碍';
				end if;
				return '高龄残疾';
			elsif(mentalNum > 0)then
					return '高龄精神障碍';
			end if;
    end if;
    return '高龄';
  else
    if(married = 1)then
    	if(disabledNum > 0)then
      	if(mentalNum > 0)then
        	return '单身残疾精神障碍';
        end if;
        return '单身残疾';
      elsif(mentalNum > 0)then
      	return '单身精神障碍';
      end if;
      return '单身';
    else
      if(disabledNum > 0)then
				if(mentalNum > 0)then
					return '残疾精神障碍';
				end if;
				return '残疾';
			elsif(mentalNum > 0)then
					return '精神障碍';
			end if;
    end if;
  end if;
  return null;
end getOlderType;
/

