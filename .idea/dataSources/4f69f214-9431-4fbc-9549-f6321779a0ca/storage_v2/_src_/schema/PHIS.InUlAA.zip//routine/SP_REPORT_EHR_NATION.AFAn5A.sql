create procedure SP_REPORT_EHR_NATION
  /********************************************************************/
   /*                                                                  */
   /*        REPORT健康档案_社区民族分布                               */
   /*                                                                  */
   /********************************************************************/
as
V_REPORT_DATE  VARCHAR(8);
begin
   V_REPORT_DATE :=to_char(sysdate - 1,'yyyymmdd');
   begin
     savepoint point; ---记录保存点---

     delete from REPORT_EHR_NATION where report_date=V_REPORT_DATE;

     --insert
     insert into Report_Ehr_Nation(report_date,org_id,Nation_Id,Nation_Name,amount,update_time,create_date,district_id)

     select V_REPORT_DATE,t2.PT_ORG_ID ,t2.nationality,t3.dict_name as Nation_Name,t2.sums,sysdate,sysdate,t2.committee from
     (
            select t.nationality,t.PT_ORG_ID ,t.committee,count(t.nationality)sums
            from (
                 select t1.PT_ORG_ID ,t1.committee,
                 case when nvl(t1.nationality,'98')='98' then '98' else t1.nationality end as nationality
                 from ehr_person t1 where ( t1.status = '0') and  t1.PT_ORG_ID  is not null and t1.committee is not null
            ) t
            group by t.nationality,t.PT_ORG_ID ,t.committee
      )t2 left join std_gbdict_detail t3 on t3.gb_code='GB/T3304' and t3.detail_code=t2.nationality;

      commit;

        --3.异常处理

        exception   when   others   then
          begin
            rollback to savepoint point;
            rollback;
          end;

     end;
end SP_REPORT_EHR_NATION;

/

