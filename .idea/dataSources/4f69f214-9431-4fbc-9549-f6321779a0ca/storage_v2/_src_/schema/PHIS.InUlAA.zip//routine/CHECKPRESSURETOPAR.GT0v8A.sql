create function checkPressureToPar(birthday in date,  diastolic in number, systolic in number) return integer is

begin
  if(sysdate-birthday<30) then
     if (diastolic=34 and systolic=76) then
       return 1;
     else
       return 0;
     end if;
  elsif(sysdate-birthday<365*0.5) then
       if(diastolic>=30 and diastolic<=45 and systolic>=70 and systolic<=100) then
          return 1;
       else
          return 0;
       end if;
  elsif(sysdate-birthday<365) then
       if(diastolic>=35 and diastolic<=45 and systolic>=90 and systolic<=105) then
          return 1;
       else
          return 0;
       end if;
  elsif(sysdate-birthday<365*2) then
       if(diastolic>=40 and diastolic<=50 and systolic>=85 and systolic<=105) then
          return 1;
       else
          return 0;
       end if;
  elsif(sysdate-birthday<365*7) then
       if(diastolic>=55 and diastolic<=65 and systolic>=85 and systolic<=105) then
          return 1;
       else
          return 0;
       end if;
  elsif(sysdate-birthday<365*12) then
       if(diastolic>=60 and diastolic<=75 and systolic>=90 and systolic<=110) then
          return 1;
       else
          return 0;
       end if;
  else
       if(diastolic>=60 and diastolic<=90 and systolic>=90 and systolic<=140) then
          return 1;
       else
          return 0;
       end if;
  end if;
  --return 0;
end checkPressureToPar;
/

