create procedure SP_REPORT_PHEALTH_MENTAL_JOB(
     errorcode out int,				--返回错误代码
     errormsg out varchar2,	--返回错误参数
     p_org_id number    --机构代码
) is
/**
* REPORT公共卫生_精神病管理统计---按职业
* 统计项 患病总人数   已管理人数   规范管理人数  按时服药人数 复发人数
* bus_type 24 管理卡  19 管理评估  17 随访
*/
  v_report_date  VARCHAR(8):= to_char(sysdate,'yyyymmdd'); --报表日期
  v_icd10 varchar(100) := 'I10.X02';     --诊断对应ICD10编码
  v_spec_id number := 10011;
  v_job_id varchar(100) := 'GB/T6565-2009';--职业对应国标代码
  v_num number;
  v_create_date date := sysdate;--创建时间
  v_code_drug varchar2(50) := '10000392';--按时服药数据元代码
--  v_code_drug_value varchar(200) := '5146001, 5146002, 1';--按时服药相应数据元值（不同页面不同值都可理解为按时服药，所以有3个值）
  v_code_drug_value_1 varchar(10) :='1';--按时服药相应数据元值（不同页面不同值都可理解为按时服药，所以有3个值）
  v_code_drug_value_2 varchar(10) :='5146001';--按时服药相应数据元值（不同页面不同值都可理解为按时服药，所以有3个值）
  v_code_drug_value_3 varchar(10) :='5146002';--按时服药相应数据元值（不同页面不同值都可理解为按时服药，所以有3个值）
  v_start_time_code varchar(20) := '10000257'; --初次发病时间对应数据元值
begin
    select count(0) into v_num  from REPORT_PHEALTH_MENTAL_JOB where REPORT_DATE = v_report_date and ORG_ID = p_org_id and SPEC_ID = v_spec_id;
    if v_num>0 then
    select create_date into v_create_date from REPORT_PHEALTH_MENTAL_JOB where REPORT_DATE = v_report_date and ORG_ID = p_org_id and SPEC_ID = v_spec_id and rownum=1;
    end if;

    delete from REPORT_PHEALTH_MENTAL_JOB where REPORT_DATE = v_report_date and ORG_ID = p_org_id and SPEC_ID = v_spec_id;

   --"occupation 不为 null" begin
    insert into REPORT_PHEALTH_MENTAL_JOB(REPORT_DATE,ORG_ID,SPEC_ID,JOB_ID,JOB_NAME,PERSON_COUNT,SPEC_COUNT,CHECK_COUNT,DURG_COUNT,RELAPSE_COUNT,UPDATE_TIME,CREATE_DATE)
    select v_report_date, p_org_id, v_spec_id,a.occupation, (select DICT_NAME from std_gbdict_detail where gb_code=v_job_id and detail_code=a.occupation),
    -- 患病总人数
    (
       select count(0) from phealth_mental_illness_roster where
          patient_id in (select id from ehr_person where pt_org_id = p_org_id and occupation = a.occupation and (status = 0) )

    --select count(0) from ehr_issue where icd10 = v_icd10
    --            and person_id in (select id from ehr_person where pt_org_id = p_org_id and occupation = a.occupation)
          ),
    -- 已管理人数
    (select count(0) from phealth_spec_case where spec_id = v_spec_id
          and person_id in (select id from ehr_person where pt_org_id = p_org_id and occupation = a.occupation and (status = 0) )),
    -- 规范管理人数
    (
       select count(count(0)) from phealth_soap_service s
       inner join ehr_person p on s.patient_id = p.id
       where  p.pt_org_id = p_org_id  and p.occupation=a.occupation
       and (p.status = 0)  and ( s.status = '0')
       group by s.patient_id
       having sum(case when bus_type=24 then 1 else 0 end)>0 and
       sum(case when bus_type=19 then 1 else 0 end)>0 and sum(case when bus_type=17 then 1 else 0 end)>0
    ),
    --按时服药人数
    (
      select count( distinct s2.patient_id )
      from PHEALTH_SOAP_SERVICE_metadata s2,
      (
         select s.patient_id, max(s.measure_date) as measure_date
         from PHEALTH_SOAP_SERVICE_metadata s
         inner join ehr_person e on s.Patient_Id = e.id
         inner join phealth_mental_illness_roster r on (r.patient_id = e.id)
         where e.pt_org_id = p_org_id
         and (e.status = 0) and ( s.status = '0')
         group by s.patient_id
      ) s3, ehr_person ep
      where ( s2.metadata_code = v_code_drug )
      and ( s2.metadata_value in ( v_code_drug_value_1, v_code_drug_value_2, v_code_drug_value_3  ) )
      and ( s2.patient_id = s3.patient_id ) and ( s2.measure_date = s3.measure_date )
      and ( ep.id = s3.patient_id ) and ( ep.occupation = a.occupation )
      and ( ep.status = 0) and ( s2.status = '0')

    ),
    --复发人数
    (
      select count( distinct s2.patient_id )
      from PHEALTH_SOAP_SERVICE_metadata s2,
      (
         select s.patient_id, max(s.measure_date) as measure_date
         from PHEALTH_SOAP_SERVICE_metadata s
         inner join ehr_person e on s.Patient_Id = e.id
         inner join phealth_mental_illness_roster r on (r.patient_id = e.id)
         where e.pt_org_id = p_org_id
          and (e.status = 0)  and ( s.status = '0')
         group by s.patient_id
      ) s3, ehr_person ep
      where ( s2.metadata_code = v_start_time_code ) --初次发病时间有数据，不为null，即是复发
      and ( s2.patient_id = s3.patient_id ) and ( s2.measure_date = s3.measure_date )
      and ( ep.id = s3.patient_id ) and ( ep.occupation = a.occupation )
      and ( ep.status = 0)  and ( s2.status = '0')

    ),
    sysdate, v_create_date
    from ehr_person a
    where a.pt_org_id = p_org_id
    and a.occupation is not null
    and (a.status = 0)
    group by a.occupation;
   --"occupation 不为 null" begin

   --"occupation 为 null" begin
    insert into REPORT_PHEALTH_MENTAL_JOB(REPORT_DATE,ORG_ID,SPEC_ID,JOB_ID,JOB_NAME,PERSON_COUNT,SPEC_COUNT,CHECK_COUNT,DURG_COUNT,RELAPSE_COUNT,UPDATE_TIME,CREATE_DATE)
    select v_report_date, p_org_id, v_spec_id,-1, '未填',
    -- 患病总人数
    (
       select count(0) from phealth_mental_illness_roster where
          patient_id in (select id from ehr_person where pt_org_id = p_org_id and occupation is null and (status = 0) )

    --select count(0) from ehr_issue where icd10 = v_icd10
    --            and person_id in (select id from ehr_person where pt_org_id = p_org_id and occupation is null)
          ),
    -- 已管理人数
    (select count(0) from phealth_spec_case where spec_id = v_spec_id
          and person_id in (select id from ehr_person where pt_org_id = p_org_id and occupation is null and (status = 0) )),
    -- 规范管理人数
    (
       select count(count(0)) from phealth_soap_service s
       inner join ehr_person p on s.patient_id = p.id
       where  p.pt_org_id = p_org_id  and p.occupation is null
       and (p.status = 0)  and ( s.status = '0')
       group by s.patient_id
       having sum(case when bus_type=24 then 1 else 0 end)>0 and
       sum(case when bus_type=19 then 1 else 0 end)>0 and sum(case when bus_type=17 then 1 else 0 end)>0
    ),
    --按时服药人数
    (
      select count( distinct s2.patient_id )
      from PHEALTH_SOAP_SERVICE_metadata s2,
      (
         select s.patient_id, max(s.measure_date) as measure_date
         from PHEALTH_SOAP_SERVICE_metadata s
         inner join ehr_person e on s.Patient_Id = e.id
         inner join phealth_mental_illness_roster r on (r.patient_id = e.id)
         where e.pt_org_id = p_org_id and (e.status = 0)  and ( s.status = '0')
         group by s.patient_id
      ) s3, ehr_person ep
      where ( s2.metadata_code = v_code_drug )
      and ( s2.metadata_value in ( v_code_drug_value_1, v_code_drug_value_2, v_code_drug_value_3  ) )
      and ( s2.patient_id = s3.patient_id ) and ( s2.measure_date = s3.measure_date )
      and ( ep.id = s3.patient_id ) and ( ep.occupation is null )
      and ( ep.status = 0)  and ( s2.status = '0')

    ),
    --复发人数
    (
      select count( distinct s2.patient_id )
      from PHEALTH_SOAP_SERVICE_metadata s2,
      (
         select s.patient_id, max(s.measure_date) as measure_date
         from PHEALTH_SOAP_SERVICE_metadata s
         inner join ehr_person e on s.Patient_Id = e.id
         inner join phealth_mental_illness_roster r on (r.patient_id = e.id)
         where e.pt_org_id = p_org_id
         and (e.status = 0)  and ( s.status = '0')
         group by s.patient_id
      ) s3, ehr_person ep
      where ( s2.metadata_code = v_start_time_code ) --初次发病时间有数据，不为null，即是复发
      and ( s2.patient_id = s3.patient_id ) and ( s2.measure_date = s3.measure_date )
      and ( ep.id = s3.patient_id ) and ( ep.occupation is null )
      and ( ep.status = 0)  and ( s2.status = '0')

    ),
    sysdate, v_create_date
    from ehr_person a
    where a.pt_org_id = p_org_id
    and (a.status = 0)
    and a.occupation is null
    group by a.occupation;
   --"occupation 为 null" begin

    errorcode := 0;
    errormsg := 'ok';

   commit;
   exception when others then
   begin
        errorcode := -1;
        errormsg := SQLCODE||':'||SUBSTR(SQLERRM, 1, 200);
        rollback;
   end;
end SP_REPORT_PHEALTH_MENTAL_JOB;

/

