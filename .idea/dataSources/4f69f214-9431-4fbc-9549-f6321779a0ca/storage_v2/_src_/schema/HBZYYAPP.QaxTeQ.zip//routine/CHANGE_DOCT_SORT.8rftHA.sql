create procedure change_doct_sort(curId in number,nextId in number)
as
cursort number(20);
nextsort number(20);
--select doct_sort from wms_doct_schedule where id = 1
begin
  select doct_sort into cursort from wms_doct_schedule where id = curId;
  select doct_sort into nextsort from wms_doct_schedule where id = nextId;
  update wms_doct_schedule set doct_sort = cursort where id = nextId;
  update wms_doct_schedule set doct_sort = nextsort where id = curId;
  commit;
end;
/

