create PROCEDURE AA
AS
  cursor cur1 is 
  select "门诊号" from ZKR_MZBRCX;
  --cur2 ZKR_MZBRCX%TYPE;
   aa varchar(200);
BEGIN
   open cur1;
   fetch cur1 into aa;
    
   close cur1;
end;
/

