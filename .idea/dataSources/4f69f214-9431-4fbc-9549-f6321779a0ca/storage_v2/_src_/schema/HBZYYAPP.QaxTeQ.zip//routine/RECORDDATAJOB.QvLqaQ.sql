create procedure RecordDataJob is
begin

declare
   --1.声明游标
   cursor vrows is
  select * from zkr_mzbrcx; --where 门诊日期  >= trunc(sysdate) and 门诊日期  < trunc(sysdate)+1 order by 门诊日期;
   --声明变量,记录一行数据
   vrow zkr_mzbrcx%rowtype;
begin
   --2.打开游标
   open vrows;
   --3.循环遍历,取数据
   loop
       fetch vrows into vrow;
       exit when vrows%notfound;
        INSERT INTO ZKR_MZBL( 病历号,门诊号,姓名,病历名称,创建时间,科室编号,科室名称,医生编号,医生名称,病历内容)
        select  病历号,门诊号,姓名,病历名称,创建时间,科室编号,
            科室名称,医生编号,医生名称,病历内容 from ZKR_MZBL@zsyyapplinkdoc
            where 门诊号= vrow.门诊号;

   end loop;
   --4.关闭游标
   close vrows;

end;
  /

