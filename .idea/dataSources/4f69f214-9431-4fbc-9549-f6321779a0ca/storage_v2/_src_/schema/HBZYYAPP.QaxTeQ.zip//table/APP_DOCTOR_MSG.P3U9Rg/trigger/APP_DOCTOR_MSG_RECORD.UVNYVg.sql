create trigger APP_DOCTOR_MSG_RECORD
  before insert
  on APP_DOCTOR_MSG
  for each row
  declare
  nextid number;
begin
  IF :new.ID IS NULL or :new.ID=0 THEN
  select SEQ_FIRST_RECORD.nextval
  into nextid
    from sys.dual;
    :new.ID:=nextid;
  end if;
end app_doctor_msg_RECORD;
/

