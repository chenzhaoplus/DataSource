create procedure myDemo03(name in varchar,age in int)
as
begin
  dbms_output.put_line('name='||name||', age='||age);
end;
/

