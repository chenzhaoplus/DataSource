create procedure update_sort
as
begin
  update wms_doct_schedule set doct_sort =  1 where id =  49;
  commit;
end update_sort;
/

