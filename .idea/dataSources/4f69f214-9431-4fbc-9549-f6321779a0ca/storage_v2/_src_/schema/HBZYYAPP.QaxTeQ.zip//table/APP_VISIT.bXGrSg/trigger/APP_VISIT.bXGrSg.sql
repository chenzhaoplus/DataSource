create trigger APP_VISIT
  before insert
  on APP_VISIT
  for each row
  begin
 select SEQ_T_HIDE_DRUG.nextval into :new.ID from dual;
end;
/

