create procedure test_select3_procedure
AS
--游标的定义
Cursor test_cursor is
select * from ZKR_ZDCX;
cur test_cursor%rowtype;  --游标的类型，我理解类似于list的泛型
BEGIN
--for cur in test_cursor loop
--exit when test_cursor%notfound;
dbms_output.put_line('数据是:');
--end loop;
END;
/

