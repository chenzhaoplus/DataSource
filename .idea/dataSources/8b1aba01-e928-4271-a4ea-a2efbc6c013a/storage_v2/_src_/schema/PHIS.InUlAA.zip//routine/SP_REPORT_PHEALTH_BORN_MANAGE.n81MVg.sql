create procedure SP_REPORT_PHEALTH_BORN_MANAGE(
     errorcode out int,				--返回错误代码
     errormsg out varchar2,	--返回错误参数
     p_org_id number    --机构代码
) is
/**
* REPORT公共卫生_儿童保健考核指标统计
* 统计项 产前检查_孕三个月   产前检查_小于5次  产前检查_大于等于5次  孕产期血红蛋白_大于110 孕产期血红蛋白_等于110
*       孕产期血红蛋白_等于100  孕产期血红蛋白_等于90 孕产期血红蛋白_小于60 孕产期筛查_HIV检测 孕产期筛查_HIV阳性
*     孕产期筛查_梅毒检测   孕产期筛查_梅毒确诊 孕产期筛查_筛查检测 孕产期筛查_筛查阳性 孕产期筛查_诊断检测 孕产期筛查_诊断确诊
*       住院分娩  高危妊娠_是高危 高危妊娠_管理  接生方式_科学 接生方式_新法 接生方式_脐带卷消毒 分娩方式_顺产 分娩方式_剖宫
*       分娩方式_阴道手术  婴儿转归_活产  婴儿转归_死胎  婴儿转归_死亡  婴儿情况_体重小于2千5百克 婴儿情况_畸形 婴儿情况_破伤风
*       孕妇死亡_孕妇死亡 孕妇死亡_产妇死亡 孕妇死亡_产科出血 孕妇死亡_妊高症 孕妇死亡_产褥感染 孕妇死亡_合并症 孕妇死亡_羊水栓塞
*        产后访视_一次 产后访视_二次 产后访视_四次 新生儿访视_一次 新生儿访视_二次 新生儿访视_三次 新生儿访视_四次
* bus_type 34 新生儿家庭视访记录  58 分娩登记表
*
*/
  v_report_date  VARCHAR(8):= to_char(sysdate,'yyyymmdd'); --报表日期
  v_num number;
  v_create_date date := sysdate;--创建时间
begin
   select count(0) into v_num  from REPORT_PHEALTH_BORN_MANAGE where REPORT_DATE = v_report_date and ORG_ID = p_org_id ;
   if v_num>0 then
      select create_date into v_create_date from REPORT_PHEALTH_BORN_MANAGE where REPORT_DATE = v_report_date and ORG_ID = p_org_id and  rownum=1;
   end if;

   delete from REPORT_PHEALTH_BORN_MANAGE where REPORT_DATE = v_report_date and ORG_ID = p_org_id ;

   insert into REPORT_PHEALTH_BORN_MANAGE(REPORT_DATE,ORG_ID,CQJC_A,CQJC_B,CQJC_C,XHDB_A,XHDB_B,XHDB_C,XHDB_D,
     XHDB_E,YCQSC_A,YCQSC_B,YCQSC_C,YCQSC_D,YCQSC_E,YCQSC_F,YCQSC_G,YCQSC_H,ZYFM,GWRS_A,GWRS_B,JSFS_A,JSFS_B,JSFS_C,
     FMFS_A,FMFS_B,FMFS_C,YEZG_A,YEZG_B,YEZG_C,YEQK_A,YEQK_B,YEQK_C,YFSW_A,YFSW_B,YFSW_C,YFSW_D,YFSW_E,YFSW_F,YFSW_G,
     CHFS_A,CHFS_B,CHFS_C,CHFS_D,XSEFS_A,XSEFS_B,XSEFS_C,XSEFS_D,UPDATE_TIME,CREATE_DATE)
   values( v_report_date, p_org_id,
     -- 产前检查_孕三个月
     (
        select count(0) from (
               select p.patient_id from phealth_soap_service p
               where p.patient_id in (
                     select id from ehr_person where pt_org_id = p_org_id and (status = 0) and sex = '1'
               ) and bus_type = 59 and ( p.status = '0')
               group by p.patient_id
        )
     ),
     -- 产前检查_小于5次
     (
        select count(0) from (
               select p.patient_id from phealth_soap_service p
               where p.patient_id in (
                     select id from ehr_person where pt_org_id = p_org_id and (status = 0) and sex = '1'
               ) and bus_type = 59 and ( p.status = '0')
           group by p.patient_id)
      ),
     -- 产前检查_大于等于5次
     (
        select count(0) from (
               select p.patient_id from phealth_soap_service p
               where p.patient_id in (
                     select id from ehr_person where pt_org_id = p_org_id and (status = 0) and sex = '1'
               ) and bus_type = 59 and ( p.status = '0')
               group by p.patient_id
        )
     ),
     --孕产期血红蛋白_大于110
     (
        select count(0) from (
               select p.patient_id from phealth_soap_service p
               where p.patient_id in(
                     select id from ehr_person where pt_org_id = p_org_id and (status = 0) and sex='2'
               ) and bus_type = 59 and ( p.status = '0')
               group by p.patient_id
        )
     ),
     --孕产期血红蛋白_等于110
     (
        select count(0) from (
               select p.patient_id from phealth_soap_service p
               where p.patient_id in(select id from ehr_person where pt_org_id = p_org_id and (status = 0) and sex='2' ) and bus_type = 59
               and ( p.status = '0')
               group by p.patient_id
        )
     ),
     -- 孕产期血红蛋白_等于100
     (
        select count(0) from (
               select p.patient_id from phealth_soap_service p
               where p.patient_id in(select id from ehr_person where pt_org_id = p_org_id and (status = 0) and sex='2' ) and bus_type = 59
               and ( p.status = '0')
               group by p.patient_id
        )
     ),
     --孕产期血红蛋白_等于90
     (
        select count(0) from (
               select p.patient_id from phealth_soap_service p
               where p.patient_id in(select id from ehr_person where pt_org_id = p_org_id and (status = 0) and sex='2' ) and bus_type = 59
               and ( p.status = '0')
               group by p.patient_id
        )
     ),
     --孕产期血红蛋白_小于60
     (
        select count(0) from (
               select p.patient_id from phealth_soap_service p
               where p.patient_id in(select id from ehr_person where pt_org_id = p_org_id and (status = 0) and sex='2' ) and bus_type = 59
               and ( p.status = '0')
               group by p.patient_id
        )
     ),
     --孕产期筛查_HIV检测
     (
        select count(0) from (
               select p.patient_id from phealth_soap_service p
               where p.patient_id in(select id from ehr_person where pt_org_id = p_org_id and (status = 0) and sex='2' ) and bus_type = 59
               and ( p.status = '0')
               group by p.patient_id
        )
     ),
     --孕产期筛查_HIV阳性
     (
        select count(0) from (
               select p.patient_id from phealth_soap_service p
               where p.patient_id in(select id from ehr_person where pt_org_id = p_org_id and (status = 0) and sex='2' ) and bus_type = 59
               and ( p.status = '0')
               group by p.patient_id
        )
     ),
     --孕产期筛查_梅毒检测
     (
        select count(0) from (
               select p.patient_id from phealth_soap_service p
               where p.patient_id in(select id from ehr_person where pt_org_id = p_org_id and (status = 0) and sex='2' ) and bus_type = 59
               and ( p.status = '0')
               group by p.patient_id
        )
     ),
     --孕产期筛查_梅毒确诊
     (
        select count(0) from (
               select p.patient_id from phealth_soap_service p
               where p.patient_id in(select id from ehr_person where pt_org_id = p_org_id and (status = 0) and sex='2' ) and bus_type = 59
               and ( p.status = '0')
               group by p.patient_id
        )
     ),
     --孕产期筛查_筛查检测
     (
        select count(0) from (
               select p.patient_id from phealth_soap_service p
               where p.patient_id in(select id from ehr_person where pt_org_id = p_org_id and (status = 0) and sex='2' ) and bus_type = 59
               and ( p.status = '0')
               group by p.patient_id
        )
     ),
     --孕产期筛查_筛查阳性
     (
        select count(0) from (
               select p.patient_id from phealth_soap_service p
               where p.patient_id in(select id from ehr_person where pt_org_id = p_org_id and (status = 0) and sex='2' ) and bus_type = 59
               and ( p.status = '0')
               group by p.patient_id
        )
     ),
     --孕产期筛查_诊断检测
     (
        select count(0) from (
               select p.patient_id from phealth_soap_service p
               where p.patient_id in(select id from ehr_person where pt_org_id = p_org_id and (status = 0) and sex='2' ) and bus_type = 59
               and ( p.status = '0')
               group by p.patient_id
        )
     ),
     --孕产期筛查_诊断确诊
     (
        select count(0) from (
               select p.patient_id from phealth_soap_service p
               where p.patient_id in(select id from ehr_person where pt_org_id = p_org_id and (status = 0) and sex='2' ) and bus_type = 59
               and ( p.status = '0')
               group by p.patient_id
        )
     ),
     --住院分娩
     (
        select count(0) from (
               select p.patient_id from phealth_soap_service p
               where p.patient_id in(select id from ehr_person where pt_org_id = p_org_id and (status = 0) and sex='2' ) and bus_type = 59
               and ( p.status = '0')
               group by p.patient_id
        )
     ),
     --高危妊娠_是高危
     (
        select count(0) from (
               select p.patient_id from phealth_soap_service p
               where p.patient_id in(select id from ehr_person where pt_org_id = p_org_id and (status = 0) and sex='2' ) and bus_type = 59
               and ( p.status = '0')
               group by p.patient_id
        )
     ),
     --高危妊娠_管理
     (
        select count(0) from (
               select p.patient_id from phealth_soap_service p
               where p.patient_id in(select id from ehr_person where pt_org_id = p_org_id and (status = 0) and sex='2' ) and bus_type = 59
               and ( p.status = '0')
               group by p.patient_id
        )
     ),
     --接生方式_科学
     (
        select count(0) from (
               select p.patient_id from phealth_soap_service p
               where p.patient_id in(select id from ehr_person where pt_org_id = p_org_id and (status = 0) and sex='2' ) and bus_type = 59
               and ( p.status = '0')
               group by p.patient_id
        )
     ),
     --接生方式_新法
     (
        select count(0) from (
               select p.patient_id from phealth_soap_service p
               where p.patient_id in(select id from ehr_person where pt_org_id = p_org_id and (status = 0) and sex='2' ) and bus_type = 59
               and ( p.status = '0')
               group by p.patient_id
        )
     ),
     --接生方式_脐带卷消毒
     (
        select count(0) from (
               select p.patient_id from phealth_soap_service p
               where p.patient_id in(select id from ehr_person where pt_org_id = p_org_id and (status = 0) and sex='2' ) and bus_type = 59
               and ( p.status = '0')
               group by p.patient_id
        )
     ),
     --分娩方式_顺产
     (
        select count(0) from (
               select p.patient_id from phealth_soap_service p
               where p.patient_id in(select id from ehr_person where pt_org_id = p_org_id and (status = 0) and sex='2' ) and bus_type = 59
               and ( p.status = '0')
               group by p.patient_id
        )
     ),
     --分娩方式_剖宫
     (
        select count(0) from (
               select p.patient_id from phealth_soap_service p
               where p.patient_id in(select id from ehr_person where pt_org_id = p_org_id and (status = 0) and sex='2' ) and bus_type = 59
               and ( p.status = '0')
               group by p.patient_id
        )
     ),
     --分娩方式_阴道手术
     (
        select count(0) from (
               select p.patient_id from phealth_soap_service p
               where p.patient_id in(select id from ehr_person where pt_org_id = p_org_id and (status = 0) and sex='2' ) and bus_type = 59
               and ( p.status = '0')
               group by p.patient_id
        )
     ),
     --婴儿转归_活产
     (
        select count(0) from (
               select p.patient_id from phealth_soap_service p
               where p.patient_id in(select id from ehr_person where pt_org_id = p_org_id and (status = 0) and sex='2' ) and bus_type = 59
               and ( p.status = '0')
               group by p.patient_id
        )
     ),
     --婴儿转归_死胎
     (
        select count(0) from (
               select p.patient_id from phealth_soap_service p
               where p.patient_id in(select id from ehr_person where pt_org_id = p_org_id and (status = 0) and sex='2' ) and bus_type = 59
               and ( p.status = '0')
               group by p.patient_id
        )
     ),
     --婴儿转归_死亡
     (
        select count(0) from (
               select p.patient_id from phealth_soap_service p
               where p.patient_id in(select id from ehr_person where pt_org_id = p_org_id and (status = 0) and sex='2' ) and bus_type = 59
               and ( p.status = '0')
               group by p.patient_id
        )
     ),
     --婴儿情况_体重小于2千5百克
     (
        select count(0) from (
               select p.patient_id from phealth_soap_service p
               where p.patient_id in(select id from ehr_person where pt_org_id = p_org_id and (status = 0) and sex='2' ) and bus_type = 59
               and ( p.status = '0')
               group by p.patient_id
        )
     ),
     --婴儿情况_畸形
     (
        select count(0) from (
               select p.patient_id from phealth_soap_service p
               where p.patient_id in(select id from ehr_person where pt_org_id = p_org_id and (status = 0) and sex='2' ) and bus_type = 59
               and ( p.status = '0')
               group by p.patient_id
        )
     ),
     --婴儿情况_破伤风
     (
        select count(0) from (
               select p.patient_id from phealth_soap_service p
               where p.patient_id in(select id from ehr_person where pt_org_id = p_org_id and (status = 0) and sex='2' ) and bus_type = 59
               and ( p.status = '0')
               group by p.patient_id
        )
     ),
     --孕妇死亡_孕妇死亡
     (
        select count(0) from (
               select p.patient_id from phealth_soap_service p
               where p.patient_id in(select id from ehr_person where pt_org_id = p_org_id and (status = 0) and sex='2' ) and bus_type = 59
               and ( p.status = '0')
               group by p.patient_id
        )
     ),
     --孕妇死亡_产妇死亡
     (
        select count(0) from (
               select p.patient_id from phealth_soap_service p
               where p.patient_id in(select id from ehr_person where pt_org_id = p_org_id and (status = 0) and sex='2' ) and bus_type = 59
               and ( p.status = '0')
               group by p.patient_id
        )
     ),
     --孕妇死亡_产科出血
     (
        select count(0) from (
               select p.patient_id from phealth_soap_service p
               where p.patient_id in(select id from ehr_person where pt_org_id = p_org_id and (status = 0) and sex='2' ) and bus_type = 59
               and ( p.status = '0')
               group by p.patient_id
        )
     ),
     --孕妇死亡_妊高症
     (
        select count(0) from (
               select p.patient_id from phealth_soap_service p
               where p.patient_id in(select id from ehr_person where pt_org_id = p_org_id and (status = 0) and sex='2' ) and bus_type = 59
               and ( p.status = '0')
               group by p.patient_id
        )
     ),
     --孕妇死亡_产褥感染
     (
        select count(0) from (
               select p.patient_id from phealth_soap_service p
               where p.patient_id in(select id from ehr_person where pt_org_id = p_org_id and (status = 0) and sex='2' ) and bus_type = 59
               and ( p.status = '0')
               group by p.patient_id
        )
     ),
     --孕妇死亡_合并症
     (
        select count(0) from (
               select p.patient_id from phealth_soap_service p
               where p.patient_id in(select id from ehr_person where pt_org_id = p_org_id and (status = 0) and sex='2' ) and bus_type = 59
               and ( p.status = '0')
               group by p.patient_id
        )
     ),
     --孕妇死亡_羊水栓塞
     (
        select count(0) from (
               select p.patient_id from phealth_soap_service p
               where p.patient_id in(select id from ehr_person where pt_org_id = p_org_id and (status = 0) and sex='2' ) and bus_type = 59
               and ( p.status = '0')
               group by p.patient_id
        )
     ),
     --产后访视_一次
     (
        select count(0) from (
               select p.patient_id from phealth_soap_service p
               where p.patient_id in(select id from ehr_person where pt_org_id = p_org_id and (status = 0) and sex='2' ) and bus_type = 59
               and ( p.status = '0')
               group by p.patient_id
        )
     ),
     --产后访视_二次
     (
        select count(0) from (
               select p.patient_id from phealth_soap_service p
               where p.patient_id in(select id from ehr_person where pt_org_id = p_org_id and (status = 0) and sex='2' ) and bus_type = 59
               and ( p.status = '0')
               group by p.patient_id
        )
     ),
     --产后访视_三次
     (
        select count(0) from (
               select p.patient_id from phealth_soap_service p
               where p.patient_id in(select id from ehr_person where pt_org_id = p_org_id and (status = 0) and sex='2' ) and bus_type = 59
               and ( p.status = '0')
               group by p.patient_id
        )
     ),
     --产后访视_四次
     (
        select count(0) from (
               select p.patient_id from phealth_soap_service p
               where p.patient_id in(select id from ehr_person where pt_org_id = p_org_id and (status = 0) and sex='2' ) and bus_type = 59
               and ( p.status = '0')
               group by p.patient_id
        )
     ),
     --新生儿访视_一次
     (
        select count(0) from (
               select p.patient_id from phealth_soap_service p
               where p.patient_id in(select id from ehr_person where pt_org_id = p_org_id and (status = 0) and sex='2' ) and bus_type = 59
               and ( p.status = '0')
               group by p.patient_id
        )
     ),
     --新生儿访视_二次
     (
        select count(0) from (
               select p.patient_id from phealth_soap_service p
               where p.patient_id in(select id from ehr_person where pt_org_id = p_org_id and (status = 0) and sex='2' ) and bus_type = 59
               and ( p.status = '0')
               group by p.patient_id
        )
     ),
     --新生儿访视_三次
     (
        select count(0) from (
               select p.patient_id from phealth_soap_service p
               where p.patient_id in(select id from ehr_person where pt_org_id = p_org_id and (status = 0) and sex='2' ) and bus_type = 59
               and ( p.status = '0')
               group by p.patient_id
        )
     ),
     --新生儿访视_四次
     (
        select count(0) from (
               select p.patient_id from phealth_soap_service p
               where p.patient_id in(select id from ehr_person where pt_org_id = p_org_id and (status = 0) and sex='2' ) and bus_type = 59
               and ( p.status = '0')
               group by p.patient_id
        )
     ),
     sysdate, v_create_date);

   errorcode := 0;
   errormsg := 'ok';

   commit;
   exception when others then
   begin
        errorcode := -1;
        errormsg := SQLCODE||':'||SUBSTR(SQLERRM, 1, 200);
        rollback;
   end;
end SP_REPORT_PHEALTH_BORN_MANAGE;

/

