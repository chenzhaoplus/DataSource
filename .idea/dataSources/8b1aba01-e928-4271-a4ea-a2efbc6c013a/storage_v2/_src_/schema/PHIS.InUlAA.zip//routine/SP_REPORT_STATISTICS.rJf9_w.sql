create procedure SP_REPORT_Statistics as
  errorcode int;
  errormsg varchar2(200);
begin
  --SP_REPORT_EHR_NOPASS_ARCHIVE;                  --01.健康档案_不完善健康档案
                                                 --(由于 java程序会实时修改表REPORT_EHR_NOPASS_ARCHIVE，
                                                 -- 此存储过程在第一次可生成所有数据的时候，以后可不执行此存储过程)
  SP_REPORT_EHR_OCCUPATION;                      --02.健康档案_社区职业构成
  SP_REPORT_EHR_PAY_TYPE;                        --03.健康档案_社区付费类型
  SP_REPORT_EHR_FAMILY_STRUCTURE;                --04.健康档案_家庭人口结构
  SP_REPORT_EHR_BLOOD;                           --05.健康档案_社区血型分类情况统计表
  SP_REPORT_EHR_EDUCATE;                         --06.健康档案_学历统计
  SP_REPORT_EHR_NATION;                          --07.健康档案_社区民族分布
  SP_REPORT_EHR_ARCHIVE_SCALE;                   --08.健康档案_健康档案及家庭档案的数量(健康档案建档率)
  SP_REPORT_EHR_HOUSERHODER;                     --09.社区户籍分类统计
  SP_REPORT_EHR_AGE;                             --10.社区年龄构成统计
  SP_REPORT_EHR_BMI;                             --11.社区BMI指数分布统计
  SP_REPORT_EHR_CHILD;                           --12.社区儿童构成统计
  SP_REPORT_EHR_BEARING_WOMAN;                   --13.社区育龄妇女构成统计
  SP_REPORT_EHR_OLD_MAN;                         --14.社区老年人构成统计
  SP_REPORT_EHR_ISSUE;                           --15.健康问题目录
  SP_REPORT_EHR_GOLD_TOWER;                      --16.健康档案_社区人口金字塔
  SP_REPORT_EHR_USE_SCALE;                       --17.健康档案_社区服务统计
  SP_REPORT_PHEALTH_PERSON;                      --18.健康档案_社区人数统计
  SP_REPORT_EHR_STAT_QUALIFIED;                  --19.健康档案_建档统计及合格率
                                                 --(此存储过程从存储过程 SP_REPORT_EHR_NOPASS_ARCHIVE 生成的数据再计算)
  errorcode := 0;
  errormsg  := '';

  begin

    declare
    CURSOR EP_CURSOR is select t.id from sys_organizations t ;
    BEGIN
      FOR EC IN EP_CURSOR LOOP
        sp_report_phealth_hy(errorcode, errormsg, EC.id);                --41.疾病管理_高血压管理考核指标统计.sql
        SP_REPORT_PHEALTH_HY_AGE(errorcode, errormsg, EC.id);            --42.疾病管理_高血压按年龄段统计.sql
        SP_REPORT_PHEALTH_HY_SEX(errorcode, errormsg, EC.id);            --43.疾病管理_高血压按性别统计.sql
        SP_REPORT_PHEALTH_HY_JOB(errorcode, errormsg, EC.id);            --44.疾病管理_高血压按职业统计.sql
        SP_REPORT_PHEALTH_DIABETES(errorcode, errormsg, EC.id);          --45.疾病管理_糖尿病管理考核指标统计.sql
        SP_REPORT_PHEALTH_DIABETES_AGE(errorcode, errormsg, EC.id);      --46.疾病管理_糖尿病按年龄段统计.sql
        SP_REPORT_PHEALTH_DIABETES_SEX(errorcode, errormsg, EC.id);      --47.疾病管理_糖尿病按性别统计.sql
        SP_REPORT_PHEALTH_DIABETES_JOB(errorcode, errormsg, EC.id);      --48.疾病管理_糖尿病按职业统计.sql
        SP_REPORT_PHEALTH_MENTAL(errorcode, errormsg, EC.id);            --49.疾病管理_精神病管理考核指标统计.sql
        SP_REPORT_PHEALTH_MENTAL_AGE(errorcode, errormsg, EC.id);        --50.疾病管理_精神病按年龄段统计.sql
        SP_REPORT_PHEALTH_MENTAL_SEX(errorcode, errormsg, EC.id);        --51.疾病管理_精神病按性别统计.sql
        SP_REPORT_PHEALTH_MENTAL_JOB(errorcode, errormsg, EC.id);        --52.疾病管理_精神病按职业统计.sql
        SP_REPORT_PHEALTH_STROKE(errorcode, errormsg, EC.id);            --53.疾病管理_脑卒中管理考核指标统计.sql
        SP_REPORT_PHEALTH_STROKE_AGE(errorcode, errormsg, EC.id);        --54.疾病管理_脑卒中按年龄段统计.sql
        SP_REPORT_PHEALTH_STROKE_SEX(errorcode, errormsg, EC.id);        --55.疾病管理_脑卒中按性别统计.sql
        SP_REPORT_PHEALTH_STROKE_JOB(errorcode, errormsg, EC.id);        --56.疾病管理_脑卒中按职业统计.sql
        SP_REPORT_PHEALTH_TUBER(errorcode, errormsg, EC.id);             --71.疾病控制_结核病管理考核指标统计.sql
        SP_REPORT_PHEALTH_TUBER_AGE(errorcode, errormsg, EC.id);         --72.疾病控制_结核病按年龄段统计.sql
        SP_REPORT_PHEALTH_TUBER_SEX(errorcode, errormsg, EC.id);         --73.疾病控制_结核病按性别统计.sql
        SP_REPORT_PHEALTH_TUBER_JOB(errorcode, errormsg, EC.id);         --74.疾病控制_结核病按职业统计.sql
        SP_REPORT_PHEALTH_HY_ANALYSE(errorcode, errormsg, EC.id);        --57.疾病管理_高血压每月增长人数统计.sql
        SP_REPORT_PHEALTH_DIABETES_ANA(errorcode, errormsg, EC.id);      --58.疾病管理_糖尿病每月增长人数统计.sql
        SP_REPORT_PHEALTH_MENTAL_ANA(errorcode, errormsg, EC.id);        --59.疾病管理_精神病每月增长人数统计.sql
        SP_REPORT_PHEALTH_STROKE_ANA(errorcode, errormsg, EC.id);        --60.疾病管理_脑卒中每月增长人数统计.sql
        SP_REPORT_PHEALTH_TUBER_ANA(errorcode, errormsg, EC.id);         --61.疾病管理_结核病每月增长人数统计.sql

        SP_REPORT_PHEALTH_CHILD_EVALUE(errorcode, errormsg, EC.id);      --81.特殊人群统计_儿童保健考核指标.sql
        SP_REPORT_PHEALTH_BORNWOMEN(errorcode, errormsg, EC.id);         --82.特殊人群统计_孕产妇统计.sql
        SP_REPORT_PHEALTH_BORN_MANAGE(errorcode, errormsg, EC.id);       --83.特殊人群统计_孕产妇工作管理统计报表.sql
        SP_REPORT_PHEALTH_WM_DISEASE(errorcode, errormsg, EC.id);        --84.特殊人群统计_妇女病管理考核指标.sql
        SP_REPORT_PHEALTH_OLDER(errorcode, errormsg, EC.id);             --85.特殊人群统计_老年保健考核指标.sql

        --dbms_output.putline(errormsg);
        --print: errormsg;
      END LOOP;
    END;

  end;

end SP_REPORT_Statistics;

/

