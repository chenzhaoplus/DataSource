create function getMdSequence(orgId number, seqType varchar2)
  return varchar2
/** 1:入库单号
  --  2:入库验收单号
  --  3: 财务验收单号
  --  4:挂号流水号
  --  5:门诊流水号
  --  6:处方流水号
  --  7: 药库调价流水号
  --  8：药库报溢单号
  --  9：药库报损单号
  -- 10：药库出库单号
  -- 11：药库盘点流水号
  -- 12: 药库退货流水号
  -- 13：药房入库流水号
  -- 14：药房报溢单号
  -- 15：药房报损单号
  -- 16：药房盘点流水号
  -- 17: 药房退货流水号
  -- 18: 药库采购计划单流水号
  -- 19: 药房请领单流水号
  -- 20：门诊挂号结账流水号
  -- 21：门诊收费结账流水号
  -- seqType为其他字符时result：seqType||'_'||日期||三位流水号
  **/
 is
  PRAGMA AUTONOMOUS_TRANSACTION;
  result varchar(30);
  tmp    number;
  curday varchar(8);
  num    number;
begin
  select to_char(sysdate, 'yyyymmdd') into curday from dual;
  select sn
    into tmp
    from md_sequence
   where org_id = orgId
     and type = seqType
     for update;
  select count(0)
    into num
    from md_sequence
   where org_id = orgId
     and type = seqType;
  if num = 0 then
    insert into md_sequence
      (org_id, type, sn, update_time, day)
    values
      (orgId, seqType, 1, sysdate, curday);
    tmp := 1;
  else
    select count(0)
      into num
      from md_sequence
     where org_id = orgId
       and type = seqType
       and day = curday;
    if num = 0 then
      update md_sequence
         set sn = '0001', update_time = sysdate, day = curday
       where org_id = orgId
         and type = seqType;
      tmp := 1;
    else
      update md_sequence
         set sn = tmp + 1, update_time = sysdate
       where org_id = orgId
         and type = seqType
         and day = curday;
      tmp := tmp + 1;
    end if;
  end if;

  case
    when seqType in
         ('1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21') then
      if length(tmp) > 4 then
        result := curday || to_char(tmp);
      else
        result := curday || LPAD(tmp, 4, '0');
      end if;
    else
      if length(tmp) > 3 then
        result := seqType || '_' || curday || to_char(tmp);
      else
        result := seqType || '_' || curday || LPAD(tmp, 3, '0');
      end if;
  end case;

  commit;
  return result;
exception
  when NO_DATA_FOUND then
    insert into md_sequence
      (org_id, type, sn, update_time, day)
    values
      (orgId, seqType, 1, sysdate, curday);
    commit;
    case
      when seqType in
           ('1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '16', '17', '18', '19', '20', '21') then
        result := curday || '0001';
      else
        result := seqType || '_' || curday || '001';
        return result;
    end case;
end getMdSequence;
/

