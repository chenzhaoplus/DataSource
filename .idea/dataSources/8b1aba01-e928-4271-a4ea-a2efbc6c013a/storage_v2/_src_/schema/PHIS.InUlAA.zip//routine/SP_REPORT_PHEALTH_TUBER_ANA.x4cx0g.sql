create procedure SP_REPORT_PHEALTH_TUBER_ANA(
     errorcode out int,				--返回错误代码
     errormsg out varchar2,	--返回错误参数
     p_org_id number    --机构代码
) is
/**
* REPORT疾病管理_结核病每月增长人数统计
* 统计项 结核病病人总数   服务人口总数   结核病病人本月增长数
*/
  v_report_date  VARCHAR(8):= to_char(sysdate - 1,'yyyymmdd'); --报表日期
  v_year_month  VARCHAR(6):= to_char(sysdate - 1,'yyyymm');    --报表日期 年月
  v_year  VARCHAR(4):= to_char(sysdate - 1,'yyyy');            --报表日期 年
  v_month VARCHAR(2):= to_char(sysdate - 1,'mm');              --报表日期 月
  v_num number;  --已存在统计数据总数
  v_total_num number; --患病总人数
  v_ehr_num number; --服务人口总数
  v_up_num number; --结核病病人本月增长数
  v_last_month_num number; --结核病上月人数
begin

--    v_report_date  := '20120331'; --报表日期
--    v_year_month  := '201203';    --报表日期 年月
--    v_year  := '2012';            --报表日期 年
--    v_month := '3';              --报表日期 月

    select count(0) into v_num from REPORT_PHEALTH_TUBER_ANA
    where REPORT_DATE = v_report_date and ORG_ID = p_org_id;

    -- 患病总人数
    select count(0) into v_total_num
    from phealth_tuberculosis_roster r
    inner join ehr_person ep on ( (r.patient_id = ep.id) and (ep.status = 0) and (ep.pt_org_id = p_org_id) )
--    where to_char(r.create_date,'yyyymmdd')< '20120401'
    ;

    --结核病病人本月增长数
    select count(0) into v_up_num
    from phealth_tuberculosis_roster r
    inner join ehr_person ep on ( (r.patient_id = ep.id) and (ep.status = 0) and (ep.pt_org_id = p_org_id) )
    where to_char(r.create_date,'yyyymm')= v_year_month
    ;

    -- 服务人口总数
    select t1.ulation_total_num into v_ehr_num
    from sys_organizations t1
    where (t1.id = p_org_id)
--    and to_char(t1.create_date,'yyyymmdd')< '20120401'
    ;

    if v_num>0 then
      update REPORT_PHEALTH_TUBER_ANA s
      set TOTAL_NUM = v_total_num,
          EHR_NUM = v_ehr_num,
          UP_NUM = v_up_num,
          YEAR = v_year,
          MONTH = v_month,
          s.UPDATE_TIME = sysdate
      where REPORT_DATE = v_report_date and ORG_ID = p_org_id;
    else
       insert into REPORT_PHEALTH_TUBER_ANA
       (REPORT_DATE, ORG_ID, TOTAL_NUM, EHR_NUM, UP_NUM, YEAR, MONTH, UPDATE_TIME, CREATE_DATE)
       values(v_report_date, p_org_id, v_total_num, v_ehr_num, v_up_num, v_year, v_month, sysdate, sysdate);
    end if;

   errorcode := 0;
   errormsg := 'ok';

   commit;
   exception when others then
   begin
        errorcode := -1;
        errormsg := SQLCODE||':'||SUBSTR(SQLERRM, 1, 200);
        rollback;
   end;
end SP_REPORT_PHEALTH_TUBER_ANA;

/

