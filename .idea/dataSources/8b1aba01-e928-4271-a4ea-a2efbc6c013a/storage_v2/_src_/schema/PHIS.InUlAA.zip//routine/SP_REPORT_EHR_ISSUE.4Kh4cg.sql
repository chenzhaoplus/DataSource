create procedure SP_REPORT_EHR_ISSUE
/********************************************************************/
   /*                                                                  */
   /*        健康问题目录统计                               */
   /*                                                                  */
   /********************************************************************/
as
  V_REPORT_DATE  VARCHAR(8);
begin
   V_REPORT_DATE :=to_char(sysdate - 1,'yyyymmdd');
   begin
     savepoint point; ---记录保存点---
     ----
     delete from report_ehr_issue t where t.report_date=V_REPORT_DATE;

     ----
     insert into report_ehr_issue(report_date,org_id,district_id,icd10,icd10name,amount)
     select V_REPORT_DATE, p.PT_ORG_ID ,p.committee,t.icd10,t.icd10name,count(t.icd10) amount
     from ehr_issue t,ehr_person p,sys_organizations org
     where ( p.status = '0') and  t.person_id=p.id and p.PT_ORG_ID =org.id
     group by t.icd10name,t.icd10,p.PT_ORG_ID ,p.committee
         ;
     commit;

      --3.异常处理

      exception   when   others   then
        begin
          rollback to savepoint point;
          rollback;
        end;
     end;
end SP_REPORT_EHR_ISSUE;

/

