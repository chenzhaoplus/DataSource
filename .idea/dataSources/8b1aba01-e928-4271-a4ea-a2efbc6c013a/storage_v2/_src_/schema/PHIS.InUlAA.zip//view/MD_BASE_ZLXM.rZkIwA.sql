create view MD_BASE_ZLXM as
  select
--诊疗项目
  org_id orgId, 2 itemType, system_code itemCode, system_name itemName, zjc_py pybm, zjc_wb wbbm, zjc_qt qtbm, flag, standard spec, null unit, unit unitName, price, null factoryCode, null factoryName, null stock,
  null kcUnit, unit kcUnitName, 1 kcScale,
  null mzUnit, unit mzUnitName, 1 mzScale,
  null zyUnit, unit zyUnitName, 1 zyScale,
  mz_nouse mzNonuse, zy_nouse zyNonuse, fbh
from md_base_treat_item
where org_id != 0

union all

--材料
select
  mbs.org_id orgId,4 itemType, mbs.normal_code itemCode, mbs.item_name itemName, mbs.zjc_py pybm, mbs.zjc_wb wbbm, mbs.zjc_qt qtbm, '11' flag, mbs.standard spec, mbss.unit_code unit, mbs.unit_name unitName, mbss.price, mbss.factory_name factory, null provider, mbss.kcsl stock,
  null kcUnit, mbs.mz_unit_name kcUnitName, 1 kcScale,
  mbs.mz_unit mzUnit, mbs.mz_unit_name mzUnitName, (case when mzu.scale is null then 1 else mzu.scale end) mzScale,
  mbs.zy_unit zyUnit, zyu.unit zy_unit_name, (case when zyu.scale is null then 1 else zyu.scale end) zyScale,
  to_char(mbss.mz_noused) mzNonuse, to_char(mbss.zy_noused) zyNonuse, 12 fbh
from md_base_stuff_item mbs
left join md_base_stuff_storage mbss on mbs.org_id = mbss.org_id and to_char(mbs.normal_code) = to_char(mbss.normal_code)
left join md_base_stuff_unit bsu on bsu.org_id = mbs.org_id and bsu.normal_code = mbs.normal_code and bsu.unit_code = mbs.unit
left join md_base_stuff_unit mzu on mzu.org_id = mbs.org_id and mzu.normal_code = mbs.normal_code and mzu.unit_code = mbs.mz_unit
left join md_base_stuff_unit zyu on zyu.org_id = mbs.org_id and zyu.normal_code = mbs.normal_code and mzu.unit_code = mbs.zy_unit
where mbs.org_id != 0
/

