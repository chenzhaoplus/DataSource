create procedure SP_REPORT_EHR_OLD_MAN
  /********************************************************************/
   /*                                                                  */
   /*       REPORT健康档案_老年人统计                                  */
   /*                                                                  */
   /********************************************************************/
as
 V_REPORT_DATE  VARCHAR(8);
begin
   V_REPORT_DATE :=to_char(sysdate - 1,'yyyymmdd');
   begin
     savepoint point; ---记录保存点---
     --1.
     delete from REPORT_EHR_OLD_MAN where REPORT_DATE=V_REPORT_DATE;
     --2.insert
     insert into REPORT_EHR_OLD_MAN(REPORT_DATE,ORG_ID,UPDATE_TIME,CREATE_DATE,HJ_MAN,HJ_WOMAN,FHJ_MAN,FHJ_WOMAN
     ,OTHER_MAN,OTHER_WOMAN,AGE_TYPE,AGE_NAME,DISTRICT_ID)
     select V_REPORT_DATE,F.PT_ORG_ID ,sysdate,sysdate, SUM(F.HJ_MAN) as HJ_MAN,SUM(F.HJ_WOMAN) as HJ_WOMAN,SUM(F.FHJ_MAN) as FHJ_MAN
     ,SUM(F.FHJ_WOMAN) as FHJ_WOMAN,SUM(F.OTHER_MAN) as OTHER_MAN,SUM(F.OTHER_WOMAN) as OTHER_WOMAN
     ,F.AGE_TYPE,F.AGE_NAME,F.DISTRICT_ID
     from(
                select PT_ORG_ID ,COMMITTEE as DISTRICT_ID, '60' as AGE_TYPE,'60' as AGE_NAME,
                         sum(case when jztype = '1' and sex = '1' then 1 else 0 end) as HJ_MAN,
                         sum(case when jztype = '1' and sex = '2' then 1 else 0 end) as HJ_WOMAN,
                         sum(case when jztype = '2' and sex = '1' then 1 else 0 end) as FHJ_MAN,
                         sum(case when jztype = '2' and sex = '2' then 1 else 0 end) as FHJ_WOMAN,
                         sum(case when nvl(jztype,'-1') not in('1','2') and sex = 1 or jztype is null then 1 else 0 end) as OTHER_MAN,
                         sum(case when nvl(jztype,'-1') not in('1','2') and sex = 2 or jztype is null then 1 else 0 end) as OTHER_WOMAN

                from ehr_person
                where ( status = '0') and (sysdate - birthday)>=60*365
                and    (sysdate - birthday)<65*365
                and COMMITTEE is not null
                group by PT_ORG_ID ,COMMITTEE

                union all

                select PT_ORG_ID ,COMMITTEE as DISTRICT_ID, '65' as AGE_TYPE,'65' as AGE_NAME,
                         sum(case when jztype = '1' and sex = '1' then 1 else 0 end) as HJ_MAN,
                         sum(case when jztype = '1' and sex = '2' then 1 else 0 end) as HJ_WOMAN,
                         sum(case when jztype = '2' and sex = '1' then 1 else 0 end) as FHJ_MAN,
                         sum(case when jztype = '2' and sex = '2' then 1 else 0 end) as FHJ_WOMAN,
                         sum(case when nvl(jztype,'-1') not in('1','2') and sex = 1 or jztype is null then 1 else 0 end) as OTHER_MAN,
                         sum(case when nvl(jztype,'-1') not in('1','2') and sex = 2 or jztype is null then 1 else 0 end) as OTHER_WOMAN
                from   ehr_person
                where ( status = '0') and (sysdate - birthday)>=65*365
                and    (sysdate - birthday)<70*365
                and COMMITTEE is not null
                group by PT_ORG_ID ,COMMITTEE

                union all

                select PT_ORG_ID ,COMMITTEE as DISTRICT_ID, '70' as AGE_TYPE,'70' as AGE_NAME,
                         sum(case when jztype = '1' and sex = '1' then 1 else 0 end) as HJ_MAN,
                         sum(case when jztype = '1' and sex = '2' then 1 else 0 end) as HJ_WOMAN,
                         sum(case when jztype = '2' and sex = '1' then 1 else 0 end) as FHJ_MAN,
                         sum(case when jztype = '2' and sex = '2' then 1 else 0 end) as FHJ_WOMAN,
                         sum(case when nvl(jztype,'-1') not in('1','2') and sex = 1 or jztype is null then 1 else 0 end) as OTHER_MAN,
                         sum(case when nvl(jztype,'-1') not in('1','2') and sex = 2 or jztype is null then 1 else 0 end) as OTHER_WOMAN
                from   ehr_person
                where ( status = '0') and (sysdate - birthday)>=70*365
                and    (sysdate - birthday)<75*365
                and COMMITTEE is not null
                group by PT_ORG_ID ,COMMITTEE

                union all

                select PT_ORG_ID ,COMMITTEE as DISTRICT_ID, '75' as AGE_TYPE,'75+' as AGE_NAME,
                         sum(case when jztype = '1' and sex = '1' then 1 else 0 end) as HJ_MAN,
                         sum(case when jztype = '1' and sex = '2' then 1 else 0 end) as HJ_WOMAN,
                         sum(case when jztype = '2' and sex = '1' then 1 else 0 end) as FHJ_MAN,
                         sum(case when jztype = '2' and sex = '2' then 1 else 0 end) as FHJ_WOMAN,
                         sum(case when nvl(jztype,'-1') not in('1','2') and sex = 1 or jztype is null then 1 else 0 end) as OTHER_MAN,
                         sum(case when nvl(jztype,'-1') not in('1','2') and sex = 2 or jztype is null then 1 else 0 end) as OTHER_WOMAN
                from   ehr_person
                where ( status = '0') and (sysdate - birthday)>=75*365
                and COMMITTEE is not null
                group by PT_ORG_ID ,COMMITTEE
            ) F GROUP BY F.PT_ORG_ID ,F.DISTRICT_ID,F.AGE_TYPE,f.AGE_NAME;

            commit;

         --3.异常处理

          exception   when   others   then
            begin
              rollback to savepoint point;
              rollback;
            end;

   end;

end SP_REPORT_EHR_OLD_MAN;

/

