create procedure SP_REPORT_EHR_BLOOD
/**
*健康档案_社区血型分类情况统计表
*/
as
 V_REPORT_DATE  VARCHAR(8);
begin
   V_REPORT_DATE :=to_char(sysdate - 1,'yyyymmdd');
   begin
     savepoint point; ---记录保存点---
     --1.
     delete from REPORT_EHR_BLOOD where REPORT_DATE=V_REPORT_DATE;
     -- insert
     insert into REPORT_EHR_BLOOD(REPORT_DATE,ORG_ID,SEX,BLOOD_A,BLOOD_B,BLOOD_AB,BLOOD_O,BLOOD_OTHER,UPDATE_TIME
     ,CREATE_DATE,DISTRICT_ID)

    select V_REPORT_DATE, t4.PT_ORG_ID , t3.dict_name sex,BLOOD_A,BLOOD_B,BLOOD_AB,BLOOD_O,BLOOD_OTHER,sysdate,sysdate,DISTRICT_ID from (
        select t2.PT_ORG_ID ,t2.DISTRICT_ID,t2.sex,sum(BLOOD_A)BLOOD_A,sum(BLOOD_B)BLOOD_B,sum(BLOOD_AB)BLOOD_AB,sum(BLOOD_O)BLOOD_O,sum(BLOOD_OTHER)BLOOD_OTHER
        from(
            select PT_ORG_ID ,COMMITTEE as DISTRICT_ID, t.sex,
            sum(case when blood_type = '1' then 1 else 0 end) as BLOOD_A,
            sum(case when blood_type = '2'  then 1 else 0 end) as BLOOD_B,
            sum(case when blood_type = '3'  then 1 else 0 end) as BLOOD_AB,
            sum(case when blood_type = '0'  then 1 else 0 end) as BLOOD_O,
            sum( ( case when nvl(blood_type,'5')=5 --and sex = 2
                 or blood_type is null then 1 else 0 end )
               ) as BLOOD_OTHER
            from ehr_person t where ( t.status = '0') and t.PT_ORG_ID  is not null and t.committee is not null
            group by t.PT_ORG_ID ,t.committee,t.sex,t.blood_type
        ) t2 group by t2.PT_ORG_ID ,t2.DISTRICT_ID,t2.sex
    ) t4
    left join std_gbdict_detail t3 on t3.gb_code='GB/T2261-1980' and t3.detail_code=t4.sex;
   ----
    commit;

         --3.异常处理

          exception   when   others   then
            begin
              rollback to savepoint point;
              rollback;
            end;
    end;
end SP_REPORT_EHR_BLOOD;

/

