create procedure SP_REPORT_PHEALTH_DIABETES_SEX(
     errorcode out int,				--返回错误代码
     errormsg out varchar2,	--返回错误参数
     p_org_id number    --机构代码
) is
/**
* REPORT公共卫生_糖尿病管理统计---按性别
* 统计项 患病总人数   已管理人数   规范管理人数  空腹血糖达标人数
* bus_type 4 管理卡  7 管理评估  2 随访
*/
  v_report_date  VARCHAR(8):= to_char(sysdate,'yyyymmdd'); --报表日期
  v_icd10 varchar(100) := 'I10.X02';     --诊断对应ICD10编码
  v_spec_id number := 10006;
  v_sex_id varchar(100) := 'GB/T2261-1980';--性别对应国标代码
  v_num number;
  v_create_date date := sysdate;--创建时间
begin
   select count(0) into v_num  from REPORT_PHEALTH_DIABETES_SEX where REPORT_DATE = v_report_date and ORG_ID = p_org_id and SPEC_ID = v_spec_id;
   if v_num>0 then
      select create_date into v_create_date from REPORT_PHEALTH_DIABETES_SEX where REPORT_DATE = v_report_date and ORG_ID = p_org_id and SPEC_ID = v_spec_id and rownum=1;
   end if;

   delete from REPORT_PHEALTH_DIABETES_SEX where REPORT_DATE = v_report_date and ORG_ID = p_org_id and SPEC_ID = v_spec_id;

   insert into REPORT_PHEALTH_DIABETES_SEX(REPORT_DATE,ORG_ID,SPEC_ID,SEX_TYPE,SEX_NAME,PERSON_COUNT,SPEC_COUNT,CHECK_COUNT,TO_PAR_COUNT,UPDATE_TIME,CREATE_DATE)
   select v_report_date, p_org_id, v_spec_id,a.sex, (select DICT_NAME from std_gbdict_detail where gb_code=v_sex_id and detail_code=a.sex),
     -- 患病总人数
     (
      select count(0) from phealth_diabetes_roster where
            patient_id in (select id from ehr_person where pt_org_id = p_org_id and sex = a.sex and (status = 0) )
     --select count(0) from ehr_issue where icd10 = v_icd10
--            and person_id in (select id from ehr_person where pt_org_id = p_org_id and sex = a.sex)
            ),
     -- 已管理人数
     (select count(0) from phealth_spec_case where spec_id = v_spec_id
            and person_id in (select id from ehr_person where pt_org_id = p_org_id and sex = a.sex and (status = 0) )),
     -- 规范管理人数
     (select count(count(0)) from phealth_soap_service s inner join ehr_person p on s.patient_id = p.id and (p.status = 0)
       where  p.pt_org_id = p_org_id and p.sex = a.sex and ( s.status = '0')
       group by s.patient_id
       having --sum(case when bus_type=4 then 1 else 0 end)>0 and
       sum(case when bus_type=8 then 1 else 0 end)>0 and sum(case when bus_type=9 then 1 else 0 end)>0
      ),
     --空腹血糖达标人数
     (select count(kpi.id) from ehr_health_kpi kpi inner join ehr_person p on kpi.person_id = p.id and p.pt_org_id = p_org_id and (p.status = 0)
            inner join phealth_spec_case spec on kpi.person_id = spec.person_id and spec.spec_id = v_spec_id
             where p.sex = a.sex and kpi.LLIMOSIS_BLOOD_SUGAR>=3.9 and kpi.LLIMOSIS_BLOOD_SUGAR<=6.1),
     sysdate, v_create_date
   from ehr_person a
   where a.pt_org_id = p_org_id
   and (a.status = 0)
   group by a.sex;
   errorcode := 0;
   errormsg := 'ok';

   commit;
   exception when others then
   begin
        errorcode := -1;
        errormsg := SQLCODE||':'||SUBSTR(SQLERRM, 1, 200);
        rollback;
   end;
end SP_REPORT_PHEALTH_DIABETES_SEX;

/

