create FUNCTION F_GetDrug_Unit(Unit IN VARCHAR2,lx in varchar2) RETURN VARCHAR2 AS
     unit_code VARCHAR2(20);

   BEGIN
     if lx='剂量单位'then
         select item_value into unit_code from bds.bds_code_table_item@serverDblink a inner join bds.bds_code_table@serverDblink b on a.t_id=b.id
        where b.type_name='药品剂量单位' and item_name=Unit and rownum=1;
     elsif lx='药房单位' then
         select item_value into unit_code from bds.bds_code_table_item@serverDblink a inner join bds.bds_code_table@serverDblink b on a.t_id=b.id
        where b.type_name='药品包装单位' and item_name=Unit and rownum=1;
     else
         select item_value into unit_code from bds.bds_code_table_item@serverDblink a inner join bds.bds_code_table@serverDblink b on a.t_id=b.id
        where b.type_name='药品包装单位' and item_name=Unit and rownum=1;
      end if;
    RETURN unit_code;
   END;
/

