create procedure SP_REPORT_EHR_OCCUPATION
  /********************************************************************/
   /*                                                                  */
   /*        REPORT健康档案_社区职业构成                               */
   /*                                                                  */
   /********************************************************************/
as
    V_REPORT_DATE  VARCHAR(8);
begin
   V_REPORT_DATE :=to_char(sysdate - 1,'yyyymmdd');
   begin
     savepoint point; ---记录保存点---

     delete from REPORT_EHR_OCCUPATION where report_date=V_REPORT_DATE;

     --insert
      insert into REPORT_EHR_OCCUPATION(report_date,org_id,OCCUPATION_ID,OCCUPATION_NAME,amount,update_time,create_date,district_id)

      select V_REPORT_DATE,t2.PT_ORG_ID ,t2.occupation,t3.dict_name as OCCUPATION_NAME,t2.sums,sysdate,sysdate,t2.committee from
      (
      select t.occupation,t.PT_ORG_ID ,t.committee,count(t.occupation)sums
        from (select t1.PT_ORG_ID ,t1.committee,
             case when nvl(t1.occupation,'Y')='Y' then 'Y' else t1.occupation end as occupation
              from ehr_person t1 where ( t1.status = '0') and t1.PT_ORG_ID  is not null and t1.committee is not null
        ) t
      group by t.occupation,t.PT_ORG_ID ,t.committee
      )t2 left join std_gbdict_detail t3 on t3.gb_code='GB/T6565-2009' and t3.detail_code=t2.occupation;


      --commit;
       commit;

        --3.异常处理

        exception   when   others   then
          begin
            rollback to savepoint point;
            rollback;
          end;

     end;
end SP_REPORT_EHR_OCCUPATION;

/

