create procedure SP_REPORT_EHR_ARCHIVE_SCALE
/********************************************************************/
   /*                                                                  */
   /*      统计个人健康档案及家庭档案的数量                                     */
   /*                                                                  */
   /********************************************************************/
as
   v_report_date VARCHAR(8);
   begin
      v_report_date :=to_char(sysdate - 1,'yyyymmdd');
      begin
      savepoint point; ---记录保存点---

     ---
      delete from REPORT_EHR_ARCHIVE_SCALE t where t.report_date=v_report_date;

      insert into REPORT_EHR_ARCHIVE_SCALE(REPORT_DATE,ORG_ID,PERSON_AMOUNT,ARCHIVE_PERSON_AMOUNT,UPDATE_TIME
      ,CREATE_DATE,DISTRICT_ID,FAMILY_AMOUNT,ARCHIVE_FAMILY_AMOUNT,Man_Amount,WOMEN_AMOUNT,OTHER_SEX_AMOUNT)

      select report_date,PT_ORG_ID ,0,sum(person_count) a_person_cnt,sysdate,sysdate,committee,0,
      sum(family_count)a_family_count,sum(MAN_amount),sum(WOMAN_amount),sum(other_sex_amount)
      from(
          select v_report_date as report_date ,t.PT_ORG_ID ,t.committee,count(1)person_count,0 family_count,
          sum(case when t.sex = '1' then 1 else 0 end) as MAN_amount,
          sum(case when t.sex = '2' then 1 else 0 end) as WOMAN_amount,
          sum(case when t.sex <> '2' and  t.sex <> '1' then 1 else 0 end) as other_sex_amount
          from  ehr_person t
          where  ( t.status = '0')
          group by t.PT_ORG_ID ,t.committee
          union all
          select v_report_date as report_date, t3.PT_ORG_ID ,t3.committee,0 person_count,count(1) family_count,
          0 MAN_amount,0 WOMAN_amount, 0 other_sex_amount
          from ehr_family_rela t1
          inner join ehr_family t2 on t1.family_id = t2.id
          inner join ehr_person t3 on t1.person_id = t3.id
          where t1.rela_master='01'
          --and ( t3.status = '0')
          group by t3.PT_ORG_ID ,t3.committee
          union all
          select v_report_date as report_date, t3.org_id ,t3.district_id,0 person_count,count(1) family_count,
          0 MAN_amount,0 WOMAN_amount, 0 other_sex_amount
          from ehr_family_rela t1
          inner join ehr_family t2 on t1.family_id = t2.id
          inner join sys_org_district t3 on t3.district_id = t2.community_id
          where t1.rela_master='01'
          and ( t2.family_type = '1')
          group by t3.org_id ,t3.district_id
      ) t  group by t.report_date, t.PT_ORG_ID , t.committee;


      --一家机构没有数据，则相应统计结果为0,插入对应的记录
      insert into REPORT_EHR_ARCHIVE_SCALE(REPORT_DATE,ORG_ID,PERSON_AMOUNT,ARCHIVE_PERSON_AMOUNT,UPDATE_TIME
      ,CREATE_DATE,DISTRICT_ID,FAMILY_AMOUNT,ARCHIVE_FAMILY_AMOUNT,Man_Amount,WOMEN_AMOUNT,OTHER_SEX_AMOUNT)
      select v_report_date,so.id,0,0 a_person_cnt,sysdate,sysdate,0,0,
      0 a_family_count,0,0,0
      from sys_organizations so
      where so.id not in (
        select s.org_id
        from REPORT_EHR_ARCHIVE_SCALE s
        where s.report_date = v_report_date
        group by org_id
      );

      commit;
      --3.异常处理

        exception   when   others   then
          begin
            rollback to savepoint point;
            rollback;
          end;

    end;
end SP_REPORT_EHR_ARCHIVE_SCALE;

/

