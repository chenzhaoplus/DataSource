create procedure SP_REPORT_EHR_HOUSERHODER
  /********************************************************************/
   /*                                                                  */
   /*          健康档案_社区户籍分类                                   */
   /*                                                                  */
   /********************************************************************/
AS
      REPORTTIME  VARCHAR(8);--报表时间

BEGIN

      REPORTTIME :=to_char(sysdate - 1,'yyyymm');

      begin
         savepoint point; ---记录保存点---

         --1.删除旧记录
          DELETE FROM REPORT_EHR_HOUSERHODER WHERE REPORT_DATE = REPORTTIME ;

         --2.插入新记录
          INSERT INTO REPORT_EHR_HOUSERHODER(REPORT_DATE,ORG_ID,CZ_AMOUNT,ZZ_AMOUNT,QT_AMOUNT,UPDATE_TIME,CREATE_DATE,DISTRICT_ID)

          SELECT  REPORTTIME,T.PT_ORG_ID ,sum(CZ_CNT) HJ_CNT,sum(ZZ_CNT) FHJ_CNT,sum(QT_CNT) OTHER_CNT,sysdate,sysdate,DISTRICT_ID

          FROM (
                select p.PT_ORG_ID  ,p.committee as DISTRICT_ID,
                      sum(case when jztype = '1' then 1 else 0 end) CZ_CNT,
                      sum(case when jztype = '2' then 1 else 0 end) ZZ_CNT,
                      sum(case when (nvl(jztype,'-1')) not in('1','2')or jztype is null then 1 else 0 end) QT_CNT
                from   ehr_person p
                where ( p.status = '0') and p.PT_ORG_ID  is not null and p.committee is not null

                group by p.PT_ORG_ID ,p.committee

               ) T
          GROUP BY T.PT_ORG_ID ,t.DISTRICT_ID;
          commit;

         --3.异常处理
          exception   when   others   then
            begin
              rollback to savepoint point;
              rollback;
            end;


      end;

end SP_REPORT_EHR_HOUSERHODER;

/

