create procedure SP_REPORT_EHR_USE_SCALE
/********************************************************************/
/*                                                                  */
/*      健康档案_社区服务统计                                       */
/*                                                                  */
/********************************************************************/
as
    v_report_date VARCHAR(8);
begin
    v_report_date :=to_char(sysdate - 1,'yyyymmdd');
    begin
      savepoint point; ---记录保存点---

      delete from REPORT_EHR_USE_SCALE t ;--where t.report_date=v_report_date;

      --先 插入 “已做服务的人的次数(按机构,服务类型,医生  计算)”
      insert into REPORT_EHR_USE_SCALE(report_date, org_id, business_id, create_id
      , service_total_number
      , update_time, create_date
      )
      select v_report_date as report_date
      , t3.PT_ORG_ID, t4.bus_type, t4.create_userid
      , count( t3.id ) service_total_number
      , sysdate, sysdate
      from ehr_person t3
      inner join phealth_soap_service t4 on ( t3.id = t4.patient_id )
      inner join sys_business_category sbc on ( t4.bus_type = sbc.id )
      where  ( t3.status = '0') and ( t4.status = '0') and ( sbc.status = '0')
             and ( t3.archive_date is not null )
             and ( t3.admin_user_id is not null )
             and ( t3.archive_user_id is not null )
             and ( t3.PT_ORG_ID  is not null )
             and ( t3.committee is not null )
--          and t3.pt_org_id = 581422008--
--          and t4.bus_type = 75--s.business_id
      group by t3.PT_ORG_ID, t4.bus_type, t4.create_userid
      order by t3.PT_ORG_ID, t4.bus_type, t4.create_userid
      ;

      --插入 “已做服务的人数(按机构,服务类型  计算)”
      update REPORT_EHR_USE_SCALE s set s.check_person_amount = (
          select count( distinct t3.id ) check_person_amount
          from ehr_person t3
          inner join phealth_soap_service t4 on ( t3.id = t4.patient_id )
          where  ( t3.status = '0') and ( t4.status = '0')
           and ( t3.archive_date is not null )
           and ( t3.admin_user_id is not null )
           and ( t3.archive_user_id is not null )
           and ( t3.PT_ORG_ID  is not null )
           and ( t3.committee is not null )
          and t3.pt_org_id = s.org_id
          and t4.bus_type = s.business_id
      )
      where s.report_date = v_report_date;

      --插入 “已做服务的人数(按机构，服务类型，医生  计算)”

      update REPORT_EHR_USE_SCALE s set s.usage_amount = (
              select
              --v_report_date as report_date
              --, t3.PT_ORG_ID, t4.bus_type, t4.create_userid
              --,
              count( distinct t3.id ) usage_amount
              from ehr_person t3
              inner join phealth_soap_service t4 on ( t3.id = t4.patient_id )
              where  ( t3.status = '0') and ( t4.status = '0')
              and ( t3.archive_date is not null )
              and ( t3.admin_user_id is not null )
              and ( t3.archive_user_id is not null )
              and ( t3.PT_ORG_ID  is not null )
              and ( t3.committee is not null )
              and t3.pt_org_id = s.org_id--581422008--s.org_id
              and t4.bus_type = s.business_id--2--s.business_id
              and t4.create_userid = s.create_id--640999--s.create_id
--              group by t3.PT_ORG_ID, t4.bus_type, t4.create_userid
--              order by t3.PT_ORG_ID, t4.bus_type, t4.create_userid
      )
      where s.report_date =  v_report_date;--'20120726'

      --机构的总人数
      update REPORT_EHR_USE_SCALE s set s.person_amount = (
          select count(0) person_count
          from ehr_person t1
          where ( t1.status = '0')
          and t1.PT_ORG_ID = s.org_id
          and ( t1.archive_date is not null )
          and ( t1.admin_user_id is not null )
          and ( t1.archive_user_id is not null )
          and ( t1.PT_ORG_ID  is not null )
          and ( t1.committee is not null )
--          and t1.PT_ORG_ID in( select t.id from sys_organizations t start with t.id = 581422008 connect by prior t.id = t.parent_id )s.org_id
--          and t1.archive_user_id = s.create_id
      )
      where s.report_date = v_report_date;


      /*
      select v_report_date as report_date
      , a.org_id, a.bus_type, a.create_userid
      , a.usage_amount, b.person_count
      , d.check_person_amount
      , sysdate, sysdate
      from
      (
        select t2.org_id, t2.create_userid, t2.bus_type, count(0) usage_amount
        from  phealth_soap_service t2
        where  ( t2.status = '0')
        group by t2.org_id,t2.create_userid, t2.bus_type
      ) a,
      (
        select t1.PT_ORG_ID, t1.archive_user_id, count(0) person_count
        from  ehr_person t1
        where  ( t1.status = '0')
        group by t1.PT_ORG_ID, t1.archive_user_id
      ) b,
      (
        select t3.PT_ORG_ID, t4.create_userid, t4.bus_type, count(distinct t3.id) check_person_amount
        from  ehr_person t3
        inner join phealth_soap_service t4 on ( t3.id = t4.patient_id )
        where  ( t3.status = '0') and ( t4.status = '0')
        group by t3.PT_ORG_ID, t4.create_userid, t4.bus_type
        order by t3.PT_ORG_ID, t4.create_userid, t4.bus_type
      ) d
      where ( a.org_id = b.PT_ORG_ID ) and ( a.create_userid = b.archive_user_id )
      and ( a.org_id = d.PT_ORG_ID ) and ( a.create_userid = d.create_userid ) and ( a.bus_type = d.bus_type )
      order by a.org_id, a.create_userid, a.bus_type;
      */


      --设置org_name
      update REPORT_EHR_USE_SCALE s set s.org_name = ( select name from sys_organizations where id = s.org_id );
      --设置 business_name
      update REPORT_EHR_USE_SCALE s set s.business_name = ( select category_name from sys_business_category where id = s.business_id );
      --设置 create_name
      update REPORT_EHR_USE_SCALE s set s.create_name = ( select name from sys_employee_info where id = s.create_id );
      --设置spec_id, s.spec_name   begin
      update REPORT_EHR_USE_SCALE s set (s.spec_id, s.spec_name) = (
          select ps.id, ps.spec_name
          from phealth_spec ps
          inner join phealth_spec_soap pss on  ps.id = pss.spec_id
          where pss.business_type = s.business_id
      );
      --update REPORT_EHR_USE_SCALE s set s.spec_id = 0, s.spec_name = '基本信息' where s.business_id in (75,76);
      --设置spec_id, s.spec_name   end

      --插入 “已做某专案的人数(按机构,专案类型  计算)” begin
      update REPORT_EHR_USE_SCALE s set s.spec_person_amount = (
          select count( distinct t3.id ) spec_person_amount
          from ehr_person t3
          inner join phealth_soap_service t4 on ( t3.id = t4.patient_id )
          inner join phealth_spec_soap pss on ( t4.bus_type = pss.business_type )
          where  ( t3.status = '0') and ( t4.status = '0') and ( pss.status = '0')
           and ( t3.archive_date is not null )
           and ( t3.admin_user_id is not null )
           and ( t3.archive_user_id is not null )
           and ( t3.PT_ORG_ID  is not null )
           and ( t3.committee is not null )
          and t3.pt_org_id = s.org_id --'581422008'
          and pss.spec_id = s.spec_id --'10005'
      )
      where s.report_date = v_report_date;
      --插入 “已做某专案的人数(按机构,专案类型  计算)” end

      --设置未做服务的人的总数
      update REPORT_EHR_USE_SCALE set notcheck_person_amount = person_amount - check_person_amount;

     commit;
      --3.异常处理

        exception   when   others   then
          begin
            rollback to savepoint point;
            rollback;
          end;

    end;
end SP_REPORT_EHR_USE_SCALE;
/

