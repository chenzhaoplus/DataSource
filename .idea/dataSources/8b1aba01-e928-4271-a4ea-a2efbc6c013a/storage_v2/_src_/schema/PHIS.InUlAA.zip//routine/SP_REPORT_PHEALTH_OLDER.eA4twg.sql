create procedure SP_REPORT_PHEALTH_OLDER(
     errorcode out int,				--返回错误代码
     errormsg out varchar2,	--返回错误参数
     p_org_id number    --机构代码
) is
/**
* REPORT公共卫生_老年人管理考核指标
* 统计项 患病总人数   已管理人数   规范管理人数  65岁以上常驻居民  健康体检人数 年检人数 健康随访数
* bus_type 15 健康体检  7 年检  14 健康随访
*/
  v_report_date  VARCHAR(8):= to_char(sysdate,'yyyymmdd'); --报表日期
  v_spec_id number := 10004;
  v_num number;  --已存在统计数据总数
  v_person_count number; --患病总人数
  v_spec_count number; --已管理人数
  v_check_count number; --规范管理人数
  v_65up_count number; --65岁以上常驻居民
  v_checkup_count number;  --健康体检人数
  v_year_check_count number; --年检人数
  v_flow_count number;  --健康随访数
  v_old_age number:=65; --根据《。。。2011标准。。。》，65岁及以上，算老年人
  v_fu_kou number:= 1;--常住户口类别
begin
   select count(0) into v_num from REPORT_PHEALTH_OLDER where REPORT_DATE = v_report_date and ORG_ID = p_org_id and SPEC_ID = v_spec_id;
   -- 老年人总数
   select count(0) into v_person_count
   from phealth_older_roster r
   inner join ehr_person ep on ( (r.patient_id = ep.id) and (ep.status = 0) and (ep.pt_org_id = p_org_id) );

   -- 已管理人数
   select count(0) into v_spec_count
   from phealth_spec_case
   where spec_id = v_spec_id
          and person_id in (
             select ep.id
             from phealth_older_roster r
             inner join ehr_person ep on ( (r.patient_id = ep.id) and (ep.status = 0) and (ep.pt_org_id = p_org_id) )
          );

   -- 规范管理人数
   select count(0) into v_check_count from
   (
      select
--      (select count(0) from phealth_soap_service where patient_id = pids.patient_id and bus_type=4 and ( status = '0')) cardNum,
--      (select count(0) from phealth_soap_service where patient_id = pids.patient_id and bus_type=7 and ( status = '0')) evaluteNum,
        (select count(0) from phealth_soap_service where patient_id = pids.patient_id and bus_type=14 and ( status = '0')) visitNum
      from
      (
         select distinct patient_id from phealth_soap_service where patient_id in (
             select ep.id
             from phealth_older_roster r
             inner join ehr_person ep on ( (r.patient_id = ep.id) and (ep.status = 0) and (ep.pt_org_id = p_org_id) )
         ) and ( status = '0')
      ) pids
   ) tt
   where --tt.cardNum>0 and tt.evaluteNum>0 and
   tt.visitNum>0;
   --65岁以上常驻居民
   select count(0) into v_65up_count
   from phealth_older_roster r
   inner join ehr_person ep on ( (r.patient_id = ep.id) and (ep.status = 0) and (ep.pt_org_id = p_org_id) )
   where ep.pt_org_id = p_org_id and ep.HUKOU_TYPE=v_fu_kou
         and sysdate-birthday>=65*365 ;

   --健康体检人数
   select count(0) into v_checkup_count from (
          select patient_id from phealth_soap_service
          where patient_id in (
             select ep.id
             from phealth_older_roster r
             inner join ehr_person ep on ( (r.patient_id = ep.id) and (ep.status = 0) and (ep.pt_org_id = p_org_id) )
          ) and bus_type = 15 and ( status = '0')
          group by patient_id
   );
   --年检人数
   select count(0) into v_year_check_count from (
          select patient_id from phealth_soap_service
          where patient_id in (
             select ep.id
             from phealth_older_roster r
             inner join ehr_person ep on ( (r.patient_id = ep.id) and (ep.status = 0) and (ep.pt_org_id = p_org_id) )
          ) and bus_type = 15 and ( status = '0')
          group by patient_id
   );
   --健康随访数
   select count(0) into v_flow_count from (
          select patient_id from phealth_soap_service
          where patient_id in (
             select ep.id
             from phealth_older_roster r
             inner join ehr_person ep on ( (r.patient_id = ep.id) and (ep.status = 0) and (ep.pt_org_id = p_org_id) )
--                select id from ehr_person where pt_org_id = p_org_id and sysdate-birthday>v_old_age*365
          ) and bus_type = 14 and ( status = '0')
          group by patient_id
    );

   if v_num>0 then
      update REPORT_PHEALTH_OLDER
      set PERSON_COUNT = v_person_count,
          SPEC_COUNT = v_spec_count,
          CHECK_COUNT = v_check_count,
          UP65_COUNT = v_65up_count,
          CHECKUP_COUNT = v_checkup_count,
          YEAR_CHECK_COUNT = v_year_check_count,
          FLOW_COUNT = v_flow_count,
          UPDATE_TIME = sysdate
      where REPORT_DATE = v_report_date and ORG_ID = p_org_id and SPEC_ID = v_spec_id;
   else
       insert into REPORT_PHEALTH_OLDER(REPORT_DATE, ORG_ID, SPEC_ID, PERSON_COUNT, SPEC_COUNT, CHECK_COUNT, UP65_COUNT, CHECKUP_COUNT, YEAR_CHECK_COUNT, FLOW_COUNT, UPDATE_TIME, CREATE_DATE)
       values(v_report_date, p_org_id, v_spec_id, v_person_count, v_spec_count, v_check_count, v_65up_count, v_checkup_count, v_year_check_count, v_flow_count, sysdate, sysdate);
   end if;
   errorcode := 0;
   errormsg := 'ok';

   commit;
   exception when others then
   begin
        errorcode := -1;
        errormsg := SQLCODE||':'||SUBSTR(SQLERRM, 1, 200);
        rollback;
   end;
end SP_REPORT_PHEALTH_OLDER;

/

