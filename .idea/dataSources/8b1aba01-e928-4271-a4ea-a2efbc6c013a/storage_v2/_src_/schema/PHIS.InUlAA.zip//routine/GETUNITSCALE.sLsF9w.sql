create function getUnitScale( orgId in number, drugCode in varchar2, oldUnit in number, newUnit in number) return number is
  Result number;
begin
  -- orgId 机构ID
  -- drugCode 药品代码
  -- oldUnit 旧单位代码
  -- newUnit 新单位代码
  -- return  旧单位与新单位比率,值为 旧单位/新单位
  select
  (select scale from md_base_drug_unit where org_id = orgId and m_code = drugCode and unit_code = oldUnit)/
  (select scale from md_base_drug_unit where org_id = orgId and m_code = drugCode and unit_code = newUnit) into Result
  from dual;
  return round(Result,4);
end getUnitScale;
/

