create procedure SP_REPORT_PHEALTH_PERSON
/**
*REPORT健康档案_社区人数统计
*/
as
V_REPORT_DATE  VARCHAR(8);
begin
    V_REPORT_DATE :=to_char(sysdate - 1,'yyyymmdd');
    begin
        savepoint point; ---记录保存点---
        -----delete
        delete from REPORT_PHEALTH_PERSON where report_date=V_REPORT_DATE;
        -- insert
        insert into REPORT_PHEALTH_PERSON(
            REPORT_DATE, UPDATE_DATE, CREATE_DATE,
            ORG_ID, COMMITTEES_ID, ORG_NAME, COMMITTEES_NAME,
            HYPERTENSISONC_COUNT, DIABETES_COUNT, TUMOR_COUNT, AIDS_COUNT,
            CHILDREN_COUNT, WOMEN_COUNT, OLDER_COUNT, MENTAL_COUNT
        )
        select V_REPORT_DATE, sysdate as UPDATE_DATE, sysdate as CREATE_DATE, PT_ORG_ID, committee
            , so.name as ORG_NAME, sd.f_name as COMMITTEES_NAME,
            sum(HYPERTENSISONC_COUNT) as HYPERTENSISONC_COUNT, sum(DIABETES_COUNT) as DIABETES_COUNT,
            sum(TUMOR_COUNT) as TUMOR_COUNT, sum(AIDS_COUNT) as AIDS_COUNT,
            sum(CHILDREN_COUNT) as CHILDREN_COUNT, sum(WOMEN_COUNT) as WOMEN_COUNT,
            sum(OLDER_COUNT) as OLDER_COUNT, sum(MENTAL_COUNT) as MENTAL_COUNT
        from(

            select ep.pt_org_id, ep.committee            --高血压总数
            , count(0) as HYPERTENSISONC_COUNT, 0 as DIABETES_COUNT, 0 as TUMOR_COUNT, 0 as AIDS_COUNT
            , 0 as CHILDREN_COUNT, 0 as WOMEN_COUNT, 0 as OLDER_COUNT, 0 as MENTAL_COUNT
            from phealth_hypertensionc_person r
            inner join ehr_person ep on ( (r.person_id = ep.id) and (ep.status = 0) )
            group by ep.pt_org_id, ep.committee
            union
            select ep.pt_org_id, ep.committee            --糖尿病总数
            , 0, count(0) as DIABETES_COUNT, 0, 0, 0, 0, 0, 0
            from phealth_diabetes_roster r
            inner join ehr_person ep on ( (r.patient_id = ep.id) and (ep.status = 0) )
            group by ep.pt_org_id, ep.committee
            union
            select ep.pt_org_id, ep.committee            --肿瘤病总数
            , 0, 0, count(0) as TUMOR_COUNT, 0, 0, 0, 0, 0
            from phealth_tumour_roster r
            inner join ehr_person ep on ( (r.patient_id = ep.id) and (ep.status = 0) )
            group by ep.pt_org_id, ep.committee
            union
            select ep.pt_org_id, ep.committee            --结核病总数
            , 0, 0, 0, count(0) as AIDS_COUNT, 0, 0, 0, 0
            from phealth_tuberculosis_roster r
            inner join ehr_person ep on ( (r.patient_id = ep.id) and (ep.status = 0) )
            group by ep.pt_org_id, ep.committee
            union
            select ep.pt_org_id, ep.committee            --儿童总数
            , 0, 0, 0, 0, count(0) as CHILDREN_COUNT, 0, 0, 0
            from phealth_child_roster r
            inner join ehr_person ep on ( (r.patient_id = ep.id) and (ep.status = 0) )
            group by ep.pt_org_id, ep.committee
            union
            select ep.pt_org_id, ep.committee            --妇女总数
            , 0, 0, 0, 0, 0, count(0) as WOMEN_COUNT, 0, 0
            from phealth_born_women_roster r
            inner join ehr_person ep on ( (r.patient_id = ep.id) and (ep.status = 0) )
            group by ep.pt_org_id, ep.committee
            union
            select ep.pt_org_id, ep.committee            --老年人总数
            , 0, 0, 0, 0, 0, 0, count(0) as OLDER_COUNT, 0
            from phealth_older_roster r
            inner join ehr_person ep on ( (r.patient_id = ep.id) and (ep.status = 0) )
            group by ep.pt_org_id, ep.committee
            union
            select ep.pt_org_id, ep.committee            --精神病总数
            , 0, 0, 0, 0, 0, 0, 0, count(0) as MENTAL_COUNT
            from phealth_mental_illness_roster r
            inner join ehr_person ep on ( (r.patient_id = ep.id) and (ep.status = 0) )
            group by ep.pt_org_id, ep.committee
        ) t
        inner join sys_organizations so on (t.PT_ORG_ID = so.id)
        inner join sys_districts sd on (t.committee = sd.f_code)
        group by PT_ORG_ID, committee, so.name, sd.f_name
        ;
       commit;

       --3.异常处理

       exception   when   others   then
          begin
            rollback to savepoint point;
            rollback;
          end;
    end;
end SP_REPORT_PHEALTH_PERSON;

/

